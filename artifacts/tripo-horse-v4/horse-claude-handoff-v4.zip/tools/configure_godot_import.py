"""Update an existing Godot .glb.import without changing dependency paths."""
from pathlib import Path
import argparse,re
p=argparse.ArgumentParser();p.add_argument('import_file',type=Path);args=p.parse_args()
s=args.import_file.read_text()
assert '[params]' in s,'Run Godot import once first.'
for key,value in {'meshes/light_baking':'0','animation/fps':'240','animation/remove_immutable_tracks':'false','meshes/generate_lods':'true'}.items():
 pattern=r'^'+re.escape(key)+r'=.*$'
 if re.search(pattern,s,re.M):s=re.sub(pattern,key+'='+value,s,flags=re.M)
 else:s=s.replace('[params]','[params]\n'+key+'='+value)
args.import_file.write_text(s)
print('Updated import parameters; reimport the GLB in Godot.')
