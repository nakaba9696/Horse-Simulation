import bpy,numpy as np,json
from pathlib import Path
from mathutils import Matrix,Vector
P=Path(__file__).resolve().parent.parent
bpy.ops.wm.open_mainfile(filepath=str(P/'regions.blend'))
o=next(x for x in bpy.context.scene.objects if x.type=='MESH' and len(x.data.vertices)>1000);a=next(x for x in bpy.context.scene.objects if x.type=='ARMATURE')
for track in a.animation_data.nla_tracks:track.mute=True
a.animation_data.action=bpy.data.actions['RaceGallop_Loop']
K=json.loads((P/'build-info.json').read_text())['shorten_x']
base_vertex_count=int(o.get('base_vertex_count',len(o.data.vertices)))
hair_roots=json.loads(o.get('hair_root_vertices','{}'))
if o.data.shape_keys:
 for key in list(o.data.shape_keys.key_blocks)[::-1]:o.shape_key_remove(key)
bpy.context.scene.frame_set(55);bpy.context.view_layer.update()
rest=np.array([v.co[:] for v in o.data.vertices]);ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());mesh=ev.to_mesh();pos=np.array([v.co[:] for v in mesh.vertices]);ev.to_mesh_clear()
ids={};groups=[];gid=[]
for v in o.data.vertices:
 k=tuple(round(float(c),6) for c in v.co)
 if k not in ids:ids[k]=len(groups);groups.append([])
 gid.append(ids[k]);groups[ids[k]].append(v.index)
adj=[set() for _ in groups]
for e in o.data.edges:
 i,j=(gid[v] for v in e.vertices)
 if i!=j:adj[i].add(j);adj[j].add(i)
def smooth(lo,hi,x):
 t=max(0,min(1,(x-lo)/(hi-lo)));return t*t*(3-2*t)
mask=[]
for g in groups:
 x,y,z=rest[g[0]];x/=K
 limb=sum(gr.weight for gr in o.data.vertices[g[0]].groups if 'Limb_' in o.vertex_groups[gr.group].name)
 value=smooth(-.40,-.34,x)*(1-smooth(-.02,.08,x))*smooth(.30,.47,z)*(1-smooth(.82,.88,z))
 if g[0]>=base_vertex_count:value=0
 mask.append(value)
mask=np.array(mask);G=np.array([pos[g].mean(axis=0) for g in groups]);original=G.copy()
for iteration in range(120):
 for strength in [.5,-.25]:
  N=G.copy()
  for i in np.flatnonzero(mask>.0001):
   if adj[i]:N[i]+=strength*mask[i]*(G[list(adj[i])].mean(axis=0)-G[i])
  G=N
basis=o.shape_key_add(name='Basis');key=o.shape_key_add(name='RaceNeckCorrective');key.value=1.0
vg={g.index:g.name for g in o.vertex_groups};maximum=0;count=0
for v in o.data.vertices:
 delta=G[gid[v.index]]-original[gid[v.index]]
 if np.linalg.norm(delta)<1e-7:continue
 M=Matrix(((0,0,0,0),)*4)
 for g in v.groups:
  name=vg[g.group]
  if name not in a.pose.bones:continue
  T=o.matrix_world.inverted()@a.matrix_world@a.pose.bones[name].matrix@a.data.bones[name].matrix_local.inverted()@a.matrix_world.inverted()@o.matrix_world
  for i in range(4):
   for j in range(4):M[i][j]+=g.weight*T[i][j]
 d=M.to_3x3().inverted_safe()@Vector(delta)
 key.data[v.index].co=v.co+d;maximum=max(maximum,d.length);count+=1
# New tuft geometry inherits its anchor correction without smoothing away its tips.
for index,root in hair_roots.items():
 index=int(index);root=int(root);key.data[index].co=o.data.vertices[index].co+(key.data[root].co-o.data.vertices[root].co)
# Reduce baked normal-map strength; high-frequency mane detail stays in the texture.
for mat in o.data.materials:
 for node in mat.node_tree.nodes:
  if node.type=='NORMAL_MAP':node.inputs['Strength'].default_value=.15
specs=json.loads((P/'animation-specs.json').read_text());shape=o.data.shape_keys;shape.animation_data_create();morph_actions={}
for clip,sp in specs.items():
 act=bpy.data.actions.new('Morph_'+clip);act.use_fake_user=True;shape.animation_data.action=act
 key.value=1.0 if clip=='RaceGallop_Loop' else 0.0;key.keyframe_insert(data_path='value',frame=1);key.keyframe_insert(data_path='value',frame=sp['frames']+1)
 for fc in act.fcurves:
  for point in fc.keyframe_points:point.interpolation='LINEAR'
 shape.animation_data.action=None;tr=shape.animation_data.nla_tracks.new();tr.name=clip;tr.strips.new(clip,1,act);tr.mute=True;morph_actions[clip]=act
shape.animation_data.action=morph_actions['Stand_Loop'];a.animation_data.action=bpy.data.actions['Stand_Loop'];key.value=0.0
bpy.context.scene.frame_set(1);bpy.ops.wm.save_as_mainfile(filepath=str(P/'horse-gallop.blend'))
(P/'neck-corrective.json').write_text(json.dumps({'shape_key':'RaceNeckCorrective','race_value':1,'stand_walk_value':0,'affected_vertices':count,'max_rest_delta':maximum,'reference_frame':55,'method':'120 damped Taubin pairs on throat/neck/shoulder mask, broad shoulder transition and inverse LBS displacement; tufts preserve shape'},indent=2));print('CORRECTIVE',count,maximum)
