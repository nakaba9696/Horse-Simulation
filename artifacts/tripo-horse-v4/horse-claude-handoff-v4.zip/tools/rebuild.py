"""Rebuild from the bundled original. Python 3 + Blender 4.3.2 on PATH."""
import argparse, subprocess, json, struct, hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--blender',default='blender');p.add_argument('--render',action='store_true');args=p.parse_args()
root=Path(__file__).resolve().parent.parent
for stage in ['rest','animate','geometry','regions','corrective','normals','export','measure','sockets']+(['render'] if args.render else []):
 print('STAGE',stage,flush=True)
 subprocess.run([args.blender,'-b','-t','4','--python-exit-code','1','--python',str(root/'tools'/f'{stage}.py')],check=True)
raw=(root/'horse-gallop.glb').read_bytes();size=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+size])
assert len(doc['skins'][0]['joints'])==54
assert {x['name'] for x in doc['animations']}=={'RaceGallop_Loop','Stand_Loop','Walk_Loop'}
assert {'Saddle','Stirrup_L','Stirrup_R','Bit_L','Bit_R','Withers'}<={n.get('name','') for n in doc['nodes']}
horse=next(n['mesh'] for n in doc['nodes'] if n.get('name')=='Horse')
for primitive in doc['meshes'][horse]['primitives']:
 assert 'TEXCOORD_1' in primitive['attributes']
 assert len(primitive['targets'])==1
motion=json.loads((root/'motion-validation.json').read_text())['RaceGallop_Loop']['summary']
assert .15<=motion['airborne_fraction']<=.25
assert .10<=motion['withers_peak_to_peak_m']<=.15
for leg in motion['legs'].values():assert abs(leg['fitted_stride_m']-7)<.03
assert motion['loop_max_vertex_difference']<1e-5
(root/'preview'/'assets').mkdir(parents=True,exist_ok=True)
(root/'preview'/'assets'/'horse.glb').write_bytes(raw)
print('REBUILD_PASS',hashlib.sha256(raw).hexdigest())
