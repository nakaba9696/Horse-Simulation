# Rebuild and verify

Python 3, Blender 4.3.2 and Godot 4.6.3 were used. Optional media tools require Pillow/ffmpeg; inspect_gltf.py requires NumPy. No Tripo API call or credit consumption is needed.

```
python tools/rebuild.py
python tools/rebuild.py --render  # optional CPU Cycles 1600×1000 images
python tools/configure_godot_import.py path/to/horse.glb.import
godot --headless --path preview --editor --import
godot --headless --path preview --script verify.gd
```

Rebuild starts from `source-rigged.glb`; intermediate `.blend` files are generated locally. Every Blender invocation uses `--python-exit-code 1`, and the final structure/motion assertions run before success. Blender binary exports are not guaranteed byte-identical across Blender versions. Verify semantic metrics as well as SHA256SUMS for the supplied files.

`measure.py` evaluates the final GLB at 241 phases per clip. Airborne means every hoof-region minimum is above 1.5 cm at scale 2.6; withers means the Spine_7 head, also exposed as the `Withers` marker. Fitted stride uses stance hoof-centroid X slope, not a claim of zero slip at every hoof vertex.

`verify.gd` checks actual Godot clips, loops, finite bones, Stand reset and UV2 regions, plus 60 fps sockets against the Blender JSON. Imported animation key optimization permits up to 2 mm for seat/stirrups and 7 mm for bit/withers at scale 2.6, and 0.01 radians orientation error. These are cross-export tolerances, not rider alignment tolerances for the game.

Run Godot normally with `godot --path preview` for visual inspection. Headless tests do not verify GPU rendering, LOD appearance, race integration or CPU time in the game.

`python tools/inspect_gltf.py` checks finite exported float accessors and unit base/corrective normals without changing the GLB. `python tools/make_media.py` builds the contact sheets and MP4 from rendered images.
