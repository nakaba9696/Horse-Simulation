import bpy,math,json
from pathlib import Path
from mathutils import Vector,Quaternion
P=Path(__file__).resolve().parent.parent
bpy.ops.wm.open_mainfile(filepath=str(P/'rest.blend'))
a=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');s=bpy.context.scene;s.render.fps=240
scale=2.6
specs={'RaceGallop_Loop':{'duration':.45,'frames':108,'stance':.20,'stride_m':7.,'lift':.18,'phases':[(1,'Right',0),(1,'Left',.195),(0,'Right',.390),(0,'Left',.585)]},'Stand_Loop':{'duration':3.,'frames':720,'stance':1.,'stride_m':0,'lift':0,'phases':[(1,'Right',0),(1,'Left',0),(0,'Right',0),(0,'Left',0)]},'Walk_Loop':{'duration':1.2,'frames':288,'stance':.62,'stride_m':1.6,'lift':.065,'phases':[(1,'Left',0),(0,'Left',.25),(1,'Right',.5),(0,'Right',.75)]}}
def h(t):
 t=t%1;points=[(0,.55),(.12,.65),(.28,.5),(.44,.35),(.58,.2),(.68,0),(.78,.4),(.90,1),(1,.55)]
 for (ta,va),(tb,vb) in zip(points,points[1:]):
  if ta<=t<=tb:
   u=(t-ta)/(tb-ta);u=u*u*(3-2*u);return va+(vb-va)*u
 return .55
def rotate(bn,angle,axis=(0,1,0)):
 b=a.pose.bones[bn];b.rotation_mode='QUATERNION';local=b.bone.matrix_local.to_3x3().inverted()@Vector(axis);b.rotation_quaternion=Quaternion(local,math.radians(angle))
a.animation_data_clear();actions={}
for clip,sp in specs.items():
 a.animation_data_create();a.animation_data.action=None
 for tr in a.animation_data.nla_tracks:tr.mute=True
 for b in a.pose.bones:b.matrix_basis.identity()
 targets=[];helpers=[]
 for group,side,phase in sp['phases']:
  b=a.pose.bones[f'tripo::{group}_{side}_Limb_2'];rest=b.bone.tail_local.copy()
  if clip!='Stand_Loop':rest.x=a.data.bones[f'tripo::{group}_{side}_Limb_0'].head_local.x
  rest.z+={(0,'Left'):.001,(0,'Right'):-.0016,(1,'Left'):-.0145,(1,'Right'):-.009}[(group,side)]
  target=bpy.data.objects.new('IK',None);s.collection.objects.link(target);helpers.append(target)
  ik=b.constraints.new('IK');ik.target=target;ik.chain_count=3;ik.iterations=100
  foot=a.pose.bones[f'tripo::{group}_{side}_Limb_3'];orient=bpy.data.objects.new('HoofOrientation',None);s.collection.objects.link(orient);helpers.append(orient);orient.rotation_mode='QUATERNION';orient.rotation_quaternion=(a.matrix_world@foot.bone.matrix_local).to_quaternion()
  cr=foot.constraints.new('COPY_ROTATION');cr.target=orient;cr.owner_space='WORLD';cr.target_space='WORLD'
  targets.append((target,rest,phase))
 frames=sp['frames'];s.frame_start=1;s.frame_end=frames+1
 for f in range(1,frames+2):
  t=(f-1)/frames;root=a.pose.bones['tripo::Root']
  if clip=='RaceGallop_Loop':offset=Vector((.006*math.sin(2*math.pi*(t-.3)),0,-.105+(.12/scale)*h(t)))
  elif clip=='Walk_Loop':offset=Vector((.001*math.sin(2*math.pi*t),0,-.045+.0015*(1-math.cos(4*math.pi*t))))
  else:offset=Vector((0,0,.0005*(1-math.cos(2*math.pi*t))))
  root.location=root.bone.matrix_local.to_3x3().inverted()@offset;root.keyframe_insert('location',frame=f)
  for target,rest,phase in targets:
   u=(t-phase)%1
   if clip=='Stand_Loop':dx=0;dz=0
   else:
    stroke=sp['stride_m']/scale*sp['stance']
    if u<sp['stance']:dx=-stroke/2+stroke*u/sp['stance'];dz=0
    else:q=(u-sp['stance'])/(1-sp['stance']);ease=q*q*(3-2*q);dx=stroke/2-stroke*ease;dz=sp['lift']*math.sin(math.pi*q)
   target.location=rest+Vector((dx,0,dz));target.keyframe_insert('location',frame=f)
  if clip=='RaceGallop_Loop':
   rotate('tripo::Spine_0',.8*math.sin(2*math.pi*(t-.05)))
   for bn,base,amp,lag in [('tripo::Spine_8',-15,2.5,.015),('tripo::Spine_9',-12,3,.035),('tripo::Head_0',-10,3,.05),('tripo::Head_4',45,2,.065),('tripo::Head_5',10,1,.08)]:rotate(bn,base+amp*(2*h(t-lag)-1))
   rotate('tripo::Tail_0',6*math.sin(2*math.pi*(t-.12)));rotate('tripo::Tail_1',3*math.sin(2*math.pi*(t-.2)),(0,0,1))
  elif clip=='Walk_Loop':
   for bn,base,amp,lag in [('tripo::Spine_8',-3,1,.0),('tripo::Spine_9',-2,1.3,.04),('tripo::Head_0',-1,2,.08),('tripo::Head_4',6,1,.12)]:rotate(bn,base+amp*math.sin(4*math.pi*(t-lag)))
   rotate('tripo::Tail_0',2*math.sin(2*math.pi*t),(0,0,1))
  else:
   rotate('tripo::Tail_0',2*math.sin(2*math.pi*t),(0,0,1));rotate('tripo::Head_6',2*math.sin(2*math.pi*t));rotate('bone_20',1.5*math.sin(2*math.pi*(t-.15)))
  for bn in ['tripo::Spine_0','tripo::Spine_8','tripo::Spine_9','tripo::Head_0','tripo::Head_4','tripo::Head_5','tripo::Head_6','bone_20','tripo::Tail_0','tripo::Tail_1']:
   a.pose.bones[bn].keyframe_insert('rotation_quaternion',frame=f)
 bpy.ops.object.select_all(action='DESELECT');a.select_set(True);bpy.context.view_layer.objects.active=a
 bpy.ops.nla.bake(frame_start=1,frame_end=frames+1,step=1,only_selected=False,visual_keying=True,clear_constraints=True,clear_parents=False,use_current_action=False,bake_types={'POSE'})
 act=a.animation_data.action;act.name=clip;act.use_fake_user=True
 for fc in act.fcurves:
  if len(fc.keyframe_points)>1:
   fc.keyframe_points[-1].co.y=fc.keyframe_points[0].co.y
  for k in fc.keyframe_points:k.interpolation='LINEAR'
 actions[clip]=act
 for helper in helpers:bpy.data.objects.remove(helper,do_unlink=True)
 a.animation_data.action=None
 tr=a.animation_data.nla_tracks.new();tr.name=clip;tr.strips.new(clip,1,act);tr.mute=True
 print('CLIP_BAKED',clip,flush=True)
a.animation_data.action=actions['Stand_Loop'];s.frame_start=1;s.frame_end=721;s.frame_set(1)
bpy.ops.wm.save_as_mainfile(filepath=str(P/'animated.blend'))
(P/'animation-specs.json').write_text(json.dumps(specs,indent=2));print('ANIMATIONS_READY')
