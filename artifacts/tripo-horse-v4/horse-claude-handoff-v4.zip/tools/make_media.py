"""Optional: Python Pillow and ffmpeg, after render.py."""
from pathlib import Path
from PIL import Image,ImageDraw
import subprocess
p=Path(__file__).resolve().parent.parent
renders=p if (p/'race-side-000.png').exists() else p/'renders'
ext='png' if (renders/'race-side-000.png').exists() else 'jpg'
for name,ids,cols,rows,panel in [('run-sheet',[0,3,7,10,14,17,21,24],4,2,(400,500)),('side-28-sheet',list(range(28)),7,4,(400,250))]:
 w,h=panel;sheet=Image.new('RGB',(cols*w,rows*h),(15,20,22));draw=ImageDraw.Draw(sheet)
 for j,i in enumerate(ids):
  im=Image.open(renders/f'race-side-{i:03}.{ext}').convert('RGB');im.thumbnail((w,h-30));x=(j%cols)*w+(w-im.width)//2;y=(j//cols)*h+(h-im.height)//2;sheet.paste(im,(x,y));draw.text(((j%cols)*w+8,(j//cols)*h+8),f'{i}/27  {i/60:.3f}s',fill='white')
 sheet.save(p/(name+'.jpg'),quality=93)
subprocess.run(['ffmpeg','-y','-framerate','60','-i',str(renders/('race-side-%03d.'+ext)),'-vf','trim=end_frame=27,loop=loop=7:size=27:start=0,setpts=N/(60*TB),format=yuv420p','-frames:v','216','-c:v','libx264','-crf','20','-movflags','+faststart',str(p/'gallop-preview.mp4')],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
