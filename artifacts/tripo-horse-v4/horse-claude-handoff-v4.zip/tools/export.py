import bpy,json,struct
from pathlib import Path
P=Path(__file__).resolve().parent.parent
bpy.ops.wm.open_mainfile(filepath=str(P/'horse-gallop.blend'))
for obj in bpy.context.scene.objects:
 if obj.animation_data:
  obj.animation_data.action=None
  for track in obj.animation_data.nla_tracks:track.mute=False
 if obj.type=='MESH' and obj.data.shape_keys and obj.data.shape_keys.animation_data:
  obj.data.shape_keys.animation_data.action=None
  for track in obj.data.shape_keys.animation_data.nla_tracks:track.mute=False
bpy.context.scene.frame_set(1);bpy.context.view_layer.update()
bpy.ops.export_scene.gltf(filepath=str(P/'horse-gallop.glb'),export_format='GLB',export_animations=True,export_skins=True,export_extras=True,export_animation_mode='NLA_TRACKS',export_frame_range=False,export_force_sampling=True)
# Shift each clip to time zero while retaining each NLA track's name and duration.
p=P/'horse-gallop.glb';b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);payload=bytearray(b[28+n:]);seen=set()
for clip in d.get('animations',[]):
 for sm in clip['samplers']:
  i=sm['input']
  if i in seen:continue
  seen.add(i);access=d['accessors'][i];view=d['bufferViews'][access['bufferView']];off=view.get('byteOffset',0)+access.get('byteOffset',0);values=list(struct.unpack_from('<'+'f'*access['count'],payload,off));zero=values[0];values=[v-zero for v in values];struct.pack_into('<'+'f'*len(values),payload,off,*values);access['min']=[min(values)];access['max']=[max(values)]
# Recompute welded normals for both base and corrective shapes. UV seams must not
# become shading creases after a morph changes the neck surface.


js=json.dumps(d,separators=(',',':')).encode();js+=b' '*((-len(js))%4);payload+=b'\0'*((-len(payload))%4);p.write_bytes(struct.pack('<III',0x46546c67,2,28+len(js)+len(payload))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(payload),0x004e4942)+payload)
summary={clip['name']:{'duration':max(d['accessors'][sm['input']]['max'][0] for sm in clip['samplers']),'channels':len(clip['channels']),'morph_channels':sum(c['target']['path']=='weights' for c in clip['channels'])} for clip in d.get('animations',[])}
print('EXPORTED_CLIPS',json.dumps(summary));(P/'export-info.json').write_text(json.dumps(summary,indent=2))
assert set(summary)=={'RaceGallop_Loop','Stand_Loop','Walk_Loop'},summary
assert len(d['skins'][0]['joints'])==54
for name,expected in [('RaceGallop_Loop',.45),('Stand_Loop',3.),('Walk_Loop',1.2)]:assert abs(summary[name]['duration']-expected)<1e-4
