import bpy,json,re,math
from pathlib import Path
from mathutils import Vector
P=Path(__file__).resolve().parent.parent
bpy.ops.wm.open_mainfile(filepath=str(P/'geometry.blend'))
o=next(x for x in bpy.context.scene.objects if x.type=='MESH' and len(x.data.vertices)>1000)
REGIONS=['body','mane','tail','hoof','muzzle','eye','face_mark_eligible','inner_ear']
counts={name:0 for name in REGIONS};face_ids=[];leg_ids=[]
K=json.loads((P/'build-info.json').read_text())['shorten_x']
hair_info=json.loads((P/'hair-face-regions.json').read_text())
uv=o.data.uv_layers.get('CoatRegions') or o.data.uv_layers.new(name='CoatRegions')
vg_names={g.index:g.name for g in o.vertex_groups}
# Conservative spatial seeds on the rest mesh; not a texture inferred from animation poses.
crest=json.loads((P/'mane-crest.json').read_text())
def crest_z(x):
 for (x0,z0),(x1,z1) in zip(crest,crest[1:]):
  if x0<=x<=x1:return z0+(z1-z0)*(x-x0)/(x1-x0)
 return crest[0][1] if x<crest[0][0] else crest[-1][1]
def smooth(lo,hi,value):
 t=max(0,min(1,(value-lo)/(hi-lo)));return t*t*(3-2*t)
for poly in o.data.polygons:
 verts=[o.data.vertices[i] for i in poly.vertices];v=sum((x.co for x in verts),Vector())/len(verts);x,y,z=v;x/=K
 weights={}
 for vertex in verts:
  for g in vertex.groups:weights[vg_names[g.group]]=weights.get(vg_names[g.group],0)+g.weight/len(verts)
 tail=sum(w for name,w in weights.items() if name.startswith('tripo::Tail') or name in ['bone_35','bone_36','bone_37','bone_38','bone_39','bone_43'])
 legs={}
 for name,w in weights.items():
  m=re.fullmatch(r'tripo::([01])_(Left|Right)_Limb_\d+',name)
  if m:
   k=1+int(m[1])*2+(m[2]=='Right');legs[k]=legs.get(k,0)+w
 leg=max(legs,key=legs.get) if legs and max(legs.values())>.30 else 0
 near_poll=(-.395<x<-.305 and .775<z<.815 and abs(y)<.045)
 region=0
 if tail>.50 and x>.33:region=2
 elif leg and z<.055:region=3
 elif near_poll or (-.36<x<-.055 and crest_z(x)-.027<z<crest_z(x)+.010 and abs(y)<.065):region=1
 elif x<-.445 and .54<z<.69:region=4
 elif ((x+.372)/.022)**2+((abs(y)-.040)/.020)**2+((z-.742)/.022)**2<1:region=5
 elif x<-.355 and abs(y)<.011 and .625<z<.785:region=6
 elif z>.81 and abs(y)<.05 and poly.normal.y*y<0:region=7
 is_tuft=poly.index>=hair_info['first_polygon']
 if is_tuft:region=hair_info['regions'][poly.index-hair_info['first_polygon']];leg=0
 counts[REGIONS[region]]+=1;face_ids.append(region);leg_ids.append(leg)
 for li in poly.loop_indices:
  vz=o.data.vertices[o.data.loops[li].vertex_index].co.z;height=max(0,min(1,vz/.45));packed_y=(leg+.15+.7*height)/8
  # glTF exporter flips V; store 1-y so glTF/Godot receive packed_y.
  weight=.5
  if region==1:
   pt=o.data.vertices[o.data.loops[li].vertex_index].co;crest_height=crest_z(pt.x/K)
   weight=max(smooth(crest_height-.07,crest_height-.035,pt.z)*smooth(.02,.06,abs(pt.y)),smooth(crest_height-.025,crest_height+.005,pt.z))
  if region==1:weight=1.0
  uv.data[li].uv=((region+.1+.8*weight)/8,1-packed_y)
o.data.uv_layers.active_index=0
schema={'version':1,'attribute':'TEXCOORD_1 / Godot UV2','region_id':'floor(UV2.x*8)','mane_blend':'clamp((fract(UV2.x*8)-0.1)/0.8,0,1)','leg_id':'floor(UV2.y*8)','rest_height_model':'clamp((fract(UV2.y*8)-0.15)/0.7,0,1)*0.45','regions':dict(enumerate(REGIONS)),'legs':{'0':'none','1':'left_fore','2':'right_fore','3':'left_hind','4':'right_hind'},'polygon_counts':counts,'tack_materials':['Bridle_Leather','Bridle_Metal'],'hair_tufts':50,'notes':['Classified in rest pose, so regions remain attached during animation.','Face mark eligibility is a seed strip, not an accurate real-horse white marking.','Mane/body and tail/body boundaries require visual art review.']}
o['coat_region_schema']=json.dumps(schema,separators=(',',':'))
(P/'coat-region-schema.json').write_text(json.dumps(schema,indent=2));(P/'coat-face-ids.json').write_text(json.dumps({'regions':face_ids,'legs':leg_ids}))
bpy.ops.wm.save_as_mainfile(filepath=str(P/'regions.blend'));print('REGION_COUNTS',json.dumps(counts))
