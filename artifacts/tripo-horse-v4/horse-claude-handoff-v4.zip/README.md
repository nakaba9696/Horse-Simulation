# Tripo Horse v4

V4の依頼に対応した比較用素材です。導入前に **CLAUDE_HANDOFF.md** を読んでください。

- 最終モデル: `horse-gallop.glb`
- 編集用: `horse-gallop.blend`、原本: `source-rigged.glb`
- 独立プレビュー: `preview/project.godot`
- 騎手用: `saddle-track.json`、全クリップの取付点: `attachment-tracks.json`
- 測定: `motion-validation.json`、`godot-validation.json`
- 画像: `renders/`、8コマ: `run-sheet.jpg`
- 再生成: `python tools/rebuild.py`、検証: `tools/README.md`

滞空20%、き甲上下約11.9cm、完歩約7m。Stand・Walk・Raceと6取付点を収録。首・肩や毛の細部は調整余地が残る試作です。ゲーム本体へは未組み込み。
