extends SceneTree
func _initialize(): call_deferred("run_checks")
func bone_snapshot(skeleton: Skeleton3D) -> Array:
 var out=[]
 for i in range(skeleton.get_bone_count()): out.append(skeleton.get_bone_global_pose(i))
 return out
func pose_update(player: AnimationPlayer, skeleton: Skeleton3D, time: float) -> void:
 player.seek(time,true)
 player.advance(0)
 skeleton.force_update_all_bone_transforms()
 for attachment in skeleton.find_children("*","BoneAttachment3D",true,false):
  if attachment.has_method("on_skeleton_update"): attachment.on_skeleton_update()
func run_checks():
 var scene=load("res://main.tscn").instantiate()
 root.add_child(scene)
 await process_frame
 var player: AnimationPlayer=scene.player
 player.callback_mode_process=AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL
 var skels=scene.model.find_children("*","Skeleton3D",true,false)
 assert(skels.size()==1)
 var skeleton: Skeleton3D=skels[0]
 print("SKELETON_BONES ",skeleton.get_bone_count())
 assert(skeleton.get_bone_count()==54)
 var horse=scene.model.find_child("Horse",true,false) as MeshInstance3D
 assert(horse!=null and horse.mesh.get_blend_shape_count()==1)
 var region_ids={};var leg_ids={}
 var arrays=horse.mesh.surface_get_arrays(0)
 for uv in arrays[Mesh.ARRAY_TEX_UV2]:
  var region=int(floor(uv.x*8.0));var leg=int(floor(uv.y*8.0))
  assert(region>=0 and region<8 and leg>=0 and leg<5)
  region_ids[region]=region_ids.get(region,0)+1
  leg_ids[leg]=leg_ids.get(leg,0)+1
 assert(region_ids.size()==8 and leg_ids.size()==5)
 var sockets={}
 for key in ["Saddle","Stirrup_L","Stirrup_R","Bit_L","Bit_R","Withers"]:
  var node=scene.model.find_child(key,true,false) as Node3D
  assert(node!=null,"Missing socket "+key)
  sockets[key]=node
 var records={}
 for clip in ["Stand","Walk","Trot","Canter","RaceGallop"]:
  assert(player.has_animation(clip))
  var animation=player.get_animation(clip)
  assert(animation.loop_mode==Animation.LOOP_LINEAR)
  player.play(clip,0)
  pose_update(player,skeleton,0)
  var initial=bone_snapshot(skeleton);var max_loop_error=0.0
  for sample in range(1,1921):
   player.advance(animation.length/96.0)
   skeleton.force_update_all_bone_transforms()
   for index in range(skeleton.get_bone_count()):assert(skeleton.get_bone_global_pose(index).origin.is_finite())
   if sample%96==0:
    var current=bone_snapshot(skeleton)
    for index in range(current.size()):max_loop_error=max(max_loop_error,current[index].origin.distance_to(initial[index].origin))
  assert(max_loop_error<0.0001)
  var expected=0.0 if clip in ["Stand","Walk"] else 1.0
  assert(is_equal_approx(horse.get_blend_shape_value(0),expected))
  records[clip]={"duration":animation.length,"loop_error":max_loop_error,"samples":1920,"morph":horse.get_blend_shape_value(0),"tracks":animation.get_track_count()}
 # A complete Stand pose must be restored after leaving RaceGallop.
 player.play("Stand",0);pose_update(player,skeleton,0.3);var stand=bone_snapshot(skeleton)
 player.play("RaceGallop",0);pose_update(player,skeleton,0.22)
 scene.play_clip("Stand");player.advance(0)
 for step in range(30): player.advance(0.01)
 skeleton.force_update_all_bone_transforms()
 var restored=bone_snapshot(skeleton);var switch_error=0.0
 for index in range(restored.size()):switch_error=max(switch_error,restored[index].origin.distance_to(stand[index].origin))
 print("STAND_SWITCH_ERROR ",switch_error," POSITION ",player.current_animation_position)
 if switch_error>0.0001:
  for index in range(restored.size()):
   if restored[index].origin.distance_to(stand[index].origin)>0.01: print("DIFF ",skeleton.get_bone_name(index)," ",restored[index].origin.distance_to(stand[index].origin))
 assert(switch_error<0.0001)
 assert(is_zero_approx(horse.get_blend_shape_value(0)))
 var source=JSON.parse_string(FileAccess.get_file_as_string("res://../saddle-track.json"))
 var worst_socket=0.0;var worst_angle=0.0
 var per_socket={}
 var run_animation=player.get_animation("RaceGallop")
 for track in range(run_animation.get_track_count()):
  if str(run_animation.track_get_path(track)).ends_with(":tripoRoot"):
   print("ROOT_TRACK_KEYS ",run_animation.track_get_key_count(track)," FIRST ",run_animation.track_get_key_time(track,1))
 player.play("RaceGallop",0)
 for sample in source.samples:
  pose_update(player,skeleton,float(sample.time_seconds))
  await process_frame
  await process_frame
  for key in sockets:
   var node: Node3D=sockets[key]
   var transform=scene.model.global_transform.affine_inverse()*node.global_transform
   var expected=sample.nodes[key].position_model
   var error=transform.origin.distance_to(Vector3(expected[0],expected[1],expected[2]))
   per_socket[key]=max(per_socket.get(key,0.0),error)
   worst_socket=max(worst_socket,error)
   var quat=sample.nodes[key].quaternion_xyzw
   worst_angle=max(worst_angle,transform.basis.get_rotation_quaternion().angle_to(Quaternion(quat[0],quat[1],quat[2],quat[3])))
 print("SOCKET_ERROR ",worst_socket," ROTATION ",worst_angle," BY_NODE ",JSON.stringify(per_socket))
 for key in per_socket:
  var tolerance_m=0.002 if key in ["Saddle","Stirrup_L","Stirrup_R"] else 0.007
  assert(per_socket[key]*2.6<tolerance_m)
 assert(worst_angle<0.01)
 scene.toggle_markers();assert(scene.marker_visuals.size()==6)
 var result={"bones":54,"clips":records,"regions":region_ids,"legs":leg_ids,"stand_switch_error":switch_error,"socket_max_position_error":worst_socket,"socket_max_angle_error_radians":worst_angle,"socket_count":sockets.size(),"socket_position_error_model_by_node":per_socket,"reference_scale":2.6,"seat_tolerance_m":0.002,"other_socket_tolerance_m":0.007}
 var file=FileAccess.open("res://../godot-validation.json",FileAccess.WRITE)
 file.store_string(JSON.stringify(result,"\t"));print(JSON.stringify(result));quit()
