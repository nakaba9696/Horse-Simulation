# v5 の再生成と検証

Blender 4.3.2 / Godot 4.6.3 / Python 3.12 で確認。ゲームプロジェクトは使用しません。

```sh
python -m venv .venv
. .venv/bin/activate
pip install -r tools/requirements.txt
python tools/rebuild.py --blender blender --godot godot
```

同梱の `source-rigged.glb` と `v4-socket-rest.json` が必須。外部 API 呼び出し・生成課金はありません。
`repair_surface.py` は Blender 外の Python を使うため、runner が `HORSE_REPAIR_PYTHON` に現在の Python を渡します。
各 Blender ステージは `--python-exit-code 1`、各数値検証は assertion で失敗を通知します。

実画面撮影は表示環境で `--render` を追加。Linux の無画面環境では Xvfb とソフトウェア OpenGL を利用できます。
`capture.gd -- --full` は 133 枚の 1600×1000 画像を生成します。`make_media.py` はシート・動画・法線監査 JSON を作ります。
`probe.py` / `render.py` は補助的な Blender 確認用で、納品の実画面証拠は Godot 撮影です。

Godot の import は AnimationPlayer ノードの optimizer を無効にし、240fps・不変トラック保持・UV2 保持で行います。
`configure_godot_import.py` は独立 preview 用。既存ゲームに独自 `_subresources` がある場合は上書きせず、CLAUDE_HANDOFF.md に従い手で設定をマージしてください。
