import bpy,math,json,re
from pathlib import Path
from mathutils import Vector,Matrix
from mathutils.kdtree import KDTree
from mathutils.bvhtree import BVHTree
P=Path(__file__).resolve().parent.parent;bpy.ops.wm.open_mainfile(filepath=str(P/'animated.blend'))
s=bpy.context.scene;a=next(o for o in s.objects if o.type=='ARMATURE');horse=next(o for o in s.objects if o.type=='MESH' and len(o.data.vertices)>1000)
K=json.loads((P/'build-info.json').read_text())['shorten_x'];N=len(horse.data.vertices)
coords=[v.co.copy() for v in horse.data.vertices];polys=[list(p.vertices) for p in horse.data.polygons];bvh=BVHTree.FromPolygons(coords,polys,all_triangles=False);kd=KDTree(N)
for i,c in enumerate(coords):kd.insert(c,i)
kd.balance();names=[g.name for g in horse.vertex_groups];weights=[{names[g.group]:g.weight for g in v.groups} for v in horse.data.vertices]
root_uv={}
for loop in horse.data.loops:root_uv.setdefault(loop.vertex_index,horse.data.uv_layers[0].data[loop.index].uv.copy())
base_uv_name=horse.data.uv_layers[0].name
material=horse.data.materials[0]
for node in material.node_tree.nodes:
 if node.type=='BSDF_PRINCIPLED':node.inputs['Roughness'].default_value=.8
 if node.type=='NORMAL_MAP':node.inputs['Strength'].default_value=.03

def source_point(p):
 hit=bvh.find_nearest(Vector(p));return hit[0] if hit and hit[0] is not None else Vector(p)
def new_mesh(name,verts,faces,roots,mat,regions=None):
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update();obj=bpy.data.objects.new(name,mesh);s.collection.objects.link(obj);obj.parent=horse.parent;obj.matrix_world=horse.matrix_world.copy()
 for n in names:obj.vertex_groups.new(name=n)
 for i,root in enumerate(roots):
  if name.startswith('Bridle'):obj.vertex_groups['tripo::Head_5'].add([i],1.0,'REPLACE')
  else:
   for group_name,w in weights[root].items():obj.vertex_groups[group_name].add([i],w,'REPLACE')
 mod=obj.modifiers.new('Armature','ARMATURE');mod.object=a;mesh.materials.append(mat)
 for poly in mesh.polygons:poly.use_smooth=True
 uv0=mesh.uv_layers.new(name=base_uv_name)
 for poly in mesh.polygons:
  for local,li in enumerate(poly.loop_indices):uv0.data[li].uv=(local/max(1,len(poly.loop_indices)-1),.5)
 if regions is not None:
  uv2=mesh.uv_layers.new(name='CoatRegions')
  for poly,region in zip(mesh.polygons,regions):
   for li in poly.loop_indices:
    height=max(0,min(1,mesh.vertices[mesh.loops[li].vertex_index].co.z/.45));uv2.data[li].uv=((region+.9)/8,1-(.15+.7*height)/8)
 return obj
# Closed, flattened rounded locks: rest against one side of the neck rather than spikes.
verts=[];faces=[];roots=[];region_ids=[];tuft_count=0

def tuft(root,mid,tip,width,region):
 global tuft_count
 tuft_count+=1;root=Vector(root);mid=Vector(mid);tip=Vector(tip);root_id=kd.find(root)[1];start=len(verts)
 # Six-sided flattened cross sections, with a broad middle and a gathered tip.
 axis=(tip-root).normalized();side=axis.cross(Vector((0,1,0)))
 if side.length<.01:side=Vector((1,0,0))
 side.normalize();normal=axis.cross(side).normalized()
 for center,w in [(root,width*.65),(mid,width),(tip.lerp(mid,.12),width*.25)]:
  for j in range(6):
   theta=j*2*math.pi/6;verts.append(center+side*w*math.cos(theta)+normal*w*.24*math.sin(theta));roots.append(kd.find(verts[-1])[1])
 verts.append(tip);roots.append(kd.find(verts[-1])[1])
 local=[]
 for ring in range(2):
  for j in range(6):k=(j+1)%6;local.extend([(ring*6+j,ring*6+k,(ring+1)*6+k),(ring*6+j,(ring+1)*6+k,(ring+1)*6+j)])
 for j in range(1,5):local.append((0,j+1,j))
 for j in range(6):local.append((12+j,12+(j+1)%6,18))
 for face in local:faces.append(tuple(start+i for i in face));region_ids.append(region)

mane_crest=[]
for i in range(24):
 x=(-.34+i*.25/23)*K;hit=bvh.ray_cast(Vector((x,0,1.15)),Vector((0,0,-1)));root=hit[0] if hit[0] is not None else source_point((x,0,.70));mane_crest.append([x/K,float(root.z)])
 root+=Vector((0,-.001,.0008));mid=source_point((x+.003,-.037,root.z-.028))+Vector((0,-.003,0));tip=source_point((x+.014,-.048,root.z-.070-.009*math.sin(i*.9)**2))+Vector((0,-.002,0))
 tuft(root,mid,tip,.0095,1)
for i in range(6):
 root=source_point(((-.345+.004*i)*K,-.008+.003*i,.795));mid=source_point((root.x-.014,root.y,root.z-.019))+Vector((-.001,-.001,0));tip=source_point((root.x-.025,root.y,root.z-.041))+Vector((-.001,0,0));tuft(root,mid,tip,.006,1)
for i in range(8):
 theta=i*2*math.pi/8;root=source_point((.44*K+.004*math.cos(theta),.010*math.sin(theta),.22+.009*(i%3)));tip=root+Vector((.012,.013*math.sin(theta),-.090-.009*(i%3)));mid=root.lerp(tip,.55)+Vector((.002,0,0));tuft(root,mid,tip,.006,2)
# A thin closed underlay keeps the locks continuous without orange islands.
underlay_start=len(verts)
for i,(x_source,z_crest) in enumerate(mane_crest):
 x=x_source*K;root=source_point((x,0,z_crest));bottom=source_point((x+.006,-.050,root.z-.052))
 for point in [root+Vector((0,-.003,.0007)),root+Vector((0,.001,.0007)),bottom+Vector((0,.001,0)),bottom+Vector((0,-.003,0))]:
  verts.append(point);roots.append(kd.find(point)[1])
for i in range(23):
 for j in range(4):
  k=(j+1)%4;a0=underlay_start+i*4+j;b0=underlay_start+i*4+k;c0=underlay_start+(i+1)*4+k;d0=underlay_start+(i+1)*4+j;faces.extend([(a0,b0,c0),(a0,c0,d0)]);region_ids.extend([1,1])
faces.extend([(underlay_start,underlay_start+2,underlay_start+1),(underlay_start,underlay_start+3,underlay_start+2)])
last=underlay_start+23*4;faces.extend([(last,last+1,last+2),(last,last+2,last+3)]);region_ids.extend([1,1,1,1])
hair=new_mesh('HairTufts',verts,faces,roots,material,region_ids)
# Save the exact post-join mapping for corrective-shape propagation to each tuft.
bpy.ops.object.select_all(action='DESELECT');horse.select_set(True);hair.select_set(True);bpy.context.view_layer.objects.active=horse;bpy.ops.object.join()
hair_roots={str(N+i):root for i,root in enumerate(roots)};horse['hair_root_vertices']=json.dumps(hair_roots)
horse['base_vertex_count']=N
(P/'mane-crest.json').write_text(json.dumps(mane_crest,indent=2))
(P/'hair-roots.json').write_text(json.dumps(hair_roots));(P/'hair-face-regions.json').write_text(json.dumps({'first_polygon':len(polys),'regions':region_ids}))
# Leather and metal use separate materials, not coat region 7.
leather=bpy.data.materials.new('Bridle_Leather');leather.use_nodes=True;leather.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(.035,.018,.010,1);leather.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.73
metal=bpy.data.materials.new('Bridle_Metal');metal.use_nodes=True;metal.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(.25,.24,.22,1);metal.node_tree.nodes['Principled BSDF'].inputs['Metallic'].default_value=.75;metal.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.3
lv=[];lf=[];lr=[]
def beam(p0,p1,width=.0035,thickness=.0015):
 p0=Vector(p0);p1=Vector(p1);axis=(p1-p0).normalized();u=axis.cross(Vector((0,0,1)))
 if u.length<.01:u=Vector((0,1,0))
 u.normalize();v=axis.cross(u).normalized();start=len(lv)
 for center in [p0,p1]:
  for su,sv in [(-1,-1),(1,-1),(1,1),(-1,1)]:
   pt=center+u*su*width/2+v*sv*thickness/2;lv.append(pt);lr.append(kd.find(pt)[1])
 for j in range(4):k=(j+1)%4;lf.extend([(start+j,start+k,start+k+4),(start+j,start+k+4,start+j+4)])
 lf.extend([(start,start+2,start+1),(start,start+3,start+2),(start+4,start+5,start+6),(start+4,start+6,start+7)])
def band(center,axis):
 center=Vector(center);axis=Vector(axis).normalized();u=Vector((0,1,0));v=axis.cross(u).normalized();ring=[]
 for j in range(16):
  direction=math.cos(j*2*math.pi/16)*u+math.sin(j*2*math.pi/16)*v;hit=bvh.ray_cast(center,direction,.14)
  point=hit[0] if hit[0] is not None else source_point(center+direction*.045)
  ring.append(point+direction*.0022)
 for one,two in zip(ring,ring[1:]+ring[:1]):beam(one,two,.004,.0012)
band((-.451*K,0,.632),(-.55,0,-.83));band((-.357*K,0,.756),(-.55,0,-.83))
bit_points={'Bit_L':Vector((-.465*K,-.039,.604)),'Bit_R':Vector((-.465*K,.039,.604))}
for side,sign in [('L',-1),('R',1)]:
 points=[source_point((-.335*K,sign*.034,.79))+Vector((0,sign*.002,0)),source_point((-.374*K,sign*.046,.727))+Vector((0,sign*.003,0)),bit_points['Bit_'+side]]
 for one,two in zip(points,points[1:]):beam(one,two,.004,.0015)
new_mesh('BridleLeather',lv,lf,lr,leather)
mv=[];mf=[];mr=[]
for center in bit_points.values():
 start=len(mv)
 for j in range(8):
  theta=j*2*math.pi/8
  for k in range(3):
   phi=k*2*math.pi/3;pt=center+Vector(((.008+.0013*math.cos(phi))*math.cos(theta),.0013*math.sin(phi),(.008+.0013*math.cos(phi))*math.sin(theta)));mv.append(pt);mr.append(kd.find(pt)[1])
 for j in range(8):
  for k in range(3):i=start+j*3+k;ii=start+((j+1)%8)*3+k;jn=start+j*3+(k+1)%3;jjn=start+((j+1)%8)*3+(k+1)%3;mf.extend([(i,ii,jjn),(i,jjn,jn)])
start=len(mv)
for end in [bit_points['Bit_L'],bit_points['Bit_R']]:
 for j in range(6):
  pt=end+Vector((.0013*math.cos(j*2*math.pi/6),0,.0013*math.sin(j*2*math.pi/6)));mv.append(pt);mr.append(kd.find(pt)[1])
for j in range(6):k=(j+1)%6;mf.extend([(start+j,start+k,start+k+6),(start+j,start+k+6,start+j+6)])
for j in range(1,5):mf.extend([(start,start+j+1,start+j),(start+6,start+6+j,start+6+j+1)])
new_mesh('BridleMetal',mv,mf,mr,metal)
# Bone-parented sockets retain the model's -X forward / +Z up rest orientation.
def marker(name,rest_point,bone):
 obj=bpy.data.objects.new(name,None);s.collection.objects.link(obj);obj.empty_display_type='PLAIN_AXES';obj.empty_display_size=.025;obj.parent=a;obj.parent_type='BONE';obj.parent_bone=bone;bpy.context.view_layer.update()
 obj.matrix_world=a.matrix_world@a.pose.bones[bone].matrix@a.data.bones[bone].matrix_local.inverted()@Matrix.Translation(rest_point)
 return obj
old_sockets=json.loads((P/'v4-socket-rest.json').read_text())['nodes']
def old_rest(name):
 p=old_sockets[name]['position_model'];return Vector((p[0],-p[2],p[1]))
saddle=old_rest('Saddle');back=saddle-Vector((0,0,.015))
marker('Saddle',saddle,'tripo::Spine_3')
marker('Stirrup_L',back+Vector((-.015,-.085,-.045)),'tripo::Spine_3');marker('Stirrup_R',back+Vector((-.015,.085,-.045)),'tripo::Spine_3')
for name,pt in bit_points.items():marker(name,pt,'tripo::Head_5')
marker('Withers',a.data.bones['tripo::Spine_7'].head_local,'tripo::Spine_7')
import bmesh
for obj in s.objects:
 if obj.type=='MESH':
  bm=bmesh.new();bm.from_mesh(obj.data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(obj.data);bm.free()
summary={}
for obj in s.objects:
 if obj.type=='MESH':obj.data.calc_loop_triangles();summary[obj.name]={'vertices':len(obj.data.vertices),'triangles':len(obj.data.loop_triangles)}
(P/'geometry-report.json').write_text(json.dumps({'meshes':summary,'total_triangles':sum(v['triangles'] for v in summary.values()),'hair_tufts':tuft_count,'sockets':['Saddle','Stirrup_L','Stirrup_R','Bit_L','Bit_R','Withers'],'socket_rest_blender':{'Saddle':list(saddle),'Stirrup_L':list(back+Vector((-.015,-.085,-.045))),'Stirrup_R':list(back+Vector((-.015,.085,-.045)))},'neutral_body_length_m':(max(v.co.x for v in horse.data.vertices[:N])-min(v.co.x for v in horse.data.vertices[:N]))*2.6},indent=2))
bpy.ops.wm.save_as_mainfile(filepath=str(P/'geometry.blend'));print('GEOMETRY_READY',summary)
