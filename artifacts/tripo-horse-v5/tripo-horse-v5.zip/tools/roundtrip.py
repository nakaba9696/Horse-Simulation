"""Compare evaluated Blender vertices with the final GLB reimport, all five clips."""
import bpy,json
from pathlib import Path
from mathutils.kdtree import KDTree
P=Path(__file__).resolve().parent.parent
names=['RaceGallop_Loop','Stand_Loop','Walk_Loop','Trot_Loop','Canter_Loop'];specs=json.loads((P/'animation-specs.json').read_text());snapshots={}
bpy.ops.wm.open_mainfile(filepath=str(P/'horse-gallop.blend'))
a=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');horse=next(obj for obj in bpy.context.scene.objects if obj.type=='MESH' and len(obj.data.vertices)>1000);s=bpy.context.scene
for tr in a.animation_data.nla_tracks:tr.mute=True
horse.data.shape_keys.animation_data_clear()
for clip in names:
 a.animation_data.action=bpy.data.actions[clip];horse.data.shape_keys.key_blocks['RaceNeckCorrective'].value=0 if clip in ['Stand_Loop','Walk_Loop'] else 1
 for phase in [0,.25,.5,.75,1.]:
  frame=1+phase*specs[clip]['frames'];s.frame_set(int(frame),subframe=frame-int(frame));ev=horse.evaluated_get(bpy.context.evaluated_depsgraph_get());mesh=ev.to_mesh();kd=KDTree(len(mesh.vertices))
  for v in mesh.vertices:kd.insert(horse.matrix_world@v.co,v.index)
  kd.balance();snapshots[(clip,phase)]=kd;ev.to_mesh_clear()
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.context.scene.render.fps=240;bpy.ops.import_scene.gltf(filepath=str(P/'horse-gallop.glb'));s=bpy.context.scene;a=next(o for o in s.objects if o.type=='ARMATURE');horse=next(obj for obj in bpy.context.scene.objects if obj.type=='MESH' and len(obj.data.vertices)>1000)
for tr in a.animation_data.nla_tracks:tr.mute=True
horse.data.shape_keys.animation_data_clear();results={}
for clip in names:
 a.animation_data.action=next(action for action in bpy.data.actions if action.name.startswith(clip) and any(fc.data_path.startswith('pose.bones') for fc in action.fcurves));horse.data.shape_keys.key_blocks['RaceNeckCorrective'].value=0 if clip in ['Stand_Loop','Walk_Loop'] else 1;worst=0
 for phase in [0,.25,.5,.75,1.]:
  frame=phase*specs[clip]['frames'];s.frame_set(int(frame),subframe=frame-int(frame));ev=horse.evaluated_get(bpy.context.evaluated_depsgraph_get());mesh=ev.to_mesh();kd=snapshots[(clip,phase)]
  worst=max(worst,max(kd.find(horse.matrix_world@v.co)[2] for v in mesh.vertices));ev.to_mesh_clear()
 results[clip]={'phases':5,'max_nearest_vertex_error_model':worst};print(clip,worst,flush=True);assert worst<.0001
(P/'roundtrip-validation.json').write_text(json.dumps({'tolerance_model':0.0001,'reference_scale':2.6,'tolerance_reason':'0.26 mm physical tolerance accommodates float32 glTF time and transform interpolation; no visual modeling allowance','method':'Final GLB skin/morph evaluation compared to Blender source at five phases of all clips; UV-split duplicate vertices matched by nearest source vertex','clips':results},indent=2))
