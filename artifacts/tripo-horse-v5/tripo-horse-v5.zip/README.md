# Tripo Horse v5

最初に `CLAUDE_HANDOFF.md` を読んでください。GLB のほか、付属シェーダの法線補正・鼻先とたてがみの色補間、Godot の AnimationPlayer optimizer 無効化も必要です。

`sha256sum -c SHA256SUMS` で全ファイルを確認できます。配布 ZIP 自体の SHA-256 はリポジトリ側 `artifacts/tripo-horse-v5/README.md` を参照してください。

`preview/project.godot` は独立プレビュー、`tools/README.md` は再生成・検証手順です。ゲーム本体は変更していません。残る見た目の課題・検証範囲は CLAUDE_HANDOFF.md に明記しています。
