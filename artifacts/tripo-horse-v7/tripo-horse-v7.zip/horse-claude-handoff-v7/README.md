# 馬モデル v7

最初に [CLAUDE_HANDOFF.md](CLAUDE_HANDOFF.md) を読んでください。ゲーム本体のコード・データは含みません。

実馬のPD写真と並べて首頭胴の量感と運動を見直し、低頭Walk、胴pitchと頭の相対安定、正面鼻孔と口線を修正しました。細い首の長さ倍率だけを合格理由にしていません。

- `horse-gallop.glb` / `.blend`: 最終。54骨、19,168三角形、5歩法、6取付点、2つの補正。
- `v6-rest.blend`: v6制作の閉鎖/比率修復済みの中間入力。`source-rigged.glb`: 利用者提供の元Tripo。`tools/README.md`: v6入力からv7の再制作手順。
- `preview/`: Godot 4.6.3 独立場面。シェーダの法線補正と**COLOR_0による鼻孔/口線、WalkNeckCorrective**も取り込んでください。
- `comparison/iteration-11/`: 同カメラ・照明・尺度・時刻のv5/v6/v7、全578原寸画像。v7の268枚は最終新規、固定v5/v6の310枚は条件/GLB/画像hashを検査して再利用。
- `godot-renders/`: 独立の単独カメラのPNG133枚（法線監査を含む）。共通比較カメラとは区別。
- `comparison-preview.mp4` / `gallop-preview.mp4`: 比較/単独走行。60fpsの8周期。
- `reference/`: 実馬PD写真、元ページ、所蔵メタデータと原典へのリンク。未知のCG動画・抽出画像は配布しません。
- `anatomy-comparison.json`: v5/v6/v7の同じ皮膚点による頭/首上線/下線弦とworld pitch。頭/上線の目安2:3に完全一致したという主張はせず、実測0.762、上線/頭約1.31と明記。
- `neck-line.json`, `saddle-track.json`, `attachment-tracks.json`, `*-validation.json`: 数値と検証範囲。
- `review/`: 途中差戻しと2名の最終画像レビュー。修正前後はルートの `walk-neck-before-after.jpg`, `walk-mane-before-after.jpg`, `face-before-after.jpg`。

最終比較画像はPNGからロスレスWebPへ変換し、各画像の復号RGBA全画素が一致することを検査しています。`image-conversion-validation.json` が元PNGと配布WebP双方のhashを対応付けます。`capture-manifest-original.json` とレビューのcoverage JSONは元PNG名/hashの監査記録を維持し、配布版capture-manifestとレビュー本文はWebP名を使います。

中間試作の原寸画像は抜粋で、レビューの全元画像を配布したとはしません。最終11の578原寸は全収録。画像の輪郭や陰影を加工して欠点を隠していません。PD比較の矩形crop/回転/左右反転と、未知の写真速度/完全時間同期ではない点は対応JSONに明示しています。

`sha256sum -c SHA256SUMS` で全収録ファイルを確認できます。ZIP全体のSHA-256は外側README。完全再生成は最終GLBと**バイト一致**しました。

画像レビューは独立素材として通過。近接の短い毛束・塗りによる鼻孔/口の簡略感、実馬より幾分立つ首/下垂する尾等は残件です。実ゲームの騎手/手綱干渉、歩法ブレンド、LOD/FPS、実時間動画再生を完了したとはしていません。全変形面の隠れた自己交差/裏返り0の証明とも区別します。
