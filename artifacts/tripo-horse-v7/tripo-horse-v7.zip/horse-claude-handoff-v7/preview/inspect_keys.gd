extends SceneTree
func _initialize():
 var scene=load("res://assets/horse.glb").instantiate()
 var player: AnimationPlayer=scene.find_children("*","AnimationPlayer",true,false)[0]
 var animation=player.get_animation("RaceGallop")
 print("TRACKS ",animation.get_track_count()," STEP ",animation.step)
 for index in range(min(15,animation.get_track_count())):
  var times=[]
  for key in range(min(4,animation.track_get_key_count(index))):times.append(animation.track_get_key_time(index,key))
  print(animation.track_get_path(index)," TYPE ",animation.track_get_type(index)," KEYS ",animation.track_get_key_count(index)," TIMES ",times)
 quit()
