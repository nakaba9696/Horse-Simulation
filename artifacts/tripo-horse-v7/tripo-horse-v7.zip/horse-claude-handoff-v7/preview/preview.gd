extends Node3D

var model_path: String="res://assets/horse.glb"
var marker_visuals: Array[Node3D] = []
var model: Node3D
var coat_material: ShaderMaterial
var player: AnimationPlayer
var camera: Camera3D
var status: Label
var pause_button: Button
var is_paused := false
var animation_name: StringName

func _ready() -> void:
 var horse := load(model_path).instantiate() as Node3D
 add_child(horse)
 for mesh_node in horse.find_children("*","MeshInstance3D",true,false):mesh_node.lod_bias=16.0
 model=horse
 coat_material = ShaderMaterial.new()
 coat_material.shader = load("res://coat.gdshader")
 for mesh_instance in horse.find_children("*", "MeshInstance3D", true, false):
  if mesh_instance.name != "Horse": continue
  var old_material = mesh_instance.mesh.surface_get_material(0) as StandardMaterial3D
  if old_material != null and old_material.normal_texture != null:
   coat_material.set_shader_parameter("normal_texture", old_material.normal_texture)
   coat_material.set_shader_parameter("has_normal_map", true)
   coat_material.set_shader_parameter("normal_strength", old_material.normal_scale)
  mesh_instance.material_override = coat_material
  for shape in range(mesh_instance.mesh.get_blend_shape_count()):
   if mesh_instance.mesh.get_blend_shape_name(shape) == "RaceNeckCorrective":
    mesh_instance.set_blend_shape_value(shape, 0.0)
 var players := horse.find_children("*", "AnimationPlayer", true, false)
 assert(players.size() == 1, "Expected one AnimationPlayer")
 player = players[0]
 for clip in player.get_animation_list():
  if clip != "RESET":
   animation_name = clip
   break
 if player.has_animation("Stand"): animation_name = "Stand"
 assert(not animation_name.is_empty(), "Missing stand animation")
 player.get_animation(animation_name).loop_mode = Animation.LOOP_LINEAR
 player.play(animation_name)
 player.seek(0,true)
 player.advance(0)
 var ground := MeshInstance3D.new()
 var plane := PlaneMesh.new()
 plane.size = Vector2(20, 20)
 ground.mesh = plane
 var mat := StandardMaterial3D.new()
 mat.albedo_color = Color(0.12, 0.15, 0.17)
 mat.roughness = 0.95
 ground.material_override = mat
 ground.position.y = -0.001
 add_child(ground)
 var environment := WorldEnvironment.new()
 environment.environment = Environment.new()
 environment.environment.background_mode = Environment.BG_COLOR
 environment.environment.background_color = Color(0.08, 0.10, 0.12)
 environment.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
 environment.environment.ambient_light_color = Color.WHITE
 environment.environment.ambient_light_energy = 0.7
 add_child(environment)
 var light := DirectionalLight3D.new()
 light.rotation_degrees = Vector3(-45, -35, 0)
 light.light_energy = 1.8
 light.shadow_enabled = true
 add_child(light)
 camera = Camera3D.new()
 camera.projection = Camera3D.PROJECTION_ORTHOGONAL
 camera.size = 1.8
 add_child(camera)
 set_view(Vector3(0, 0.65, 2.4))
 build_controls()
 build_markers()
 print("PREVIEW_READY ", animation_name, " duration=", player.get_animation(animation_name).length)

func set_view(position_value: Vector3) -> void:
 camera.position = position_value
 camera.look_at(Vector3(0, 0.38, 0), Vector3.UP)

func button(text: String, callback: Callable, parent: Node) -> Button:
 var result := Button.new()
 result.text = text
 result.custom_minimum_size = Vector2(150, 60)
 result.pressed.connect(callback)
 parent.add_child(result)
 return result

func build_controls() -> void:
 var layer := CanvasLayer.new()
 add_child(layer)
 var panel := VBoxContainer.new()
 panel.position = Vector2(24, 20)
 layer.add_child(panel)
 var title := Label.new()
 title.text = "馬モデル走行プレビュー（試作）"
 title.add_theme_font_size_override("font_size", 28)
 panel.add_child(title)
 var views := HBoxContainer.new()
 panel.add_child(views)
 button("側面", func(): set_view(Vector3(0, 0.65, 2.4)), views)
 button("正面", func(): set_view(Vector3(-2.4, 0.60, 0)), views)
 button("背面", func(): set_view(Vector3(2.4, 0.60, 0)), views)
 button("斜め", func(): set_view(Vector3(-1.8, 0.85, 1.8)), views)
 pause_button = button("一時停止", toggle_pause, views)
 var modes := HBoxContainer.new()
 panel.add_child(modes)
 button("立ち姿", func(): play_clip("Stand"), modes)
 button("常歩", func(): play_clip("Walk"), modes)
 button("速歩", func(): play_clip("Trot"), modes)
 button("駈歩", func(): play_clip("Canter"), modes)
 button("襲歩", func(): play_clip("RaceGallop"), modes)
 button("取付点", func(): toggle_markers(), modes)
 var coats := HBoxContainer.new()
 panel.add_child(coats)
 button("鹿毛", func(): apply_coat(Color(0.36,0.13,0.045), Color(0.018,0.012,0.008)), coats)
 button("栗毛", func(): apply_coat(Color(0.42,0.15,0.05), Color(0.16,0.055,0.018)), coats)
 button("芦毛", func(): apply_coat(Color(0.65,0.65,0.62), Color(0.20,0.20,0.18)), coats)
 button("領域の確認", func(): coat_material.set_shader_parameter("show_regions", not coat_material.get_shader_parameter("show_regions")), coats)
 var speed_label := Label.new()
 speed_label.text = "再生速度（移動速度との対応は未調整）"
 panel.add_child(speed_label)
 var speed := HSlider.new()
 speed.min_value = 0.25
 speed.max_value = 2.0
 speed.step = 0.05
 speed.value = 1.0
 speed.custom_minimum_size = Vector2(650, 50)
 speed.value_changed.connect(func(value: float): player.speed_scale = value)
 panel.add_child(speed)
 status = Label.new()
 panel.add_child(status)

func toggle_pause() -> void:
 is_paused = not is_paused
 if is_paused:
  player.pause()
 else:
  player.play(animation_name)
 pause_button.text = "再生" if is_paused else "一時停止"

func _process(_delta: float) -> void:
 if player != null and status != null:
  status.text = "%s   %.2f / %.2f 秒   ×%.2f" % [animation_name, player.current_animation_position, player.current_animation_length, player.speed_scale]

func apply_coat(body: Color, hair: Color) -> void:
 coat_material.set_shader_parameter("coat_color", body)
 coat_material.set_shader_parameter("mane_color", hair)
 coat_material.set_shader_parameter("tail_color", hair)
 coat_material.set_shader_parameter("show_regions", false)

func play_clip(clip: StringName) -> void:
 if not player.has_animation(clip): return
 animation_name=clip
 is_paused=false
 player.play(clip,0.18)
 pause_button.text="一時停止"

func build_markers() -> void:
 for name_value in ["Saddle","Stirrup_L","Stirrup_R","Bit_L","Bit_R","Withers"]:
  var socket=model.find_child(name_value,true,false) as Node3D
  if socket==null: continue
  var instance=MeshInstance3D.new()
  var sphere=SphereMesh.new()
  sphere.radius=0.0075
  sphere.height=0.015
  sphere.radial_segments=8
  sphere.rings=4
  instance.mesh=sphere
  var material=StandardMaterial3D.new()
  material.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
  material.albedo_color=Color(1.0,0.65,0.05)
  instance.material_override=material
  instance.visible=false
  socket.add_child(instance)
  marker_visuals.append(instance)

func toggle_markers() -> void:
 for instance in marker_visuals: instance.visible=not instance.visible
