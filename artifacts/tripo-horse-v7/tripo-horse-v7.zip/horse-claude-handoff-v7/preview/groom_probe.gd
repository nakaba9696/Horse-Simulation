extends "res://compare_capture.gd"
func run():
 var args=OS.get_cmdline_user_args();var label=args[0] if args.size()>0 else "groom-probe"
 output=ProjectSettings.globalize_path("res://../comparison/"+label);DirAccess.make_dir_recursive_absolute(output);version="v7"
 scene=load("res://main.tscn").instantiate();root.add_child(scene)
 for i in range(3):await process_frame
 for layer in scene.find_children("*","CanvasLayer",true,false):layer.visible=false
 scene.player.callback_mode_process=AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL;scene.player.play("Walk",0)
 var duration=scene.player.get_animation("Walk").length
 for view in ["neck","reverse-neck"]:
  for frame in [0,4,8,12]:await shot("walk-"+view+"-%03d"%frame,duration*frame/16,view)
 var manifest={"source_glb_sha256":FileAccess.get_sha256("res://assets/horse.glb"),"shader_sha256":FileAccess.get_sha256("res://coat.gdshader"),"shots":shots,"views":views,"size":[1600,1000]}
 var file=FileAccess.open(output.path_join("capture-manifest.json"),FileAccess.WRITE);file.store_string(JSON.stringify(manifest,"  "));print("GROOM_PROBE_READY");quit()
