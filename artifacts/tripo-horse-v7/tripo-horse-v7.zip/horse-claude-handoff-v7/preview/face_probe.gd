extends "res://compare_capture.gd"
func run():
 var args=OS.get_cmdline_user_args();var label=args[0] if args.size()>0 else "face-probe"
 output=ProjectSettings.globalize_path("res://../comparison/"+label);DirAccess.make_dir_recursive_absolute(output);version="v7"
 scene=load("res://main.tscn").instantiate();root.add_child(scene)
 for i in range(3):await process_frame
 for layer in scene.find_children("*","CanvasLayer",true,false):layer.visible=false
 scene.player.callback_mode_process=AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL
 scene.player.play("RaceGallop",0)
 for frame in [0,14]:
  await shot("race-face-%03d"%frame,float(frame)/60,"face")
  await shot("race-neck-%03d"%frame,float(frame)/60,"neck")
 print("FACE_PROBE_READY");quit()
