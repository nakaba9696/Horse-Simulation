extends SceneTree
var scene: Node3D
var output: String
var shots: Array[String]=[]
var version: String
var views={
 "side":{"position":Vector3(0,.70,3),"target":Vector3(0,.43,0),"size":1.25},
 "front":{"position":Vector3(-3,.70,0),"target":Vector3(0,.43,0),"size":1.25},
 "oblique":{"position":Vector3(-2.5,.90,2.5),"target":Vector3(-.05,.43,0),"size":1.25},
 "back":{"position":Vector3(3,.70,0),"target":Vector3(0,.43,0),"size":1.25},
 "reverse-oblique":{"position":Vector3(-2.5,.90,-2.5),"target":Vector3(-.05,.43,0),"size":1.25},
 "reverse-neck":{"position":Vector3(-.30,.68,-3),"target":Vector3(-.27,.60,0),"size":.70},
 "neck":{"position":Vector3(-.30,.68,3),"target":Vector3(-.27,.60,0),"size":.70},
 "face":{"position":Vector3(-3,.72,0),"target":Vector3(-.42,.65,0),"size":.47}
}
func _initialize():call_deferred("run")
func shot(name: String,time: float,view: String):
 var camera=views[view]
 scene.camera.position=camera.position
 scene.camera.look_at(camera.target,Vector3.UP)
 scene.camera.size=camera.size
 scene.player.seek(time,true);scene.player.advance(0)
 for skeleton in scene.model.find_children("*","Skeleton3D",true,false):skeleton.force_update_all_bone_transforms()
 for i in range(2):await process_frame
 await RenderingServer.frame_post_draw
 var image=root.get_texture().get_image()
 assert(image.get_width()==1600 and image.get_height()==1000)
 var path=version+"-"+name+".png"
 assert(image.save_png(output.path_join(path))==OK)
 shots.append(path)
 print("COMPARE_CAPTURE ",path)
func run():
 var args=OS.get_cmdline_user_args();var label=args[0] if args.size()>0 else "final"
 output=ProjectSettings.globalize_path("res://../comparison/"+label)
 DirAccess.make_dir_recursive_absolute(output)
 var quick="--quick" in args
 var frames=[0,7,14,21] if quick else range(28)
 var hashes={}
 for v in (["v7"] if quick or "--only-v7" in args else ["v5","v6","v7"]):
  version=v
  var model_path="res://assets/horse.glb" if v=="v7" else "res://assets/"+v+".glb"
  hashes[v]=FileAccess.get_sha256(model_path)
  scene=load("res://main.tscn").instantiate();scene.model_path=model_path;root.add_child(scene)
  for i in range(3):await process_frame
  for layer in scene.find_children("*","CanvasLayer",true,false):layer.visible=false
  scene.player.callback_mode_process=AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL
  scene.player.play("RaceGallop",0)
  scene.coat_material.set_shader_parameter("normal_strength",0.03)
  for view in ["side","front","oblique"]:
   for frame in frames:await shot("race-"+view+"-%03d"%frame,float(frame)/60,view)
  for view in ["neck","face"]:
   for frame in (frames if view=="neck" else [0,7,14,21]):await shot("race-"+view+"-%03d"%frame,float(frame)/60,view)
  if v=="v7":
   for view in ["back","reverse-oblique"]:
    for frame in frames:await shot("race-"+view+"-%03d"%frame,float(frame)/60,view)
   for frame in [0,7,14,21]:await shot("race-reverse-neck-%03d"%frame,float(frame)/60,"reverse-neck")
  scene.player.play("Stand",0)
  for view in ["side","front","oblique"]:await shot("stand-"+view,0,view)
  if v in ["v6","v7"]:
   for clip in ["Stand","Walk","Trot","Canter"]:
    scene.player.play(clip,0);var duration=scene.player.get_animation(clip).length
    for frame in ([0,4,8,12] if quick else range(16)):await shot(clip.to_lower()+"-side-%03d"%frame,duration*frame/16,"side")
    if v=="v7" and clip=="Walk":
     for view in ["neck","reverse-neck"]:
      for frame in [0,4,8,12]:await shot("walk-"+view+"-%03d"%frame,duration*frame/16,view)
  if v in ["v6","v7"]:
   scene.player.play("RaceGallop",0);scene.toggle_markers()
   for view in ["side","oblique"]:
    for frame in [0,7,14,21]:await shot("markers-"+view+"-%03d"%frame,float(frame)/60,view)
  if v=="v7" and not quick:
   scene.toggle_markers()
   scene.player.play("RaceGallop",0)
   var presets={"bay":[Color(.36,.13,.045),Color(.018,.012,.008)],"chestnut":[Color(.42,.15,.05),Color(.16,.055,.018)],"gray":[Color(.65,.65,.62),Color(.20,.20,.18)]}
   for coat in presets:
    scene.apply_coat(presets[coat][0],presets[coat][1])
    for view in ["oblique","neck","face"]:await shot("coat-"+coat+"-"+view,.45*14/27,view)
  scene.queue_free()
  for i in range(3):await process_frame
 var manifest={"versions_glb_sha256":hashes,"renderer":RenderingServer.get_video_adapter_name(),"engine":Engine.get_version_info().string,"size":[1600,1000],"reference_scale":2.6,"world_coordinates":"unscaled model; all share same origin/body anchor; no per-version fit or offset","lighting":"one shared preview recipe per version; ambient 0.7, directional energy 1.8 rotation (-45,-35,0)","shader":"same v7 coat shader and normal-map strength 0.03 for all three; transported-normal guard enabled","race_sampling":"same clip times frame/60, frame 0..27; duration .45","views":views,"shots":shots}
 var file=FileAccess.open(output.path_join("capture-manifest.json"),FileAccess.WRITE);file.store_string(JSON.stringify(manifest,"  "))
 print("COMPARISON_COMPLETE ",shots.size());quit()
