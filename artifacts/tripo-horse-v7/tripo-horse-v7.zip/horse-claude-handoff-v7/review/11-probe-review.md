# v7 iteration-11-probe 独立局所レビュー

**判定：左右4位相×計8原寸の局所画像として通過。正式最終版全体の合格ではない。** ゲーム・モデル編集なし。

全8枚を1600×1000原寸で見た。10の長く孤立した房飾りと束間の大きい肌色の三角隙間が消え、首上縁に沿って後方へ寝る短い細毛の重なりとして読める。09の均等で下へ突き出す櫛歯、08の幅広い鱗状の葉も目立つ再発は見つからない。

004/012に短い斜め線の並びは見えるが、上部の黒い帯から長い歯が突き出す形ではなく、短い毛流れの範囲である。000/008でも隣接束間が途切れて別の飾りになる印象は解消。反対側は暗く隠れる部分が多いという制約はあるが、首上縁に太い突起/傷は見つからない。今回の8枚から追加の必須修正は求めない。

喉〜胸の連続した輪郭も保持しており、板状喉の再発は見つからない。ただし正式Walk16連続、他方向、他歩法、毛色、顔、取付点、実ゲーム、実時間再生/ループ境界はこの局所検査から合格とはしない。次は同一候補を正式描画して非退行を独立確認する。

## 画像の固定

- `v7-walk-neck-000.webp` SHA-256 `bdface84010cd9ff64bcb970ea103ddefdf5ea2d871fb3a1f349b2c98d6e8851`
- `v7-walk-neck-004.webp` SHA-256 `9f99d6ee962f575efebcaef5523cc3cf63b756eb7e75da6d70c7165ff4d15bed`
- `v7-walk-neck-008.webp` SHA-256 `8fa4ad0d4b16fe835d30b44a0904e78a680ed9d8a5caf09a05880f0b9860d9f1`
- `v7-walk-neck-012.webp` SHA-256 `daa1ef7a08ffa334cd86e51d19346f6f4bf42b165b2ca1aefedbf4032b80688e`
- `v7-walk-reverse-neck-000.webp` SHA-256 `206a9d0015fe709ef1e6d0c088e801cfeaa831a0eceab048fb7dd47114dce65f`
- `v7-walk-reverse-neck-004.webp` SHA-256 `b94bd82a3f3454c54e67c1903595b9645cecf9cf484db56d8aaa2ffd9e1497fc`
- `v7-walk-reverse-neck-008.webp` SHA-256 `9ba4945cbe833fb22eca494ca5d2d8f4c57cc5e9a25f508dfc19ed04a61acd4d`
- `v7-walk-reverse-neck-012.webp` SHA-256 `b0e104eee6045223a27c21d270b62de47063c5a79c4c2588425e440adc363512`
