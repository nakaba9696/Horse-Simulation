"""Contact-centroid residual speed at 16 m/s, using final GLB samples."""
import json,math,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent.parent;doc=json.loads((p/'motion-validation.json').read_text());rows=doc['RaceGallop_Loop']['frames'];speed=16.;scale=2.6;playback=speed*.45/7;legs={}
for key in rows[0]['feet']:
 values=[]
 for a,b in zip(rows,rows[1:]):
  fa=a['feet'][key];fb=b['feet'][key]
  if not(fa['expected_stance'] and fb['expected_stance']):continue
  dt=b['time_seconds']-a['time_seconds'];delta=[(fb['centroid'][i]-fa['centroid'][i])*scale/dt*playback for i in range(3)];delta[0]-=speed
  values.append(math.sqrt(sum(v*v for v in delta)))
 legs[key]={'samples':len(values),'rms_world_centroid_slip_mps':math.sqrt(sum(v*v for v in values)/len(values)),'max_world_centroid_slip_mps':max(values)}
result={'source_glb_sha256':hashlib.sha256((p/'horse-gallop.glb').read_bytes()).hexdigest(),'speed_mps':speed,'reference_scale':scale,'playback':playback,'method':'Finite differences of final GLB hoof skin vertex centroids while both adjacent samples are scheduled stance; includes xyz. Skin centroid can move from hoof deformation; not individual contact-patch static friction.','legs':legs}
(p/'contact-validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
