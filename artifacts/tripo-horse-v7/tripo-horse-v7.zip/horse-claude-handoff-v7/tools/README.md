# v7 の再制作と検証

Blender 4.3.2 / Godot 4.6.3 / Python 3.12。ゲームプロジェクトにはアクセスしません。

```sh
python -m venv .venv
. .venv/bin/activate
pip install -r tools/requirements.txt
python tools/rebuild.py --blender blender --godot godot
```

**元入力はv6の編集用中間データ `v6-rest.blend` と `baseline/v6/proportion-design.json`**。v6の鼻面修復済みの閉じた皮・54骨・元UV0/normal画像を使い、v7のproportionsから再生成します。利用者提供の原GLB `source-rigged.glb` も履歴用に同梱。v7 runnerは元Tripoからv6のボクセル修復をやり直すものではありません。外部API・生成課金はありません。

ほかの必須入力: `v4-socket-rest.json`, `baseline/v6/` の数値報告、`anatomy-race-v5.json`, `anatomy-race-v6.json`（比較基準）。これらはv6から変えない入力です。最終GLBと検証報告の内容は固定ハッシュで結び付けます。

各Blenderステージは `--python-exit-code 1`。脚/接地/浮遊/完歩・5動作・ループ・UV2・2補正・6取付点を検証します。頭の長さ/首上線/下線とworld pitchは `measure_anatomy.py`。下線は固定皮膚点の弦であり、下縁の曲線長とは区別します。

`--compare final` はv5/v6/v7の同カメラ比較（表示環境が必要）、`--render` はv7単独のPNG133枚と法線監査・動画。Linuxの無画面環境ではXvfbとソフトウェアOpenGLを使えます。`real_reference_sheets.py LABEL` は同梱PD写真と最終画像の対比シートを作成します。参照写真の取得元・切り出し・左右反転は `reference/REAL_HORSE_REFERENCE.md` と各画像metadata参照。

v7では `RaceNeckCorrective` の旧0/1契約を保ち、`WalkNeckCorrective` をWalkだけ1、他4動作0で追加。`COLOR_0` は小さい鼻孔/口線のhead-local座標です。exportは `export_vertex_color='ACTIVE', export_all_vertex_colors=False`。UV0とUV2のIDを変えず、付属シェーダでCOLORを読むため、ゲームへはGLBだけでなくシェーダ差分も取り込んでください。

AnimationPlayerノードのoptimizerとcompressionは無効、240fps、不変トラック保持、自動ライトマップUV生成なし。`configure_godot_import.py` はConfigFileで設定をマージします。独自ゲームへの適用は `CLAUDE_HANDOFF.md` を参照。

旧v6の `rest.py`, `repair_surface.py`, `shape_v6.py` 等も由来の説明用に一部残りますが、v7 runnerは閉じたv6入力から開始します。数値の `REBUILD_PASS` は見た目の合格を意味しません。独立レビューは `review/` を参照してください。
