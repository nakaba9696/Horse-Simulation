import bpy,json,re,math,sys
from pathlib import Path
from mathutils import Vector
P=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(P/'tools'));from shape_v6 import round_face,interpolate
proportion=json.loads((P/'proportion-design.json').read_text())
bpy.ops.wm.open_mainfile(filepath=str(P/'geometry.blend'))
o=next(x for x in bpy.context.scene.objects if x.type=='MESH' and len(x.data.vertices)>1000)
REGIONS=['body','mane','tail','hoof','muzzle','eye','face_mark_eligible','inner_ear'];counts={n:0 for n in REGIONS};face_ids=[];leg_ids=[]
K=json.loads((P/'build-info.json').read_text())['shorten_x'];hair=json.loads((P/'hair-face-regions.json').read_text());base_count=int(o['base_vertex_count']);original=o.data.attributes['v5_rest_position'];names={g.index:g.name for g in o.vertex_groups};uv=o.data.uv_layers.get('CoatRegions') or o.data.uv_layers.new(name='CoatRegions');crest=json.loads((P/'mane-crest.json').read_text())
def smooth(lo,hi,x):
 t=max(0,min(1,(x-lo)/(hi-lo)));return t*t*(3-2*t)
def crest_z(x):
 for (a,z),(b,w) in zip(crest,crest[1:]):
  if a<=x<=b:return z+(w-z)*(x-a)/(b-a)
 return crest[0][1] if x<crest[0][0] else crest[-1][1]
def muzzle_weight(pt):
 pt=round_face(pt,proportion);q=Vector(proportion['v5_poll']);d=Vector(proportion['v5_nose'])-q;axis=d.normalized();perp=Vector((-axis.z,0,axis.x));delta=pt-q;u=delta.dot(axis)/d.length;v=delta.dot(perp);center=interpolate(proportion['face_sections'],u,1);ry=interpolate(proportion['face_sections'],u,2);rv=interpolate(proportion['face_sections'],u,3)
 theta=math.atan2(pt.y/ry,(v-center)/rv)
 nostril=0
 for side in [-1,1]:
  angle=math.atan2(math.sin(theta-side*1.25),math.cos(theta-side*1.25));distance=math.sqrt(((u-.92)/.11)**2+(angle/.48)**2);nostril=max(nostril,.85*(1-smooth(.20,1.0,distance)))
 # A narrow, subtle lip patch on the ventral end; nostrils remain distinct small marks.
 lip=(1-smooth(.008,.022,abs(v-center-.020)))*smooth(.94,1.02,u)*.80
 return max(nostril,lip)
for poly in o.data.polygons:
 verts=[o.data.vertices[i] for i in poly.vertices];is_added=poly.index>=hair['first_polygon'];actual=sum((v.co for v in verts),Vector())/len(verts)
 old=[original.data[v.index].vector for v in verts] if not is_added else [v.co for v in verts];mean=sum(old,Vector())/len(old);x,y,z=mean;x/=K
 weights={}
 for v in verts:
  for g in v.groups:weights[names[g.group]]=weights.get(names[g.group],0)+g.weight/len(verts)
 tail=sum(w for name,w in weights.items() if 'Tail' in name or name in ['bone_35','bone_36','bone_37','bone_38','bone_39','bone_43']);legs={}
 for name,w in weights.items():
  match=re.fullmatch(r'tripo::([01])_(Left|Right)_Limb_\d+',name)
  if match:
   k=1+int(match[1])*2+(match[2]=='Right');legs[k]=legs.get(k,0)+w
 leg=max(legs,key=legs.get) if legs and max(legs.values())>.30 else 0;region=0
 if is_added:region=hair['regions'][poly.index-hair['first_polygon']];leg=0
 elif tail>.5 and x>.33:region=2
 elif leg and z<.055:region=3
 elif crest[0][0]-.025<actual.x/K<crest[-1][0]+.02 and any(v.co.z>crest_z(v.co.x/K)-.045 and abs(v.co.y)<.055 for v in verts):region=1
 elif max(muzzle_weight(v) for v in old)>.008:region=4
 elif x<-.355 and abs(y)<.011 and .625<z<.785:region=6
 elif z>.81 and abs(y)<.05 and poly.normal.y*y<0:region=7
 counts[REGIONS[region]]+=1;face_ids.append(region);leg_ids.append(leg)
 for li in poly.loop_indices:
  index=o.data.loops[li].vertex_index;pt=o.data.vertices[index].co;height=max(0,min(1,pt.z/.45));packed_y=(leg+.15+.7*height)/8;weight=.5
  if region==1:
   depth=.029 if pt.y<0 else .012
   weight=1 if is_added else smooth(crest_z(pt.x/K)-depth,crest_z(pt.x/K)-depth+.019,pt.z)*(1-smooth(.030,.053,abs(pt.y)))
  if region==4:weight=.5 if is_added else muzzle_weight(original.data[index].vector)
  uv.data[li].uv=((region+.1+.8*weight)/8,1-packed_y)
# COLOR_0 carries immutable head-local coordinates for a smooth fragment mask.
# UV0 normal map and UV2 region/leg contract remain unchanged.
colors=o.data.color_attributes.get('FaceCoordinates') or o.data.color_attributes.new(name='FaceCoordinates',type='FLOAT_COLOR',domain='CORNER')
o.data.color_attributes.active_color=colors;o.data.color_attributes.render_color_index=o.data.color_attributes.find(colors.name)
q=Vector(proportion['poll_rest']);axis=(Vector(proportion['nose_rest'])-q).normalized();length=(Vector(proportion['nose_rest'])-q).length;perp=Vector((-axis.z,0,axis.x))
for loop in o.data.loops:
 v=o.data.vertices[loop.vertex_index];delta=v.co-q;u=delta.dot(axis)/length;front=delta.dot(perp);head_weight=sum(g.weight for g in v.groups if o.vertex_groups[g.group].name=='tripo::Head_5');enabled=1.0 if v.index<base_count and .45<u<1.3 and head_weight>.65 else 0.0
 colors.data[loop.index].color=(max(0,min(1,.5+v.co.y/.12)),max(0,min(1,(u-.65)/.55)),max(0,min(1,.5+front/.12)),enabled)
(P/'face-details.json').write_text(json.dumps({'method':'No attached relief geometry. Fragment nostril and curved lip masks use COLOR_0 head-local coordinates, smooth continuous skin, soft edges. UV2 IDs unchanged.','COLOR_0_encoding':{'r':'0.5 + rest_y / 0.12','g':'(head_axis_fraction - 0.65) / 0.55','b':'0.5 + head_perpendicular / 0.12','a':'head surface mask (base skin only)'},'extra_triangles':0},indent=2))
o.data.uv_layers.active_index=0
schema={'version':1,'attribute':'TEXCOORD_1 / Godot UV2','region_id':'floor(UV2.x*8)','muzzle_blend':'region 4: clamp((fract(UV2.x*8)-0.1)/0.8,0,1); compact nostril and lip masks','mane_blend':'region 1: clamp((fract(UV2.x*8)-0.1)/0.8,0,1); opaque roots with transition below locks','leg_id':'floor(UV2.y*8)','rest_height_model':'clamp((fract(UV2.y*8)-0.15)/0.7,0,1)*0.45','regions':dict(enumerate(REGIONS)),'legs':{'0':'none','1':'left_fore','2':'right_fore','3':'left_hind','4':'right_hind'},'polygon_counts':counts,'tack_materials':['Bridle_Leather','Bridle_Metal'],'hair_tufts':66,'eyes':'two small closed ellipsoid meshes joined to body, tagged region 5; no black eye patches on body'}
o['coat_region_schema']=json.dumps(schema,separators=(',',':'));(P/'coat-region-schema.json').write_text(json.dumps(schema,indent=2));(P/'coat-face-ids.json').write_text(json.dumps({'regions':face_ids,'legs':leg_ids}))
bpy.ops.wm.save_as_mainfile(filepath=str(P/'regions.blend'));print('REGION_COUNTS',json.dumps(counts))
