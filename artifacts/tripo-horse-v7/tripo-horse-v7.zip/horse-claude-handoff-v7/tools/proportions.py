import bpy,json,sys
from pathlib import Path
from mathutils import Vector
P=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(P/'tools'));from shape_v7 import from_v6
bpy.ops.wm.open_mainfile(filepath=str(P/'v6-rest.blend'));d=json.loads((P/'baseline/v6/proportion-design.json').read_text());d['v6_poll_rest']=d['poll_rest'];d['v6_nose_rest']=d['nose_rest'];o=bpy.data.objects['Horse']
for v in o.data.vertices:v.co=from_v6(v.co,d)
d['poll_rest']=list(from_v6(d['v6_poll_rest'],d));d['nose_rest']=list(from_v6(d['v6_nose_rest'],d));d['v7_neck_edit']={'upper_translation_model':[.030,0,-.026],'lower_neck_depth_model':.020,'lower_neck_width_multiplier_max':1.16,'head_shape':'v6 skull retained rigidly; no whole-body scale change'}
(P/'proportion-design.json').write_text(json.dumps(d,indent=2));bpy.ops.wm.save_as_mainfile(filepath=str(P/'rest.blend'));print('V7_REST_READY')
