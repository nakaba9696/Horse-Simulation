# 馬モデル v8

最初に [CLAUDE_HANDOFF.md](CLAUDE_HANDOFF.md) を読んでください。ゲーム本体のコード・データは含みません。

Standの首を短く、Raceの頭を低くしました。頭のneutral形状/サイズはv7と同じです。元ゲームのmeasure.gdではStand首上線弦0.563m・頭0.561m、Raceうなじ平均1.71m/幅0.258m。独立皮膚曲線測定はStand0.5948m、Race平均1.6984m/幅0.2568m。方法差を分けて記録しています。

- horse-gallop.glb / horse-gallop.blend: 最終。54骨・19,168三角形・5歩法・6取付点・2補正。
- v7-rest.blend / baseline/v7/: 閉じたv7編集用入力。source-rigged.glbは元Tripo。
- preview/: Godot4.6.3独立場面。付属シェーダの法線補正/COLOR_0の鼻孔・口、2補正とimport設定を維持してください。
- tools/README.md: 元入力からの再制作と検証。rebuild-validation.jsonは別フォルダ再生成のGLBバイト一致。
- anatomy-comparison.json / game-measurement-comparison.json: v6/v7/v8の首/頭の測定を並列。下線は弦、上線の曲線とゲームの上線弦も別の方法。
- neck-line.json / saddle-track.json / attachment-tracks.json / *-validation.json: 数値と範囲。
- comparison/iteration-03/: 最終578画像。v8新規268、条件とGLBが一致するv6/v7の310を検証再利用。
- comparison/iteration-03-tv/: 中継FOV/距離/高さで24原寸画像。TVのnative比較は無拡大。平地の単独素材検査で、背景/騎手/HUDを再現したゲーム画面ではありません。
- godot-renders/: 単独PNG133枚、法線監査を含む。比較/単独走行の60fps8周期動画も収録。
- reference/: 実馬PD写真・権利metadata・v7の比較11枚・測定出典。元ゲームのmeasure.gdは編集せず、隔離コピーのproto素材だけ置換したログです。v7ラベルのv8への一時置換をprovenanceに明記。
- review/: 制作と分離した2名の画像レビュー、閲覧coverage、残件。neck-before-after.jpgはv7/試作02/修正03。同じ尺度/カメラです。

最終602画像と試作Stand4枚はPNG→可逆WebPで、復号RGBA全画素一致を検査。image-conversion-validation.jsonに両方のhash。capture-manifest-original.jsonとcoverage JSONは元PNG名/hashを保存、配布manifestとレビュー本文はWebP名。中間画像は抜粋であり、中間レビューの全原寸収録とはしません。最終03/03-TVは全画像収録。

首肩の穴/黒い継ぎ目の再発は閲覧範囲で見られず、5歩法・足・取付点・2補正を検証。境界辺/巻き順不整合0と、全隠れ面の自己交差/局所裏返り0の証明は別です。GPUの可視反転法線画素0は付属シェーダ適用下28画像での監査。

近接の線状毛/塗り鼻口の簡略感・下垂尾、TVでの差の小ささは残件。ゲームの騎手/手綱・歩法遷移・背景込み中継可読性・多数頭LOD/FPS・人間による実時間動画再生は未検証。独立素材の画像合格を本採用合格へ広げません。

sha256sum -c SHA256SUMSで全ファイルを検査できます。ZIP全体のSHA-256は外側README。商用利用は利用者のTripo契約に従います。未知のCG動画や他作品のモデルは同梱していません。
