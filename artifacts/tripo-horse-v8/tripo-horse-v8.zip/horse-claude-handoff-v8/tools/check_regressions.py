"""v8 preserved gait/contact contracts; intentional trunk/neck motion is recorded, not hidden."""
from pathlib import Path
import json,math,hashlib
P=Path(__file__).resolve().parent.parent;B=P/'baseline/v7';load=lambda p:json.loads(p.read_text());old=load(B/'motion-validation.json');new=load(P/'motion-validation.json');clips={}
for clip in old:
 a=old[clip]['summary'];b=new[clip]['summary'];assert abs(a['duration']-b['duration'])<1e-8
 assert b['minimum_hoof_m']>=-.004 and b['loop_max_vertex_difference']<1e-5
 assert abs(a['airborne_fraction']-b['airborne_fraction'])<.006
 assert abs(a['withers_peak_to_peak_m']-b['withers_peak_to_peak_m'])<.003
 difference=max(math.dist(ra['feet'][k]['centroid'],rb['feet'][k]['centroid'])*2.6 for ra,rb in zip(old[clip]['frames'],new[clip]['frames']) for k in ra['feet'])
 if clip=='RaceGallop_Loop':
  for leg in b['legs'].values():assert abs(leg['fitted_stride_m']-7)<.025
  assert max(l['stance_height_variation_m'] for l in b['legs'].values())<.010
 clips[clip]={'duration':b['duration'],'max_v7_hoof_centroid_difference_m':difference,'minimum_hoof_m':b['minimum_hoof_m'],'airborne_fraction':b['airborne_fraction'],'withers_peak_to_peak_m':b['withers_peak_to_peak_m'],'loop_difference_model':b['loop_max_vertex_difference'],'feet_byte_identity_claimed':False}
contact=load(P/'contact-validation.json');previous=load(B/'contact-validation.json')
for name,row in contact['legs'].items():assert row['rms_world_centroid_slip_mps']<=previous['legs'][name]['rms_world_centroid_slip_mps']+.15,(name,row)
neck=load(P/'neck-line.json');s=neck['summary'];poll=[x['points_model']['poll'][1]*2.6 for x in neck['samples'][:-1]];poll_range=max(poll)-min(poll)
assert .25<=poll_range<=.30,poll_range
assert s['nose_forward_every_sample'] and s['max_lateral_mid_m']<.005
assert s['minimum_crest_above_chord_m']>=-.003
surface=load(P/'surface-validation.json')
for mesh in surface['meshes'].values():assert mesh['boundary_edges']==mesh['nonmanifold_edges']==mesh['inconsistent_winding_edges']==0
assert surface['max_degenerate_faces']==0 and not surface['globally_reversed_body_component']
geometry=load(P/'geometry-report.json');assert geometry['total_triangles']==19168
assert geometry['socket_rest_blender']==load(B/'geometry-report.json')['socket_rest_blender']
anatomy=load(P/'anatomy-race-v8.json');r=anatomy['clips']['RaceGallop_Loop']['summary'];assert r['head_pitch_world_degrees_peak_to_peak']<15 and r['trunk_pitch_world_degrees_peak_to_peak']>7
assert r['head_center_height_m_peak_to_peak']<load(P/'anatomy-race-v7.json')['clips']['RaceGallop_Loop']['summary']['head_center_height_m_peak_to_peak']
stand=anatomy['clips']['Stand_Loop']['summary']
assert .56<=stand['top_line_m']<=.62
assert 1.0<=stand['top_line_m']/stand['head_length_m']<=1.1
race_rows=anatomy['clips']['RaceGallop_Loop']['samples'][:-1]
mean_poll=sum(x['poll_height_m'] for x in race_rows)/len(race_rows)
assert 1.66<=mean_poll<=1.72,mean_poll
assert min(x['neck_pitch_world_degrees'] for x in race_rows)>=30
assert max(x['neck_pitch_world_degrees'] for x in race_rows)<=45
assert r['top_line_m']<load(P/'anatomy-race-v7.json')['clips']['RaceGallop_Loop']['summary']['top_line_m']
walk=anatomy['clips']['Walk_Loop']['summary'];old_walk=load(P/'anatomy-race-v7.json')['clips']['Walk_Loop']['summary']
for k in walk:assert abs(walk[k]-old_walk[k])<1e-5,(k,walk[k],old_walk[k])
result={'source_glb_sha256':hashlib.sha256((P/'horse-gallop.glb').read_bytes()).hexdigest(),'clips':clips,'stand_top_line_m':stand['top_line_m'],'race_mean_poll_m':mean_poll,'walk_summary_equal_tolerance':1e-5,'poll_height_range_m':poll_range,'contact_validation_method':contact['method'],'contact_comparison':'Each leg RMS <= v7 + 0.15m/s; identical centroid trajectories are not claimed. Intentional trunk pitch changes upper limb poses while world hoof IK targets stay fixed.','sockets':'Six names and rest anchor contract retained; animated transforms are regenerated for the intentional trunk and head motion and separately checked in Godot for all five clips.','numeric_contracts':'PASS','visual_approval':'Separate independent actual-image review required; numerical tests do not approve anatomy/appearance.'}
(P/'regression-validation.json').write_text(json.dumps(result,indent=2));print('V8_REGRESSION_PASS',poll_range)
