"""Use the immutable v7 authored rest mesh; no skull/torso/UV/color rescaling."""
import bpy,json
from pathlib import Path
P=Path(__file__).resolve().parent.parent
bpy.ops.wm.open_mainfile(filepath=str(P/'v7-rest.blend'))
d=json.loads((P/'baseline/v7/proportion-design.json').read_text());d['v8_base']='v7 authored rest; Stand and Race targets changed in animation; skull geometry unchanged'
(P/'proportion-design.json').write_text(json.dumps(d,indent=2));bpy.ops.wm.save_as_mainfile(filepath=str(P/'rest.blend'));print('V8_REST_V7_UNCHANGED')
