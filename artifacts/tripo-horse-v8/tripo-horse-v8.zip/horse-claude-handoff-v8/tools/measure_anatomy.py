"""Measure fixed barycentric skin landmarks; standalone .blend input, no game access."""
import bpy,sys,json,math,numpy as np
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from mathutils.geometry import barycentric_transform
P=Path(__file__).resolve().parent.parent
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [];root=Path(args[0]) if args else P
bpy.ops.wm.open_mainfile(filepath=str(root/'horse-gallop.blend'));a=next(o for o in bpy.data.objects if o.type=='ARMATURE');o=bpy.data.objects['Horse'];s=bpy.context.scene;N=int(o['base_vertex_count']);d=json.loads((root/'neck-design.json').read_text())
rest=np.array([v.co[:] for v in o.data.vertices[:N]]);faces=[tuple(f.vertices) for f in o.data.polygons if all(i<N for i in f.vertices)];bvh=BVHTree.FromPolygons([Vector(p) for p in rest],faces,all_triangles=True)
q=Vector(d['poll_rest']);w=Vector(d['withers_design_rest']);n=Vector(d['nose_rest']);seeds={'poll':q,'upper_lip':n,'withers':w,'throatlatch':q+Vector((.020,0,-.090)),'neck_shoulder_junction':w+Vector((-.060,0,-.045))}
landmarks={}
for name,seed in seeds.items():
 hit,normal,ix,distance=bvh.find_nearest(seed);tri=faces[ix];weights=barycentric_transform(hit,*[Vector(rest[i]) for i in tri],Vector((1,0,0)),Vector((0,1,0)),Vector((0,0,1)));landmarks[name]=(tri,np.array(weights))
for tr in a.animation_data.nla_tracks:tr.mute=True
o.data.shape_keys.animation_data_clear()
def coordinates(frame):
 s.frame_set(int(frame),subframe=frame-int(frame));bpy.context.view_layer.update();ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=ev.to_mesh();co=np.array([v.co[:] for v in m.vertices[:N]]);ev.to_mesh_clear();return co
results={}
for clip,frames in [('Stand_Loop',720),('RaceGallop_Loop',108),('Walk_Loop',288)]:
 a.animation_data.action=bpy.data.actions[clip];o.data.shape_keys.key_blocks['RaceNeckCorrective'].value=1 if clip=='RaceGallop_Loop' else 0
 if 'WalkNeckCorrective' in o.data.shape_keys.key_blocks:o.data.shape_keys.key_blocks['WalkNeckCorrective'].value=1 if clip=='Walk_Loop' else 0
 rows=[]
 for i in range(109 if clip=='RaceGallop_Loop' else 33):
  t=i/(108 if clip=='RaceGallop_Loop' else 32);co=coordinates(1+t*frames);pts={k:np.sum(co[list(ix)]*weights[:,None],axis=0) for k,(ix,weights) in landmarks.items()};posed=BVHTree.FromPolygons([Vector(p) for p in co],faces,all_triangles=True);q1=pts['poll'];w1=pts['withers'];profile=[]
  for u in np.linspace(0,1,33):
   x=w1[0]+(q1[0]-w1[0])*u;hit=posed.ray_cast(Vector((x,0,2)),Vector((0,0,-1)))[0];profile.append(np.array(hit) if hit is not None else w1*(1-u)+q1*u)
  profile[0]=w1;profile[-1]=q1
  top=sum(np.linalg.norm(b-a) for a,b in zip(profile,profile[1:]))*2.6;bottom=np.linalg.norm(pts['throatlatch']-pts['neck_shoulder_junction'])*2.6;head=np.linalg.norm(pts['upper_lip']-q1)*2.6
  rear=np.array(a.pose.bones['tripo::Spine_0'].head);front=np.array(a.pose.bones['tripo::Spine_7'].head);trunk=front-rear;hd=pts['upper_lip']-q1;head_pitch=math.degrees(math.atan2(hd[2],-hd[0]));trunk_pitch=math.degrees(math.atan2(trunk[2],-trunk[0]));neck_pitch=math.degrees(math.atan2(q1[2]-w1[2],w1[0]-q1[0]))
  rows.append({'phase':t,'points_blender_model':{k:list(map(float,v)) for k,v in pts.items()},'top_profile_blender_model':[list(map(float,p)) for p in profile],'top_line_m':float(top),'lower_line_chord_m':float(bottom),'head_length_m':float(head),'head_to_top_line':float(head/top),'top_to_lower_line_chord':float(top/bottom),'neck_pitch_world_degrees':neck_pitch,'head_pitch_world_degrees':head_pitch,'trunk_pitch_world_degrees':trunk_pitch,'head_center_height_m':float((q1[2]+pts['upper_lip'][2])*.5*2.6),'upper_lip_height_m':float(pts['upper_lip'][2]*2.6),'poll_height_m':float(q1[2]*2.6),'withers_height_m':float(w1[2]*2.6)})
 keys=['head_pitch_world_degrees','trunk_pitch_world_degrees','neck_pitch_world_degrees','head_center_height_m','upper_lip_height_m','poll_height_m','withers_height_m'];summary={k+'_peak_to_peak':max(r[k] for r in rows)-min(r[k] for r in rows) for k in keys};summary.update({k:rows[0][k] for k in ['top_line_m','lower_line_chord_m','head_length_m','head_to_top_line','top_to_lower_line_chord']});results[clip]={'summary':summary,'samples':rows};print(clip,summary,flush=True)
report={'method':'Five fixed nearest-surface barycentric landmarks on base skin, same seed offsets from version-specific poll and withers. Head is poll to upper lip surface point. Top line is a 33-point sagittal upper-surface polyline; lower line is throatlatch to neck-shoulder junction chord, explicitly not a traced underside arc. Added mane/face relief excluded. World pitch uses evaluated skin head direction and anatomical Spine_0 to Spine_7 trunk axis. Rest and source metadata included for audit; this measurement is not an anatomical ground truth.','reference_scale':2.6,'landmark_seeds_blender_model':{k:list(v) for k,v in seeds.items()},'landmark_barycentric':{k:{'vertices':list(ix),'weights':list(map(float,wt))} for k,(ix,wt) in landmarks.items()},'clips':results};(P/('anatomy-race-v8.json' if root.resolve()==P.resolve() else 'anatomy-'+root.name+'.json')).write_text(json.dumps(report,indent=2))
