# v8 の再制作と検証

Blender 4.3.2 / Godot 4.6.3 / Python 3.12。ゲーム本体へはアクセスしません。

```sh
python -m venv .venv
. .venv/bin/activate
pip install -r tools/requirements.txt
python tools/rebuild.py --blender blender --godot godot
```

元入力は `v7-rest.blend` と `baseline/v7/proportion-design.json`。v7の閉じた皮・54骨・頭の形・UVをそのまま使い、StandとRaceの首頭の目標位置を変えます。`source-rigged.glb` は元Tripoの履歴用。外部API・生成課金はありません。`v4-socket-rest.json`、`build-info.json`、`muzzle-fusion.json`、`baseline/v7/`、比較用 `anatomy-race-v6.json` と `anatomy-race-v7.json` も入力です。

各Blenderステージは `--python-exit-code 1`。脚/接地/浮遊/完歩・5動作・ループ・UV2・2補正・6取付点を検証します。頭と首の測定は `measure_anatomy.py`。上線は33点の皮膚の曲線、下線は固定点の弦です。ゲームのmeasure.gdの上線弦とは別の測り方で、両方を報告します。

`--compare LABEL` はv6/v7/v8の同一条件比較、`--render` は単独PNG133枚と法線監査・動画。表示環境が必要です。Linux無画面ではXvfbとソフトウェアOpenGLを使えます。`compare_media.py LABEL` と `real_reference_sheets.py LABEL` で一覧画像とPD写真比較を生成します。PNGが配布時に可逆WebPとなった場合も読み込めます。

`preview/tv_capture.gd -- LABEL` と `tools/tv_media.py LABEL` は元ゲームの中継カメラから測った距離/高さ/FOVを使います。背景と騎手なし、平地へ再配置した独立素材の可読性検査です。ゲーム全体の受け入れ試験とはしません。

RaceNeckCorrectiveはRace/Trot/Canterで1、Stand/Walkで0。WalkNeckCorrectiveはWalkだけ1。COLOR_0は鼻孔/口の頭ローカル座標で、頂点色としてALBEDOへ直接乗算しません。付属シェーダはv7と同じです。

GodotのAnimationPlayer optimizer/compression無効、240fps、不変トラック保持、自動ライトマップUVなし、embedded_image_handling=3。`configure_godot_import.py` はConfigFileでマージします。取り込みは `CLAUDE_HANDOFF.md` を参照。旧版由来の補助ファイルは一部残りますがrunnerはv7入力から開始します。

数値のREBUILD_PASSだけで見た目を合格とはしません。独立レビューはreview/へ。全隠れ面の自己交差や実ゲームの騎手/手綱/歩法ブレンド/性能は別途確認が必要です。
