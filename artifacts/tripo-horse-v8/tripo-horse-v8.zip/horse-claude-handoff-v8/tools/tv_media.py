from pathlib import Path
from PIL import Image,ImageDraw
import argparse,json
p=Path(__file__).resolve().parent.parent;a=argparse.ArgumentParser();a.add_argument('label');args=a.parse_args();q=p/'comparison'/args.label

def load(name):
 f=q/name
 return Image.open(f if f.exists() else f.with_suffix('.webp')).convert('RGB')
def make(name,versions,cols):
 c=Image.new('RGB',(1600,1000),(18,23,28));d=ImageDraw.Draw(c);width=1600//cols
 for row,frame in enumerate([0,14]):
  for col,(label,v) in enumerate(versions):
   im=load(f'{v}-tv-lod1-{frame:03}.png');assert im.size==(1600,1000)
   # Native pixels, no resize: same centered crop for every model and phase.
   left=(1600-width)//2;box=(left,265,left+width,735);crop=im.crop(box);c.paste(crop,(col*width,row*500+30));d.text((col*width+10,row*500+7),f'{label} / frame {frame:02} / TV native 1:1',fill='white')
 c.save(q/name,quality=96,subsampling=0)
make('tv-compare-native.jpg',[(v,v) for v in ['v6','v7','v8']],3)
make('tv-ab-native.jpg',[('A','v8'),('B','v7')],2)
(q/'tv-ab-key.json').write_text(json.dumps({'A':'v8','B':'v7','scope':'Same coat, FOV, perspective distance and default LOD1; label letters only. Native pixel crop; no enlargement or per-model fitting.'},indent=2))
print('TV_MEDIA_READY')
