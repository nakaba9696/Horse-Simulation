"""Fixed crops shared by all versions; no individual fitting or stretching."""
from pathlib import Path
from PIL import Image,ImageOps,ImageDraw
import argparse,json
parser=argparse.ArgumentParser();parser.add_argument('iteration');args=parser.parse_args();p=Path(__file__).resolve().parent.parent;q=p/'comparison'/args.iteration

def contact(out,names,cols,rows,crop=None):
 w=1600//cols;h=1000//rows;canvas=Image.new('RGB',(1600,1000),(18,23,28));draw=ImageDraw.Draw(canvas)
 for i,name in enumerate(names):
  im=Image.open((q/(name+'.png')) if (q/(name+'.png')).exists() else (q/(name+'.webp'))).convert('RGB');assert im.size==(1600,1000)
  if crop:im=im.crop(crop)
  im=ImageOps.contain(im,(w,h-22));x=i%cols*w+(w-im.width)//2;y=i//cols*h+22+(h-22-im.height)//2;canvas.paste(im,(x,y));draw.text((i%cols*w+8,i//cols*h+4),name,fill='white')
 canvas.save(q/(out+'.jpg'),quality=95,subsampling=0)
for view in ['side','front','oblique']:
 contact('compare-'+view,[f'{v}-race-{view}-{f:03}' for f in [0,9,18] for v in ['v6','v7','v8']],3,3,(120,130,1480,930))
 contact('v8-'+view+'-28',[f'v8-race-{view}-{f:03}' for f in range(28)],7,4,(120,130,1480,930))
for view in ['neck','face']:
 contact('compare-'+view,[f'{v}-race-{view}-{f:03}' for f in [0,14] for v in ['v6','v7','v8']],3,2)
contact('v8-gaits',[f'v8-{c}-side-{f:03}' for c in ['stand','walk','trot','canter'] for f in [0,4,8,12]],4,4,(120,130,1480,930))
for clip in ['stand','walk','trot','canter']:
 contact('compare-'+clip,[f'{v}-{clip}-side-{f:03}' for f in [0,4,8,12] for v in ['v7','v8']],2,4,(120,130,1480,930))
contact('compare-markers',[f'{v}-markers-oblique-{f:03}' for f in [0,14] for v in ['v7','v8']],2,2,(120,130,1480,930))
if ((q/'v8-race-back-000.png').exists() or (q/'v8-race-back-000.webp').exists()):
 for view in ['back','reverse-oblique']:
  contact('v8-'+view+'-28',[f'v8-race-{view}-{f:03}' for f in range(28)],7,4,(120,130,1480,930))
 contact('v8-reverse-neck',[f'v8-race-reverse-neck-{f:03}' for f in [0,7,14,21]],2,2)
if ((q/'v8-coat-gray-face.png').exists() or (q/'v8-coat-gray-face.webp').exists()):
 contact('v8-coats',[f'v8-coat-{coat}-{view}' for view in ['oblique','neck','face'] for coat in ['bay','chestnut','gray']],3,3)
# Capture metadata stores exact common camera positions, lighting and GLB hashes.
print('COMPARISON_MEDIA_READY',args.iteration)
