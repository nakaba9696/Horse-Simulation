# sculpt-neck 床影候補の独立画像確認

2026-10-25 Asia/Tokyo。GLB SHA-256 `50f8c9d320b6cb72a19a258f237d8589446b1d18b27af18b69cc77fac61dc125`。制作編集なし。

**照明候補として通過。全周期の再描画へ進めてよい。最終納品の合格ではない。**

`experiments/sculpt-neck/floor-shadow-probes/ortho-front.webp`、`ortho-face.webp`、`ortho-side.webp` の3枚を1600×1000原寸で実見。先のprobeで床全域に出た斜めの反復帯は消え、首〜胴の大きな等高線状の陰影も解消した。顔寄りの喉中央にはごく淡い斜めの面の変化が残るが、黒い穴/三角形の反復段とは読めず、この重点3枚では修正必須の帯は確認しない。左肩や顎下の影は残り、馬の陰影を全部消した絵ではない。

対象設定は親申告で床PlaneMeshのcast_shadowのみOFF、馬の投影/受影ON、orthogonal/max6m/bias.1/normalbias2。画像は設定値自体の証明にはしない。このisolated studioでの判定であり、ゲームの影設定への適合は未検証。

首形状は前回sculpt-neck重点probeの改善を保持して見える。全周期のRace/Walkなど、反対側、接地時に影が不自然に離れないか、細い髪や頭絡の影、毛色、比較版の同条件再描画は次の正式レビューが必要。norm4版は閲覧していない。
