import bpy,json,math
from pathlib import Path
from mathutils import Matrix,Vector
P=Path(__file__).resolve().parent.parent;bpy.ops.wm.open_mainfile(filepath=str(P/'horse-gallop.blend'))
a=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');s=bpy.context.scene;specs=json.loads((P/'animation-specs.json').read_text());C=Matrix(((1,0,0,0),(0,0,1,0),(0,-1,0,0),(0,0,0,1)))
names=['Saddle','Stirrup_L','Stirrup_R','Bit_L','Bit_R','Withers'];nodes={name:bpy.data.objects[name] for name in names};tracks={};worst_bit=0
for track in a.animation_data.nla_tracks:track.mute=True
for clip,sp in specs.items():
 a.animation_data.action=bpy.data.actions[clip];samples=[];count=round(sp['duration']*60)
 for i in range(count+1):
  seconds=sp['duration']*i/count;frame=1+seconds*240;s.frame_set(int(frame),subframe=frame-int(frame));bpy.context.view_layer.update();poses={}
  for name,node in nodes.items():
   M=C@node.matrix_world@C.inverted();q=M.to_quaternion();forward=M.to_3x3()@Vector((-1,0,0));up=M.to_3x3()@Vector((0,1,0));poses[name]={'position_model':list(M.translation),'quaternion_xyzw':[q.x,q.y,q.z,q.w],'forward_model':list(forward),'up_model':list(up),'pitch_degrees':math.degrees(math.atan2(forward.y,math.hypot(forward.x,forward.z)))}
  samples.append({'time_seconds':seconds,'phase':i/count,'nodes':poses})
  metal=bpy.data.objects['BridleMetal'];ev=metal.evaluated_get(bpy.context.evaluated_depsgraph_get());mesh=ev.to_mesh()
  for bit,indices in [('Bit_L',range(24)),('Bit_R',range(24,48))]:
   center=sum((metal.matrix_world@mesh.vertices[j].co for j in indices),Vector())/24;worst_bit=max(worst_bit,(center-nodes[bit].matrix_world.translation).length)
  ev.to_mesh_clear()
 tracks[clip]={'duration_seconds':sp['duration'],'fps':60,'samples':samples}
root={'coordinate_space':'unscaled glTF model space: +Y up, -X forward','reference_scale':2.6,'source_fps':240,'clip':'RaceGallop_Loop','duration_seconds':.45,'fps':60,'samples':tracks['RaceGallop_Loop']['samples']}
(P/'saddle-track.json').write_text(json.dumps(root,indent=2));(P/'attachment-tracks.json').write_text(json.dumps({'coordinate_space':root['coordinate_space'],'reference_scale':2.6,'clips':tracks},indent=2))
rest=tracks['Stand_Loop']['samples'][0]['nodes']
(P/'socket-rest.json').write_text(json.dumps({'coordinate_space':root['coordinate_space'],'reference_scale':2.6,'nodes':rest,'parents':{n:nodes[n].parent_bone for n in names},'bit_marker_to_ring_max_model_error':worst_bit},indent=2))
assert worst_bit<1e-5,worst_bit
for clip,data in tracks.items():
 assert max((Vector(data['samples'][0]['nodes'][name]['position_model'])-Vector(data['samples'][-1]['nodes'][name]['position_model'])).length for name in names)<1e-5
print('SOCKET_TRACKS_READY', {k:len(v['samples']) for k,v in tracks.items()},'bit_error',worst_bit)
