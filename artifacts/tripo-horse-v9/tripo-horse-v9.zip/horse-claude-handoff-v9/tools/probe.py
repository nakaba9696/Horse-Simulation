import bpy,math,json
from pathlib import Path
from mathutils import Vector
P=Path(__file__).resolve().parent.parent;bpy.ops.wm.read_factory_settings(use_empty=True);bpy.context.scene.render.fps=60;bpy.ops.import_scene.gltf(filepath=str(P/'horse-gallop.glb'))
# Blender cannot use imported custom split normals for the changing shape key.
# Recompute normals from the evaluated shape for renders; leave the GLB unchanged.
bpy.context.view_layer.objects.active=next(o for o in bpy.context.scene.objects if o.type=='MESH' and len(o.data.vertices)>1000);bpy.ops.mesh.customdata_custom_splitnormals_clear()
s=bpy.context.scene;a=next(o for o in s.objects if o.type=='ARMATURE');horse=next(o for o in s.objects if o.type=='MESH' and len(o.data.vertices)>1000)
for tr in a.animation_data.nla_tracks:tr.mute=True
if horse.data.shape_keys:horse.data.shape_keys.animation_data_clear()
def activate(clip):
 a.animation_data.action=next(act for act in bpy.data.actions if act.name.startswith(clip) and any(fc.data_path.startswith('pose.bones') for fc in act.fcurves))
 if horse.data.shape_keys:horse.data.shape_keys.key_blocks['RaceNeckCorrective'].value=0 if clip in ['Stand_Loop','Walk_Loop'] else 1
s.render.engine='CYCLES';s.cycles.samples=8;s.cycles.use_denoising=False;s.render.resolution_x=1600;s.render.resolution_y=1000;s.render.resolution_percentage=100
s.world=bpy.data.worlds.new('Studio');s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.15,.17,.18,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.45;s.view_settings.view_transform='AgX'
for pos,power in [((-1.4,-2,2.6),200),((1.0,1.8,2),130)]:
 light=bpy.data.lights.new('Light','AREA');light.energy=power;light.size=2;obj=bpy.data.objects.new('Light',light);s.collection.objects.link(obj);obj.location=pos;obj.rotation_euler=(Vector((0,0,.4))-obj.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.002));ground=bpy.context.object;mat=bpy.data.materials.new('Floor');mat.diffuse_color=(.10,.13,.14,1);ground.data.materials.append(mat)
d=bpy.data.cameras.new('Camera');camera=bpy.data.objects.new('Camera',d);s.collection.objects.link(camera);s.camera=camera;d.type='ORTHO';d.ortho_scale=1.8
positions={'side':(0,-3,.70),'front':(-3,-.04,.75),'back':(3,-.04,.75)}
def view(name):camera.location=positions[name];camera.rotation_euler=(Vector((0,0,.42))-camera.location).to_track_quat('-Z','Y').to_euler()
original=horse.data.materials[0];materials=[]
for i in range(8):mat=original.copy();mat.name='Coat_'+str(i);materials.append(mat)
horse.data.materials.clear()
for mat in materials:horse.data.materials.append(mat)
for poly in horse.data.polygons:poly.material_index=min(7,int(horse.data.uv_layers[1].data[poly.loop_indices[0]].uv.x*8))
# Smooth mane colour at the boundary, using the unchanged UV2 encoding.
mat=materials[1];nodes=mat.node_tree.nodes;links=mat.node_tree.links;uv=nodes.new('ShaderNodeUVMap');uv.uv_map=horse.data.uv_layers[1].name;sep=nodes.new('ShaderNodeSeparateXYZ');links.new(uv.outputs[0],sep.inputs[0]);mul=nodes.new('ShaderNodeMath');mul.operation='MULTIPLY';mul.inputs[1].default_value=8;links.new(sep.outputs[0],mul.inputs[0]);sub=nodes.new('ShaderNodeMath');sub.operation='SUBTRACT';sub.inputs[1].default_value=1.1;links.new(mul.outputs[0],sub.inputs[0]);div=nodes.new('ShaderNodeMath');div.operation='DIVIDE';div.inputs[1].default_value=.8;div.use_clamp=True;links.new(sub.outputs[0],div.inputs[0]);mix=nodes.new('ShaderNodeMixRGB');links.new(div.outputs[0],mix.inputs[0]);bsdf=next(n for n in nodes if n.type=='BSDF_PRINCIPLED');links.new(mix.outputs[0],bsdf.inputs['Base Color'])
muzzle_mat=materials[4];mn=muzzle_mat.node_tree.nodes;ml=muzzle_mat.node_tree.links;mu=mn.new('ShaderNodeUVMap');mu.uv_map=horse.data.uv_layers[1].name;ms=mn.new('ShaderNodeSeparateXYZ');ml.new(mu.outputs[0],ms.inputs[0]);mm=mn.new('ShaderNodeMath');mm.operation='MULTIPLY';mm.inputs[1].default_value=8;ml.new(ms.outputs[0],mm.inputs[0]);mt=mn.new('ShaderNodeMath');mt.operation='SUBTRACT';mt.inputs[1].default_value=4.1;ml.new(mm.outputs[0],mt.inputs[0]);md=mn.new('ShaderNodeMath');md.operation='DIVIDE';md.inputs[1].default_value=.8;md.use_clamp=True;ml.new(mt.outputs[0],md.inputs[0]);muzzle_mix=mn.new('ShaderNodeMixRGB');ml.new(md.outputs[0],muzzle_mix.inputs[0]);ml.new(muzzle_mix.outputs[0],next(n for n in mn if n.type=='BSDF_PRINCIPLED').inputs['Base Color'])
def lin(v):return v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4
def rgba(c,linear=True):return tuple(lin(v) if linear else v for v in c[:3])+(1,)
colors=[(.36,.13,.045),(.025,.018,.012),(.025,.018,.012),(.15,.14,.13),(.10,.075,.06),(.015,.012,.01),(.36,.13,.045),(.28,.15,.12)]
debug=[(.7,.7,.7),(.9,.1,.05),(.6,.05,.8),(.05,.2,.9),(.05,.8,.8),(.01,.01,.01),(1,1,.05),(.1,.9,.1)]
def palette(values,linear=True):
 for mat,color in zip(materials,values):
  for node in mat.node_tree.nodes:
   if node.type=='BSDF_PRINCIPLED':node.inputs['Base Color'].default_value=rgba(color,linear);node.inputs['Roughness'].default_value=.8
 mix.inputs[1].default_value=rgba(values[0],linear);mix.inputs[2].default_value=rgba(values[1],linear);muzzle_mix.inputs[1].default_value=rgba(values[0],linear);muzzle_mix.inputs[2].default_value=rgba(values[4],linear)
def render(name):s.render.filepath=str(P/(name+'.png'));bpy.ops.render.render(write_still=True)
palette(colors);activate('RaceGallop_Loop');view('side');s.frame_set(13);render('probe-side');camera.location=(-.24,-3,.66);camera.rotation_euler=(Vector((-.22,0,.56))-camera.location).to_track_quat('-Z','Y').to_euler();d.ortho_scale=.95;render('probe-neck')
