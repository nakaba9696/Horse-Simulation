"""Ground-fixed and oblique contour diagnostics; source raster remains private."""
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/horse-v9-mpl')
from pathlib import Path
from PIL import Image,ImageDraw,ImageOps,ImageFilter
import numpy as np,json,math,argparse
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent.parent;a=argparse.ArgumentParser();a.add_argument('label');args=a.parse_args();q=P/'reference-contours'/args.label;q.mkdir(parents=True,exist_ok=True);obs=json.loads((P/'reference-observations.json').read_text());scale=obs['model_units_per_source_pixel']*800;phaseoffset=obs['model_phase_offset'];rows=obs['rows']
versions={v:json.loads((P/('neck-line.json' if v=='v9' else 'baseline/v8/neck-line.json')).read_text())['samples'] for v in ['v8','v9']}
def model_mask(im):
 ar=np.asarray(im.convert('RGB')).astype(float);r,g,b=ar[:,:,0],ar[:,:,1],ar[:,:,2];return ((r>g*1.18)&(r>b*1.25)&(r>25))|((r+1.0>=g)&(g+1.0>=b))
def source_mask(im):
 ar=np.asarray(im.convert('RGB')).astype(float);return (ar[:,:,0]>ar[:,:,1]*1.12)&(ar[:,:,0]-ar[:,:,2]>15)&(ar[:,:,0]>20)&(ar[:,:,1]>ar[:,:,2]*1.15)
def edge(mask):
 im=Image.fromarray((mask*255).astype('uint8'));e=np.array(im)>np.array(im.filter(ImageFilter.MinFilter(3)));return Image.fromarray((e*255).astype('uint8')).filter(ImageFilter.MaxFilter(3))
def source_edge(path,factor,flip=False):
 im=Image.fromarray((source_mask(Image.open(path))*255).astype('uint8'))
 if flip:im=im.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
 im=im.resize((round(im.width*factor),round(im.height*factor)),Image.Resampling.BILINEAR);return edge(np.asarray(im)>127)
def at(version,t,name='withers'):
 a=versions[version];x=t*108;i=int(x);u=x-i;return np.array(a[i]['points_model'][name])*(1-u)+np.array(a[min(i+1,108)]['points_model'][name])*u
for v in ['v8','v9']:
 meanwx=np.mean([at(v,(phaseoffset+i/15)%1)[0] for i in range(15)]);meanrefx=np.mean([239-r['withers_px'][0] for r in rows]);off=(round(800+800*meanwx-meanrefx*scale),round(900-120*scale))
 for i in range(15):
  f=P/'reference-render'/args.label/f'{v}-race-{i:03}.png';canvas=Image.new('RGB',(1600,1000),(245,246,248));canvas.paste((25,100,200),mask=edge(model_mask(Image.open(f))));ref=source_edge(P/'private-reference/user-video-1'/f'{i+1:03}.png',scale,True);layer=Image.new('L',(1600,1000));layer.paste(ref,off);canvas.paste((215,60,40),mask=layer);d=ImageDraw.Draw(canvas);d.line((50,900,1550,900),fill=(100,100,100),width=1);d.text((25,25),f'{v} blue / owner video red / source{i+1:02}; GROUND FIXED, one constant translation+scale',fill='black');d.text((25,48),'No per-frame withers translation. Does not remove whole-body vertical motion.',fill='black');canvas.save(q/f'{v}-owner-run-ground-{i+1:02}.png')
 # Sensitivity to a whole reference-frame shift, not a claim of exact mocap timing.
 for n in [0,7]:
  c=Image.new('RGB',(1600,1000),'white');d=ImageDraw.Draw(c)
  for j,shift in enumerate([-1,0,1]):
   f=P/'reference-render'/args.label/f'{v}-race-{n:03}.png';im=Image.new('RGB',(1600,1000),(245,246,248));im.paste((25,100,200),mask=edge(model_mask(Image.open(f))));ref=source_edge(P/'private-reference/user-video-1'/f'{(n+shift)%15+1:03}.png',scale,True);layer=Image.new('L',(1600,1000));layer.paste(ref,off);im.paste((215,60,40),mask=layer);im=ImageOps.contain(im.crop((200,150,1400,950)),(530,850));c.paste(im,(j*533,85));d.text((j*533+8,35),f'{v} model{n+1:02} / ref shift {shift:+d}',fill='black')
  d.text((15,10),'One reference-frame phase uncertainty: no per-frame retiming / ground fixed',fill='black');c.save(q/f'{v}-phase-sensitivity-{n:02}.jpg',quality=95)
# Fixed-image-plane poll trace; units derived from one scale, not calibrated real-horse truth.
fig,axes=plt.subplots(2,1,figsize=(16,10),dpi=100)
x=np.arange(15)/15;sf=obs['model_units_per_source_pixel']*2.6;refheight=np.array([(120-r['poll_px'][1])*sf for r in rows]);refforward=np.array([(r['poll_px'][0]-r['withers_px'][0])*sf for r in rows])
for ax,ref,name in [(axes[0],refheight,'Poll image-plane height above fixed ground (m-equivalent)'),(axes[1],refforward,'Poll forward of withers (m-equivalent)')]:
 ax.plot(x,ref,'o-',color='#c6402d',label='Owner video hand points');ax.fill_between(x,ref-3*sf,ref+3*sf,color='#c6402d',alpha=.15,label='Point uncertainty +/-3 source pixels')
 for v,col in [('v8','#777777'),('v9','#1764c0')]:
  pts=[at(v,(phaseoffset+i/15)%1,'poll') for i in range(15)];w=[at(v,(phaseoffset+i/15)%1) for i in range(15)];vals=[q[1]*2.6 for q in pts] if ax is axes[0] else [(b[0]-a[0])*2.6 for a,b in zip(pts,w)];ax.plot(x,vals,'o-',color=col,label=v)
 ax.set_ylabel(name);ax.set_xlabel('Normalized source-video cycle');ax.grid(alpha=.25);ax.legend()
fig.suptitle('Reference observations, not numerical acceptance gates. Fixed 79/240 model phase offset.\nAuthored control targets are reused here: curve agreement is NOT independent visual validation.\nImage-plane source and approximate CG anchors; paid12-frame source unavailable.')
fig.tight_layout(rect=[0,0,1,.93]);fig.savefig(q/'head-motion-traces.png');plt.close(fig)
# 8 source-Walk contour comparisons in the original oblique projection; not side-view certification.
cam=np.array([-3,1.1,1.6]);target=np.array([0,.45,0]);forward=(target-cam)/np.linalg.norm(target-cam);right=np.cross(forward,[0,1,0]);right/=np.linalg.norm(right);up=np.cross(right,forward)
def project(point):
 d=np.asarray(point)-target;return np.array([800+800*np.dot(d,right),500-800*np.dot(d,up)])
walk_scale=4.4;wref=np.array([77,42]);walk_records=[]
for v in ['v8','v9']:
 tracks=json.loads((P/('attachment-tracks.json' if v=='v9' else 'baseline/v8/attachment-tracks.json')).read_text())['clips']['Walk_Loop']['samples']
 for i in range(8):
  # Original130frames100fps; eight evenly spaced normalized phases.
  source_index=round(i*130/8)%130+1;source=P/'private-reference'/f'walk-full-{source_index:03}.png';sm=source_mask(Image.open(source));wref=np.array([77,int(np.where(sm[:,77])[0].min())]);sample=tracks[round(i*(len(tracks)-1)/8)];anchor=project(sample['nodes']['Withers']['position_model']);off=tuple(np.round(anchor-wref*walk_scale).astype(int));canvas=Image.new('RGB',(1600,1000),(245,246,248));im=Image.open(P/'reference-render'/args.label/f'{v}-walk-oblique-{i:03}.png');canvas.paste((25,100,200),mask=edge(model_mask(im)));layer=Image.new('L',(1600,1000));layer.paste(source_edge(source,walk_scale),off);canvas.paste((215,60,40),mask=layer);d=ImageDraw.Draw(canvas);d.text((20,20),f'{v} blue / owner Walk contour red / source frame{source_index:03}/130',fill='black');d.text((20,43),'Oblique approximation only: camera unknown; not a side-view reconstruction or exact-match acceptance.',fill='black');canvas.save(q/f'{v}-owner-walk-oblique-{i:02}.png');walk_records.append({'version':v,'source_original_frame':source_index,'source_original_time_seconds':(source_index-1)/100,'model_phase':i/8,'single_scale':walk_scale,'translation':list(off)})
(q/'diagnostics-manifest.json').write_text(json.dumps({'source_glb_sha256':__import__('hashlib').sha256((P/'horse-gallop.glb').read_bytes()).hexdigest(),'ground_fixed_method':'one isotropic scale and one constant translation per version; no framewise vertical adjustment','phase_uncertainty':'whole source frame +/-1 at two representative phases, not exact synchronization','walk_oblique_camera':{'position':cam.tolist(),'target':target.tolist(),'status':'approximate unknown source camera; no side-view proof'},'walk_records':walk_records,'missing':'12frame paid sheet and separate Canter source unavailable; not approved'},indent=2,default=lambda x:int(x)))
print('REFERENCE_DIAGNOSTICS_READY')
