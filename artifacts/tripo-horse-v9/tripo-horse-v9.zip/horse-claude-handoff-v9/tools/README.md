# v9 の再制作と検証

Blender 4.3.2 / Godot 4.6.3 / Python 3.12 / ffmpeg。独立した素材の道具です。

```sh
python -m venv .venv
. .venv/bin/activate
pip install -r tools/requirements.txt
python tools/rebuild.py --blender blender --godot godot
# 表示環境がある場合
python tools/rebuild.py --blender blender --godot godot --compare final --render
python tools/comparison_video.py final
python tools/gait_videos.py
python tools/real_reference_sheets.py final
```

元入力は v8同梱の `v7-rest.blend`、`baseline/v7/proportion-design.json`、`v4-socket-rest.json`、`build-info.json`、`muzzle-fusion.json`、`reference-observations.json`、`anatomy-race-v8.json`、`baseline/v8/{motion-validation,contact-validation,geometry-report}.json`。`source-rigged.glb`は元Tripo履歴用。GLB比較は `preview/assets/v7.glb`・`v8.glb`。外部API・生成課金なし。

v9は首下面の局所sculpt、局所的な首のウェイト平滑化、2補正を再制作。頭の骨に均等0.90倍を全歩法で適用。襲歩/駈歩の首頭は支給走り動画の15位相の観測点から周期曲線を作り、襲歩の胴の上下も同期。常歩の2回うなずきと胴pitchを維持。4蹄の既存骨をRoot直下へ付け替え、全歩法の世界蹄姿勢を焼き込み、蹄底のウェイトを硬くします。骨名54本/三角形19,168/UVの整数領域を保持。v8の首・頭の数値目標は合格条件ではありません。

各Blenderステージは `--python-exit-code 1`。脚/接地/浮遊/完歩・5動作・ループ・UV2・2補正・6取付点を検証します。`check_contact.py` は支持全窓の残差を残し、端から1キーを除いた内部値も補助で出します。内部値だけでゼロ滑りと判定しません。首上線は33点の皮膚曲線、下線は固定点間の弦で、ゲーム側の測り方と混同しません。

`reference_capture.gd -- final` は80枚。`owner_contours.py final`、`reference_diagnostics.py final`、`extend_contours.py` は支給動画の私用展開画像が必要で、同梱原画だけから再生成できる道具ではありません（著作権のため元動画と私用展開画像は配布しません）。生成済み輪郭と支給SHA/変換条件は同梱します。`stand_contours.py`は同梱PD写真を見て作った手輪郭です。12コマ版は15コマ動画からの抽出で、有料12コマ原画を見たと偽りません。駈歩は支給走りの首頭参考、脚は3拍子。常歩の元カメラ未知、斜め近似比較です。

付属 `preview/coat.gdshader` は幾何法線半球guard閾値.15、normal_strength=.03、COLOR_0の鼻孔/口を維持し、v9でUV2の元の高さから蹄冠の色を連続化。旧版シェーダだけでは同じ見えになりません。独立studioの影はorthogonal/max6m/bias.1/normalbias2、床は受影のみ、馬の投受影は有効です。この6mを実際のレース全景のSunへそのまま流用しません。

GodotのAnimationPlayer optimizer/compression無効、240fps、不変トラック保持、自動ライトマップUVなし、embedded_image_handling=3。`configure_godot_import.py`はConfigFileでマージします。Game側のGLB/旧アニメ/旧Skeletonとの混用は禁止。取り込みは `CLAUDE_HANDOFF.md`。

比較PNGは配布時に可逆WebPへ変換し、復号RGBA一致を検証。画像を参照する道具はWebPにも対応するものと、再描画PNGを必要とするものがあります。手本資料の私用再生成を除き、数値の制作pipelineは閉じた入力で再実行できます。REBUILD_PASSは機械的検証で、見た目合格の代わりではありません。
