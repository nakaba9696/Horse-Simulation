"""Reuse unchanged baseline renders only after checking common capture metadata."""
from pathlib import Path
import json,shutil,hashlib,argparse
parser=argparse.ArgumentParser();parser.add_argument('source');parser.add_argument('target');args=parser.parse_args();P=Path(__file__).resolve().parent.parent;src=P/'comparison'/args.source;dst=P/'comparison'/args.target;a=json.loads((src/'capture-manifest.json').read_text());b=json.loads((dst/'capture-manifest.json').read_text())
for key in ['shader_sha256','renderer','engine','size','reference_scale','world_coordinates','lighting','shader','race_sampling','views']:assert a[key]==b[key],key
copied=[]
for version in ['v7','v8']:
 sha=hashlib.sha256((P/'preview/assets'/(version+'.glb')).read_bytes()).hexdigest();assert sha==a['versions_glb_sha256'][version];b['versions_glb_sha256'][version]=sha
 for name in a['shots']:
  if name.startswith(version+'-'):
   shutil.copy2(src/name,dst/name);copied.append(name)
b['shots']=copied+b['shots'];b['baseline_render_reuse']={'source_capture':args.source,'versions':['v7','v8'],'images':len(copied),'reason':'Baseline GLB hashes and all common camera/lighting/shader/phase metadata unchanged; v9 was newly rendered for this iteration.'};(dst/'capture-manifest.json').write_text(json.dumps(b,indent=2));print('BASELINE_REUSE_VERIFIED',len(copied))
