import bpy,math,json
from pathlib import Path
from mathutils import Vector,Quaternion,Matrix
from mathutils.bvhtree import BVHTree
P=Path(__file__).resolve().parent.parent
bpy.ops.wm.open_mainfile(filepath=str(P/'rest.blend'))
a=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');s=bpy.context.scene;s.render.fps=240
scale=2.6
specs={'RaceGallop_Loop':{'duration':.45,'frames':108,'stance':.20,'stride_m':7.,'lift':.18,'phases':[(1,'Right',0),(1,'Left',.195),(0,'Right',.390),(0,'Left',.585)]},'Stand_Loop':{'duration':3.,'frames':720,'stance':1.,'stride_m':0,'lift':0,'phases':[(1,'Right',0),(1,'Left',0),(0,'Right',0),(0,'Left',0)]},'Walk_Loop':{'duration':1.2,'frames':288,'stance':.62,'stride_m':1.6,'lift':.065,'phases':[(1,'Left',0),(0,'Left',.25),(1,'Right',.5),(0,'Right',.75)]}}
specs.update({'Trot_Loop':{'duration':.72,'frames':173,'stance':.52,'stride_m':2.8,'lift':.075,'phases':[(1,'Left',0),(0,'Right',0),(1,'Right',.5),(0,'Left',.5)]},'Canter_Loop':{'duration':.60,'frames':144,'stance':.28,'stride_m':4.5,'lift':.13,'phases':[(1,'Right',0),(1,'Left',.24),(0,'Right',.24),(0,'Left',.50)]}})
# Integer bake interval must exactly match the 240 fps duration.
specs['Trot_Loop']['duration']=173/240
body=bpy.data.objects['Horse'];bvh=BVHTree.FromPolygons([v.co for v in body.data.vertices],[list(p.vertices) for p in body.data.polygons])
proportions=json.loads((P/'proportion-design.json').read_text())
poll_rest=bvh.find_nearest(Vector(proportions['poll_rest']))[0];poll_rest.y=0
nose_rest=bvh.find_nearest(Vector(proportions['nose_rest']))[0];nose_rest.y=0
withers_rest=a.data.bones['tripo::Spine_7'].head_local.copy();withers_rest.y=0;withers_rest.z+=.025
withers_skin_rest=bvh.ray_cast(Vector((withers_rest.x,0,2)),Vector((0,0,-1)))[0]
(P/'neck-design.json').write_text(json.dumps({'poll_rest':list(poll_rest),'nose_rest':list(nose_rest),'withers_design_rest':list(withers_rest),'v9_method':'Visual reference driven neck axis preserving reach; retired v8 neck-length/poll-height limits are not pass criteria.'},indent=2))
def h(t):
 t=t%1;points=[(0,.55),(.12,.65),(.28,.5),(.44,.35),(.58,.2),(.68,0),(.78,.4),(.90,1),(1,.55)]
 for (ta,va),(tb,vb) in zip(points,points[1:]):
  if ta<=t<=tb:
   u=(t-ta)/(tb-ta);u=u*u*(3-2*u);return va+(vb-va)*u
 return .55
reference=json.loads((P/'reference-observations.json').read_text())
REF_OFFSET=79/240

def reference_value(t,key):
 # Uniform periodic Catmull-Rom, no sample-specific phase warp.
 q=((t-REF_OFFSET)%1)*len(reference['rows']);i=int(q);u=q-i;rows=reference['rows'];n=len(rows)
 a,b,c,d=[rows[k%n][key] for k in [i-1,i,i+1,i+2]]
 return .5*((2*b)+(-a+c)*u+(2*a-5*b+4*c-d)*u*u+(-a+3*b-3*c+d)*u*u*u)

def rotate(bn,angle,axis=(0,1,0)):
 b=a.pose.bones[bn];b.rotation_mode='QUATERNION';local=b.bone.matrix_local.to_3x3().inverted()@Vector(axis);b.rotation_quaternion=Quaternion(local,math.radians(angle))
def neck_pose(t,frame,clip="RaceGallop_Loop"):
 bpy.context.view_layer.update()
 B=a.pose.bones['tripo::Spine_7'].matrix@a.data.bones['tripo::Spine_7'].matrix_local.inverted()
 withers=B@withers_rest;withers.y=0
 if clip=='Walk_Loop':
  phi=-2+3*math.sin(4*math.pi*(t-.04));horizontal=.235;target_down=58+4*math.sin(4*math.pi*(t-.08))
 elif clip=='Stand_Loop':
  phi=34+.3*math.sin(2*math.pi*t);reach=.265;horizontal=reach*math.cos(math.radians(phi));target_down=48+.5*math.sin(2*math.pi*(t-.04))
 elif clip in ['RaceGallop_Loop','Canter_Loop']:
  horizontal=reference_value(t,'neck_forward_model')
  rise=reference_value(t,'neck_up_model')
  phi=math.degrees(math.atan2(rise,horizontal))
  target_down=reference_value(t,'head_down_degrees')
 else:
  phi=36+4.5*(2*h(t-.04)-1);horizontal=.200+.012*(1-h(t-.04));target_down=45+5*(2*h(t-.075)-1)
 poll=withers+Vector((-horizontal,0,math.tan(math.radians(phi))*horizontal))
 if clip=='Trot_Loop':poll.z+=.0085*(2*h(t-.04)-1)
 d=nose_rest-poll_rest;rest_down=math.degrees(math.atan2(-d.z,-d.x))
 skull=Matrix.Translation(poll)@Matrix.Rotation(math.radians(rest_down-target_down),4,'Y')@Matrix.Scale(.90,4)@Matrix.Translation(-poll_rest)
 start=B@a.data.bones['tripo::Spine_8'].head_local;end=skull@a.data.bones['tripo::Head_5'].head_local
 z0=a.data.bones['tripo::Spine_8'].head_local.z;z1=a.data.bones['tripo::Head_5'].head_local.z
 chain=['tripo::Spine_8','tripo::Spine_9','tripo::Head_0','tripo::Head_1','tripo::Head_2','tripo::Head_3','tripo::Head_4']
 for name in chain:
  bone=a.pose.bones[name];u=(bone.bone.head_local.z-z0)/(z1-z0)
  rest_axis=a.data.bones['tripo::Head_5'].head_local-a.data.bones['tripo::Spine_8'].head_local;rest_axis.y=0;rest_axis.normalize()
  target_axis=end-start;target_axis.y=0;target_axis.normalize()
  neck_rotation=rest_axis.rotation_difference(target_axis).to_matrix().to_4x4()
  desired=neck_rotation@bone.bone.matrix_local;desired.translation=start.lerp(end,u);desired.translation.y=bone.bone.head_local.y
  bone.matrix=desired;bpy.context.view_layer.update()
  bone.keyframe_insert('location',frame=frame);bone.keyframe_insert('rotation_quaternion',frame=frame);bone.keyframe_insert('scale',frame=frame)
 bone=a.pose.bones['tripo::Head_5'];bone.matrix=skull@bone.bone.matrix_local;bpy.context.view_layer.update()
 bone.keyframe_insert('location',frame=frame);bone.keyframe_insert('rotation_quaternion',frame=frame);bone.keyframe_insert('scale',frame=frame)
a.animation_data_clear();actions={} 
for clip,sp in specs.items():
 a.animation_data_create();a.animation_data.action=None
 for tr in a.animation_data.nla_tracks:tr.mute=True
 for b in a.pose.bones:b.matrix_basis.identity()
 targets=[];helpers=[]
 for group,side,phase in sp['phases']:
  b=a.pose.bones[f'tripo::{group}_{side}_Limb_2'];rest=b.bone.tail_local.copy()
  if clip!='Stand_Loop':rest.x=a.data.bones[f'tripo::{group}_{side}_Limb_0'].head_local.x
  rest.z+=.0004
  target=bpy.data.objects.new('IK',None);s.collection.objects.link(target);helpers.append(target)
  ik=b.constraints.new('IK');ik.target=target;ik.chain_count=3;ik.iterations=100
  foot=a.pose.bones[f'tripo::{group}_{side}_Limb_3'];orient=bpy.data.objects.new('HoofOrientation',None);s.collection.objects.link(orient);helpers.append(orient);orient.rotation_mode='QUATERNION';orient.rotation_quaternion=(a.matrix_world@foot.bone.matrix_local).to_quaternion()
  cr=foot.constraints.new('COPY_TRANSFORMS');cr.target=orient;cr.owner_space='WORLD';cr.target_space='WORLD'
  targets.append((target,rest,phase,orient,foot.bone.head_local-b.bone.tail_local))
 frames=sp['frames'];s.frame_start=1;s.frame_end=frames+1
 for f in range(1,frames+2):
  t=(f-1)/frames;root=a.pose.bones['tripo::Root']
  if clip=='RaceGallop_Loop':offset=Vector((.006*math.sin(2*math.pi*(t-.3)),0,-.105+(.15/scale)*h(t)))
  elif clip in ['Trot_Loop','Canter_Loop']:offset=Vector((.002*math.sin(2*math.pi*t),0,-.105+(.045 if clip=='Trot_Loop' else .075)/scale*h(t)))
  elif clip=='Walk_Loop':offset=Vector((.001*math.sin(2*math.pi*t),0,-.045+.0015*(1-math.cos(4*math.pi*t))))
  else:offset=Vector((0,0,.0005*(1-math.cos(2*math.pi*t))))
  root.location=root.bone.matrix_local.to_3x3().inverted()@offset;root.keyframe_insert('location',frame=f)
  for target,rest,phase,orient,foot_offset in targets:
   u=(t-phase)%1
   if clip=='Stand_Loop':dx=0;dz=0
   else:
    stroke=sp['stride_m']/scale*sp['stance']
    if u<sp['stance']:dx=-stroke/2+stroke*u/sp['stance'];dz=0
    else:q=(u-sp['stance'])/(1-sp['stance']);ease=q*q*(3-2*q);dx=stroke/2-stroke*ease;dz=sp['lift']*math.sin(math.pi*q)
   target.location=rest+Vector((dx,0,dz));target.keyframe_insert('location',frame=f)
   orient.location=target.location+foot_offset;orient.keyframe_insert('location',frame=f)
  if clip in ['RaceGallop_Loop','Trot_Loop','Canter_Loop']:
   pitch_wave=math.sin(2*math.pi*(t-.05))
   rotate('tripo::Spine_0',.8*pitch_wave);bpy.context.view_layer.update()
   original_withers=a.pose.bones['tripo::Spine_7'].head.z
   rotate('tripo::Spine_0',(5.0 if clip=='RaceGallop_Loop' else 2.0)*pitch_wave);bpy.context.view_layer.update()
   correction_z=original_withers-a.pose.bones['tripo::Spine_7'].head.z
   root.location=root.bone.matrix_local.to_3x3().inverted()@(offset+Vector((0,0,correction_z)));root.keyframe_insert('location',frame=f)
   bpy.context.view_layer.update()
   if clip=='RaceGallop_Loop':
    # Keep world hoof IK and trunk pitch; fit body vertical timing to the same source cycle.
    BW=a.pose.bones['tripo::Spine_7'].matrix@a.data.bones['tripo::Spine_7'].matrix_local.inverted()
    body_adjust=reference_value(t,'withers_ground_height_model')-(BW@withers_skin_rest).z
    root.location+=root.bone.matrix_local.to_3x3().inverted()@Vector((0,0,body_adjust))
    root.keyframe_insert('location',frame=f);bpy.context.view_layer.update()
   neck_pose(t,f,clip)
   rotate('tripo::Tail_0',6*math.sin(2*math.pi*(t-.12)));rotate('tripo::Tail_1',3*math.sin(2*math.pi*(t-.2)),(0,0,1))
  elif clip=='Walk_Loop':
   neck_pose(t,f,clip)
   for bn,base,amp,lag in []:rotate(bn,base+amp*math.sin(4*math.pi*(t-lag)))
   rotate('tripo::Tail_0',2*math.sin(2*math.pi*t),(0,0,1))
  else:
   neck_pose(t,f,clip)
   rotate('tripo::Tail_0',2*math.sin(2*math.pi*t),(0,0,1));rotate('tripo::Head_6',2*math.sin(2*math.pi*t));rotate('bone_20',1.5*math.sin(2*math.pi*(t-.15)))
  for bn in ['tripo::Spine_0','tripo::Spine_8','tripo::Spine_9','tripo::Head_0','tripo::Head_4','tripo::Head_5','tripo::Head_6','bone_20','tripo::Tail_0','tripo::Tail_1']:
   a.pose.bones[bn].keyframe_insert('rotation_quaternion',frame=f)
 bpy.ops.object.select_all(action='DESELECT');a.select_set(True);bpy.context.view_layer.objects.active=a
 bpy.ops.nla.bake(frame_start=1,frame_end=frames+1,step=1,only_selected=False,visual_keying=True,clear_constraints=True,clear_parents=False,use_current_action=False,bake_types={'POSE'})
 act=a.animation_data.action;act.name=clip;act.use_fake_user=True
 for fc in act.fcurves:
  if len(fc.keyframe_points)>1:
   fc.keyframe_points[-1].co.y=fc.keyframe_points[0].co.y
  for k in fc.keyframe_points:k.interpolation='LINEAR'
 actions[clip]=act
 for helper in helpers:bpy.data.objects.remove(helper,do_unlink=True)
 a.animation_data.action=None
 tr=a.animation_data.nla_tracks.new();tr.name=clip;tr.strips.new(clip,1,act);tr.mute=True
 print('CLIP_BAKED',clip,flush=True)
a.animation_data.action=actions['Stand_Loop'];s.frame_start=1;s.frame_end=721;s.frame_set(1)
bpy.ops.wm.save_as_mainfile(filepath=str(P/'animated.blend'))
(P/'animation-specs.json').write_text(json.dumps(specs,indent=2));print('ANIMATIONS_READY')
