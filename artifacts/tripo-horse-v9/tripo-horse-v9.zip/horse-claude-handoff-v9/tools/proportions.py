"""Use v8 bundled neutral mesh; local lower-neck sculpt, preserve topology/UV, smooth neck and rigidify hoof weights."""
import bpy,json,sys
from pathlib import Path
P=Path(__file__).resolve().parent.parent
bpy.ops.wm.open_mainfile(filepath=str(P/'v7-rest.blend'))
d=json.loads((P/'baseline/v7/proportion-design.json').read_text());d['v9_base']='v8 bundled v7 neutral rest; local lower-neck sculpt, UV/topology retained, neck weights smoothed and hoof weights made rigid; animated head scale0.9, reference-driven Race/Canter targets'
# Existing hoof bones become root-level rigid effectors. Rest matrices stay identical.
a=next(o for o in bpy.data.objects if o.type=='ARMATURE')
bpy.context.view_layer.objects.active=a;a.select_set(True);bpy.ops.object.mode_set(mode='EDIT')
parents={}
for group in [0,1]:
 for side in ['Left','Right']:
  bone=a.data.edit_bones[f'tripo::{group}_{side}_Limb_3'];parents[bone.name]=bone.parent.name;bone.use_connect=False;bone.parent=a.data.edit_bones['tripo::Root']
bpy.ops.object.mode_set(mode='OBJECT')
(P/'hoof-rig-contract.json').write_text(json.dumps({'method':'Reparent existing four hoof bones to tripo::Root, preserving armature-space rest transforms; bake explicit world hoof transforms for all clips. Avoids nonlinear leg-parent interpolation bending rigid capsules between keys.','previous_parents':parents,'new_parent':'tripo::Root','bone_count':len(a.data.bones),'sockets_unchanged':True,'integration':'Use baked clip tracks; do not assume hoof parent is Limb_2 or add old procedural hoof motion.'},indent=2))
# Remove the inflated lower-neck pocket, retaining the broad root and skull.
import math
from mathutils import Vector
horse=bpy.data.objects['Horse'];W=a.data.bones['tripo::Spine_7'].head_local.copy();W.z+=.025;Q=Vector(d['poll_rest']);count=0;largest=0

def smooth(lo,hi,x):
 t=max(0,min(1,(x-lo)/(hi-lo)));return t*t*(3-2*t)
for vertex in horse.data.vertices:
 x,y,z=vertex.co;u=max(0,min(1,(W.x-x)/(W.x-Q.x)));crest=W.z+(Q.z-W.z)*u
 limb=sum(g.weight for g in vertex.groups if 'Limb' in horse.vertex_groups[g.group].name);head=sum(g.weight for g in vertex.groups if horse.vertex_groups[g.group].name=='tripo::Head_5')
 amount=.018*math.sin(math.pi*u)*(1-smooth(.60,.78,u))*smooth(.405,.54,z)*smooth(.015,.11,crest-z)*(1-smooth(.10,.45,limb))*(1-smooth(.75,.95,head))
 if amount>1e-8:vertex.co.z+=amount;count+=1;largest=max(largest,amount)
(P/'neutral-neck-sculpt.json').write_text(json.dumps({'method':'Local upward sculpt of inflated lower-neck pocket; broad root width, crest, skull, torso and limbs retained; UV/topology unchanged.','vertices':count,'max_shift_model':largest},indent=2))
sys.path.insert(0,str(P/'tools'));from hoof_weights import apply
apply(bpy.data.objects['Horse'],P/'hoof-weight-validation.json')
from neck_weights import apply as apply_neck
apply_neck(bpy.data.objects['Horse'],a,P/'neck-weight-validation.json')
(P/'proportion-design.json').write_text(json.dumps(d,indent=2));bpy.ops.wm.save_as_mainfile(filepath=str(P/'rest.blend'));print('V9_LOCAL_NECK_SCULPT_UV_TOPOLOGY_PRESERVED_WEIGHTS_CHANGED')
