"""Rest-pose skin cross sections; added mane/eyes are excluded from dimensions."""
import bpy,json,math
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
P=Path(__file__).resolve().parent.parent;result={'method':'Final GLB reimport, skeleton REST pose, corrective 0. Base-body triangles only (first source body triangle count; exporter preserves polygon order). Neck sections perpendicular to withers-poll chord, width measured at midpoint between dorsal/ventral skin hits. Head bounding box uses >0.995 Head_5 weight, excluding added geometry. Upper neck rays may include the jaw; this is a geometric cross-section diagnostic, not an anatomical acceptance score.','reference_scale':2.6,'versions':{}}
for version in ['v5','v6']:
 file=P/('preview/assets/v5.glb' if version=='v5' else 'horse-gallop.glb');design=json.loads((P/('baseline/v5/neck-design.json' if version=='v5' else 'neck-design.json')).read_text());body_count=json.loads((P/('baseline/v5/surface-repair.json' if version=='v5' else 'muzzle-fusion.json')).read_text())['body_triangles' if version=='v5' else 'body_triangles_after_union']
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(file));s=bpy.context.scene;a=next(o for o in s.objects if o.type=='ARMATURE');o=next(o for o in s.objects if o.type=='MESH' and len(o.data.vertices)>1000);a.data.pose_position='REST'
 if o.data.shape_keys:
  o.data.shape_keys.animation_data_clear()
  for key in o.data.shape_keys.key_blocks:key.value=0
 bpy.context.view_layer.update();ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());mesh=ev.to_mesh();coords=[o.matrix_world@v.co for v in mesh.vertices];faces=[tuple(f.vertices) for f in list(mesh.polygons)[:body_count]];bvh=BVHTree.FromPolygons(coords,faces);body_indices={i for face in faces for i in face};ev.to_mesh_clear()
 w=Vector(design['withers_design_rest']);q=Vector(design['poll_rest']);axis=(q-w).normalized();normal=Vector((axis.z,0,-axis.x));sections=[]
 for u in [.25,.5,.75]:
  point=w.lerp(q,u);top=bvh.ray_cast(point+normal*.2,-normal,.5)[0];assert top is not None
  bottom=bvh.ray_cast(top-normal*.0001,-normal,.5)[0];assert bottom is not None
  center=(top+bottom)*.5;left=bvh.ray_cast(center,Vector((0,-1,0)),.5)[0];right=bvh.ray_cast(center,Vector((0,1,0)),.5)[0];assert left is not None and right is not None
  sections.append({'fraction_from_withers':u,'dorsoventral_thickness_m':(top-bottom).length*2.6,'lateral_width_m':(left-right).length*2.6})
 head_group=o.vertex_groups.get('tripo::Head_5');head=[coords[v.index] for v in o.data.vertices if v.index in body_indices and any(g.group==head_group.index and g.weight>.995 for g in v.groups)]
 head_axis=(Vector(design['nose_rest'])-q).normalized();perp=Vector((-head_axis.z,0,head_axis.x));longs=[x.dot(head_axis) for x in head];depth=[x.dot(perp) for x in head];width=[x.y for x in head]
 result['versions'][version]={'neck_sections':sections,'rigid_head_bbox_m':{'longitudinal_extent':(max(longs)-min(longs))*2.6,'depth':(max(depth)-min(depth))*2.6,'width':(max(width)-min(width))*2.6}}
result['v6_over_v5']={'neck_sections':[{'fraction_from_withers':a['fraction_from_withers'],'thickness':b['dorsoventral_thickness_m']/a['dorsoventral_thickness_m'],'width':b['lateral_width_m']/a['lateral_width_m']} for a,b in zip(result['versions']['v5']['neck_sections'],result['versions']['v6']['neck_sections'])],'rigid_head_bbox':{k:result['versions']['v6']['rigid_head_bbox_m'][k]/result['versions']['v5']['rigid_head_bbox_m'][k] for k in ['longitudinal_extent','depth','width']}}
(P/'dimension-validation.json').write_text(json.dumps(result,indent=2));print('DIMENSIONS',json.dumps(result['v6_over_v5']))
