"""Merge import settings through Godot's ConfigFile parser, preserving other options."""
from pathlib import Path
import argparse,subprocess
p=argparse.ArgumentParser();p.add_argument('import_file',type=Path);p.add_argument('--godot',default='godot');args=p.parse_args()
subprocess.run([args.godot,'--headless','--path',str(args.import_file.resolve().parent.parent),'--script',str(Path(__file__).with_name('import_settings.gd').resolve()),'--',str(args.import_file.resolve())],check=True,timeout=30)
