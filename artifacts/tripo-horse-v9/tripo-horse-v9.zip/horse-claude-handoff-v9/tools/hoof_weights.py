"""Keep the rigid hoof capsule on its hoof bone; blend into the pastern above it."""
import re,json
from pathlib import Path

def apply(body,report_path):
 groups={g.index:g for g in body.vertex_groups};count=0;legs={};maxshift=0
 for vertex in body.data.vertices:
  z=vertex.co.z
  if z>=.090:continue
  by_leg={}
  for g in vertex.groups:
   m=re.fullmatch(r'tripo::([01])_(Left|Right)_Limb_\d+',groups[g.group].name)
   if m:by_leg[m.group(1),m.group(2)]=by_leg.get((m.group(1),m.group(2)),0)+g.weight
  if not by_leg:continue
  leg=max(by_leg,key=by_leg.get)
  if by_leg[leg]<.80:continue
  t=max(0,min(1,(z-.055)/(.090-.055)));strength=1-t*t*(3-2*t)
  if strength<=1e-8:continue
  hoof=body.vertex_groups[f'tripo::{leg[0]}_{leg[1]}_Limb_3'];old={g.group:g.weight for g in vertex.groups};new={g:w*(1-strength) for g,w in old.items()};new[hoof.index]=new.get(hoof.index,0)+strength
  for g in list(vertex.groups):groups[g.group].remove([vertex.index])
  for g,w in new.items():
   if w>1e-8:groups[g].add([vertex.index],w,'REPLACE')
  count+=1;legs[str(leg)]=legs.get(str(leg),0)+1
 Path(report_path).write_text(json.dumps({'method':'Rigid hoof capsule below rest z .055model; smooth transition to original pastern weights at z .090. Only vertices with >=.8 weight belonging to one leg; no topology/positions/UV edits. World hoof orientation and ankle IK unchanged.','changed_vertices':count,'per_leg':legs,'note':'Introduced for v9 reference-driven body bob without deforming the rigid hoof contact surface. Verify final GLB contact; not a claim of exact zero skin-centroid slip.'},indent=2))
 print('RIGID_HOOF_WEIGHTS',count,legs)
