"""Fixed camera v8/v9 gait comparison movies; eight cycles, actual clip periods."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageOps
import tempfile,subprocess,json
P=Path(__file__).resolve().parent.parent;q=P/'comparison/final';durations={'stand':3.,'walk':1.2,'trot':173/240,'canter':.6};records=[]
for clip,duration in durations.items():
 with tempfile.TemporaryDirectory(prefix='v9-gait-') as folder:
  tmp=Path(folder)
  for i in range(16):
   out=Image.new('RGB',(1600,1000),(18,23,28));d=ImageDraw.Draw(out)
   for j,v in enumerate(['v8','v9']):
    src=q/f'{v}-{clip}-side-{i:03}.png'
    if not src.exists():src=src.with_suffix('.webp')
    im=ImageOps.contain(Image.open(src).crop((150,170,1470,950)),(800,850));out.paste(im,(j*800+(800-im.width)//2,80+(850-im.height)//2));d.text((j*800+15,25),f'{v} {clip} phase{i}/16; fixed shared camera/scale',fill='white')
   out.save(tmp/f'{i:03}.png')
  target=P/f'{clip}-comparison.mp4';subprocess.run(['ffmpeg','-y','-v','error','-framerate',str(16/duration),'-stream_loop','7','-i',str(tmp/'%03d.png'),'-frames:v','128','-c:v','libx264','-threads','4','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart',str(target)],check=True);records.append({'file':target.name,'clip_period_seconds':duration,'unique_frames':16,'cycles':8,'timeline':'Uniform phase; low rate for long Stand noted; no source video pixels.'})
(P/'gait-video-manifest.json').write_text(json.dumps({'movies':records,'human_realtime_playback':'not claimed; reviews used consecutive rendered frames'},indent=2));print('GAIT_VIDEOS_READY')
