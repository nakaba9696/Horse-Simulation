"""Actual animated surface landmarks, same methods for the bundled v5/v6."""
import json,math,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent.parent
result={'coordinate_space':'distances in physical meters at reference scale 2.6','method':'Actual evaluated skin landmarks from neck-line.json; 108 phases excluding duplicate endpoint. Head length is poll to midpoint of bilateral muzzle surface landmarks, not the scale parameter.','versions':{}}
for version,path in [('v5',P/'baseline/v5/neck-line.json'),('v6',P/'neck-line.json')]:
 rows=json.loads(path.read_text())['samples'][:-1];values={key:[] for key in ['neck_horizontal_length_m','neck_chord_length_m','head_length_m','poll_height_m']}
 for row in rows:
  x=row['points_model'];w=x['withers'];q=x['poll'];n=x['nose']
  values['neck_horizontal_length_m'].append(abs(q[0]-w[0])*2.6);values['neck_chord_length_m'].append(math.dist(q,w)*2.6);values['head_length_m'].append(math.dist(n,q)*2.6);values['poll_height_m'].append(q[1]*2.6)
 result['versions'][version]={name:{'mean':sum(v)/len(v),'min':min(v),'max':max(v),'range':max(v)-min(v)} for name,v in values.items()}
result['v6_over_v5']={key:result['versions']['v6'][key]['mean']/result['versions']['v5'][key]['mean'] for key in ['neck_horizontal_length_m','neck_chord_length_m','head_length_m']}
result['source_glb_sha256']=hashlib.sha256((P/'horse-gallop.glb').read_bytes()).hexdigest()
(P/'proportion-comparison.json').write_text(json.dumps(result,indent=2));print(json.dumps(result['v6_over_v5']))
