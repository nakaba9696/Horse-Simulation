"""Hand-annotated owner example landmarks. Derived points only, no owner raster copies."""
import json,math
from pathlib import Path
P=Path(__file__).resolve().parent.parent
# Reproducible visual anchors, not inferred anatomical bone locations.
# W: upper silhouette at the same source x=125 every frame.
# Q: upper crest three pixels behind the visible ear column, plus one pixel inside skin.
# N: foremost visible muzzle edge below Q, not a source 3D anatomical landmark.
W=[(125,y) for y in [52,51,50,48,48,46,44,44,42,42,43,44,46,48,50]]
Q=[(163,43),(163,39),(162,37),(161,34),(160,31),(158,29),(157,25),(155,25),(153,24),(153,23),(153,25),(156,26),(159,29),(161,33),(162,38)]
N=[(178,60),(179,57),(179,54),(177,50),(177,48),(175,45),(173,42),(172,40),(171,40),(170,39),(171,40),(173,42),(175,46),(177,51),(177,56)]

mean_height=sum(120-y for x,y in W)/15
# One sequence-wide scale, established from the preserved body/ground relation, not neck targets.
scale=.5495891802840762/mean_height
rows=[{'source_frame':i+1,'reference_phase':i/15,'withers_px':list(w),'poll_px':list(q),'upper_lip_px':list(n),'neck_forward_model':(q[0]-w[0])*scale,'neck_up_model':(w[1]-q[1])*scale,'withers_ground_height_model':(120-w[1])*scale,'head_down_degrees':math.degrees(math.atan2(n[1]-q[1],n[0]-q[0]))} for i,(w,q,n) in enumerate(zip(W,Q,N))]
(P/'reference-observations.json').write_text(json.dumps({'source':'Owner running video1:15frames,240x144,33fps,0.454545s; not the missing paid12frame sheet','manual_landmark_uncertainty_px':3,'anchor_definition':'W is the visible upper silhouette at x125, Q is crest behind ear, N is foremost lower muzzle. Reproducible CG image anchors, not known bone anatomy. Initial01/02 interior points superseded after independent review.','source_ground_y_px':120,'mean_withers_to_ground_px':mean_height,'model_units_per_source_pixel':scale,'scale_method':'Single sequence-wide isotropic scale from mean withers-to-ground; no per-frame neck scaling, stretching or warping. Source point uncertainty and stylization prevent exact anatomy claims.','model_phase_offset':79/240,'phase_method':'One fixed normalized cyclic offset, chosen by support/gathered/flight sequence; no per-frame time warping. Foot poses are not exact mocap.','rows':rows},indent=2))
print('REFERENCE_OBSERVATIONS_READY',scale)
