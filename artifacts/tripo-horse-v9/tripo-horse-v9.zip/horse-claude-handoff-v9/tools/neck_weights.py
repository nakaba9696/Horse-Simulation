import numpy as np,json
from pathlib import Path

def apply(body,armature,report_path):
 groups={g.index:g for g in body.vertex_groups};H=body.vertex_groups['tripo::Head_5'].index;N=len(body.data.vertices);W=np.zeros((N,len(groups)));mask=np.zeros(N)
 def smooth(a,b,x):
  t=max(0,min(1,(x-a)/(b-a)));return t*t*(3-2*t)
 for v in body.data.vertices:
  x,y,z=v.co
  for g in v.groups:W[v.index,g.group]=g.weight
  head=W[v.index,H];limb=sum(w for k,w in enumerate(W[v.index]) if 'Limb' in groups[k].name)
  mask[v.index]=smooth(-.345,-.310,x)*(1-smooth(-.220,-.150,x))*smooth(.405,.515,z)*(1-smooth(.795,.840,z))*(1-smooth(.15,.50,limb))*(1-smooth(.80,.92,head))
 adj=[set() for i in range(N)]
 for e in body.data.edges:
  a,b=e.vertices;adj[a].add(b);adj[b].add(a)
 for iteration in range(30):
  out=W.copy()
  for i in np.flatnonzero(mask>.001):
   if adj[i]:out[i]+=.35*mask[i]*(W[list(adj[i])].mean(axis=0)-W[i])
  W=out
 for v in body.data.vertices:
  if mask[v.index]<=.001:continue
  row=W[v.index];keep=np.argsort(row)[-4:];row2=np.zeros_like(row);row2[keep]=row[keep];row2/=row2.sum()
  for g in list(v.groups):groups[g.group].remove([v.index])
  for k in keep:
   if row2[k]>1e-8:groups[int(k)].add([v.index],float(row2[k]),'REPLACE')
 Path(report_path).write_text(json.dumps({'method':'Localized adjacency smoothing of original influence fields, skull/chest/limbs protected; <=4 normalized influences','changed_vertices':int((mask>.001).sum())},indent=2))
 print('NECK_LOCAL_WEIGHT_SMOOTH',int((mask>.001).sum()))
