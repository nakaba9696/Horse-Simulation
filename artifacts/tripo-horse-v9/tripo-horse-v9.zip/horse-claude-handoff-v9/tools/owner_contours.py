"""Contours only from owner example; never distribute source rasters or blended reference images."""
from pathlib import Path
from PIL import Image,ImageOps,ImageFilter,ImageDraw
import numpy as np,json,argparse,hashlib
P=Path(__file__).resolve().parent.parent;a=argparse.ArgumentParser();a.add_argument('label');args=a.parse_args();obs=json.loads((P/'reference-observations.json').read_text());out=P/'reference-contours'/args.label;out.mkdir(parents=True,exist_ok=True)
pps=800;scale=obs['model_units_per_source_pixel']*pps
phase_offset=obs['model_phase_offset']
# Model side camera y=.5, size1.25 at1000pixels => pixel y=900-800*y.
versions={v:json.loads((P/('neck-line.json' if v=='v9' else 'baseline/v8/neck-line.json')).read_text())['samples'] for v in ['v8','v9']}
def point_at(rows,t):
 j=t*108;i=int(j);u=j-i
 return np.array(rows[i]['points_model']['withers'])*(1-u)+np.array(rows[min(i+1,108)]['points_model']['withers'])*u
def edge(mask,width=3):
 im=Image.fromarray((mask*255).astype('uint8'));er=im.filter(ImageFilter.MinFilter(3));e=np.array(im)>np.array(er);return Image.fromarray((e*255).astype('uint8')).filter(ImageFilter.MaxFilter(width))
def model_mask(im):
 ar=np.asarray(im.convert('RGB')).astype(float);r,g,b=ar[:,:,0],ar[:,:,1],ar[:,:,2]
 return ((r>g*1.18)&(r>b*1.25)&(r>25))|((r+1.0>=g)&(g+1.0>=b))
manifest=[]
for i,row in enumerate(obs['rows']):
 src=P/'private-reference/user-video-1'/f'{i+1:03}.png'
 ar=np.asarray(Image.open(src).convert('RGB')).astype(float);mask=(ar[:,:,0]>ar[:,:,1]*1.12)&(ar[:,:,0]-ar[:,:,2]>15)&(ar[:,:,0]>20)
 up=Image.fromarray((mask*255).astype('uint8')).transpose(Image.Transpose.FLIP_LEFT_RIGHT).resize((round(240*scale),round(144*scale)),Image.Resampling.BILINEAR);contour=edge(np.asarray(up)>127,3)
 for v in ['v8','v9']:
  modelpath=P/'reference-render'/args.label/f'{v}-race-{i:03}.png';im=Image.open(modelpath).convert('RGB');t=(phase_offset+i/15)%1;w=point_at(versions[v],t);model_anchor=(800+800*w[0],900-800*w[1]);anchor=((239-row['withers_px'][0])*scale,row['withers_px'][1]*scale);offset=(round(model_anchor[0]-anchor[0]),round(model_anchor[1]-anchor[1]))
  canvas=Image.new('RGB',(1600,1000),(245,246,248));model_edge=edge(model_mask(im),3);canvas.paste((25,100,200),mask=model_edge);ref_layer=Image.new('L',(1600,1000));ref_layer.paste(contour,offset);canvas.paste((215,60,40),mask=ref_layer)
  draw=ImageDraw.Draw(canvas);x,y=model_anchor;draw.ellipse((x-5,y-5,x+5,y+5),outline=(0,0,0),width=2);draw.text((25,25),f'{v} blue / owner video contour red / source frame {i+1:02}/15; phase {t:.3f}',fill='black');draw.text((25,48),'One fixed scale; withers aligned each frame; no neck warp. Video-derived reference; not the paid 12-frame sheet.',fill='black')
  dest=out/f'{v}-owner-run-{i+1:02}.png';canvas.save(dest);manifest.append({'version':v,'source_frame':i+1,'model_phase':t,'reference_scale_px':scale,'reference_translation_px':offset,'withers_model':w.tolist(),'model_image':str(modelpath.relative_to(P)),'reference_source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output':dest.name})
# All15 frames, not12 relabeled from15. Each sheet1600x1000, constant crops/scales shared by versions.
for v in ['v8','v9']:
 for first in [0,8]:
  c=Image.new('RGB',(1600,1000),'white');d=ImageDraw.Draw(c)
  for j,i in enumerate(range(first,min(first+8,15))):
   im=Image.open(out/f'{v}-owner-run-{i+1:02}.png').crop((200,190,1450,960));im=ImageOps.contain(im,(400,450));c.paste(im,(j%4*400+(400-im.width)//2,j//4*500+25));d.text((j%4*400+5,j//4*500+5),f'{v} / owner frame{i+1:02}',fill='black')
  c.save(out/f'{v}-owner-run-sheet-{first:02}.jpg',quality=95,subsampling=0)
(out/'contour-manifest.json').write_text(json.dumps({'method':'Only reference silhouette edges derived from owner video; no original raster, color, texture, blended reference or commercial title included. One fixed isotropic scale, withers translation per frame; model blue/reference red. Model masks are rendering contour diagnostics, not altered production meshes.','missing':'Paid12frame sheet unavailable; these are actual15video frames and are not substituted for12frame acceptance. Owner latest running video guides Canter head/neck, not direct three-beat foot matching. Stand uses supplemental PD photo; owner Walk source is oblique.','captures':manifest},indent=2))
print('OWNER_RUN_CONTOURS_READY',len(manifest))
