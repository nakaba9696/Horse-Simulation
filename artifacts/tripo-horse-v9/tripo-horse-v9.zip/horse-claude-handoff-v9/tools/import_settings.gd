extends SceneTree
func _initialize():
 var args=OS.get_cmdline_user_args()
 if args.size()!=1:quit(2);return
 var config=ConfigFile.new()
 if config.load(args[0])!=OK:quit(2);return
 for pair in [["meshes/light_baking",0],["animation/fps",240],["animation/remove_immutable_tracks",false],["meshes/generate_lods",true],["gltf/embedded_image_handling",3]]:
  config.set_value("params",pair[0],pair[1])
 var resources: Dictionary=config.get_value("params","_subresources",{})
 var nodes: Dictionary=resources.get("nodes",{})
 var player: Dictionary=nodes.get("PATH:AnimationPlayer",{})
 player["optimizer/enabled"]=false
 player["compression/enabled"]=false
 nodes["PATH:AnimationPlayer"]=player
 resources["nodes"]=nodes
 config.set_value("params","_subresources",resources)
 if config.save(args[0])!=OK:quit(2);return
 print("IMPORT_SETTINGS_MERGED: AnimationPlayer optimizer disabled; other settings preserved")
 quit()
