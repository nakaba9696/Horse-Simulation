"""v9 preserved gait/contact contracts; intentional trunk/neck motion is recorded, not hidden."""
from pathlib import Path
import json,math,hashlib
P=Path(__file__).resolve().parent.parent;B=P/'baseline/v8';load=lambda p:json.loads(p.read_text());old=load(B/'motion-validation.json');new=load(P/'motion-validation.json');clips={}
for clip in old:
 a=old[clip]['summary'];b=new[clip]['summary'];assert abs(a['duration']-b['duration'])<1e-8
 assert b['minimum_hoof_m']>=-.004 and b['loop_max_vertex_difference']<1e-5
 assert abs(a['airborne_fraction']-b['airborne_fraction'])<.006
 if clip!='RaceGallop_Loop':assert abs(a['withers_peak_to_peak_m']-b['withers_peak_to_peak_m'])<.003
 difference=max(math.dist(ra['feet'][k]['centroid'],rb['feet'][k]['centroid'])*2.6 for ra,rb in zip(old[clip]['frames'],new[clip]['frames']) for k in ra['feet'])
 if clip=='RaceGallop_Loop':
  for leg in b['legs'].values():assert abs(leg['fitted_stride_m']-7)<.025
  assert max(l['stance_height_variation_m'] for l in b['legs'].values())<.010
 clips[clip]={'duration':b['duration'],'max_v8_hoof_centroid_difference_m':difference,'minimum_hoof_m':b['minimum_hoof_m'],'airborne_fraction':b['airborne_fraction'],'withers_peak_to_peak_m':b['withers_peak_to_peak_m'],'loop_difference_model':b['loop_max_vertex_difference'],'feet_byte_identity_claimed':False}
contact=load(P/'contact-validation.json');previous=load(B/'contact-validation.json')
for name,row in contact['legs'].items():assert row['rms_world_centroid_slip_mps']<=previous['legs'][name]['rms_world_centroid_slip_mps']+.15,(name,row)
neck=load(P/'neck-line.json');s=neck['summary'];poll=[x['points_model']['poll'][1]*2.6 for x in neck['samples'][:-1]];poll_range=max(poll)-min(poll)
assert math.isfinite(poll_range)
assert s['nose_forward_every_sample'] and s['max_lateral_mid_m']<.005
# Neck shape is assessed in actual images, not retired numeric neck gates.
surface=load(P/'surface-validation.json')
for mesh in surface['meshes'].values():assert mesh['boundary_edges']==mesh['nonmanifold_edges']==mesh['inconsistent_winding_edges']==0
assert surface['max_degenerate_faces']==0 and not surface['globally_reversed_body_component']
geometry=load(P/'geometry-report.json');assert geometry['total_triangles']==19168
assert geometry['socket_rest_blender']==load(B/'geometry-report.json')['socket_rest_blender']
anatomy=load(P/'anatomy-race-v9.json');r=anatomy['clips']['RaceGallop_Loop']['summary'];assert r['trunk_pitch_world_degrees_peak_to_peak']>7
# V9: Head travel/neck dimensions reported only, judged against reference motion visually.
stand=anatomy['clips']['Stand_Loop']['summary']
race_rows=anatomy['clips']['RaceGallop_Loop']['samples'][:-1]
mean_poll=sum(x['poll_height_m'] for x in race_rows)/len(race_rows)
walk=anatomy['clips']['Walk_Loop']['summary'];old_walk=load(P/'anatomy-race-v8.json')['clips']['Walk_Loop']['summary']
# Walk targets/nod timing retained; skull is resized uniformly for reference proportions.
walk_differences={k:walk[k]-old_walk[k] for k in walk}
result={'source_glb_sha256':hashlib.sha256((P/'horse-gallop.glb').read_bytes()).hexdigest(),'clips':clips,'stand_top_line_m':stand['top_line_m'],'race_mean_poll_m':mean_poll,'walk_summary_differences_from_v8':walk_differences,'poll_height_range_m':poll_range,'contact_validation_method':contact['method'],'contact_comparison':'Each leg RMS <= v8 + 0.15m/s; identical centroid trajectories are not claimed. Intentional trunk pitch changes upper limb poses while world hoof IK targets stay fixed.','sockets':'Six names and rest anchor contract retained; animated transforms are regenerated for the intentional trunk and head motion and separately checked in Godot for all five clips.','numeric_contracts':'PASS mechanical contracts only; retired V8 neck/head limits not gates','visual_approval':'Separate independent actual-image review required; numerical tests do not approve anatomy/appearance.'}
(P/'regression-validation.json').write_text(json.dumps(result,indent=2));print('V9_REGRESSION_PASS',poll_range)
