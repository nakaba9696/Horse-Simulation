"""Local v6 -> v7 neckline edit. Head is translated rigidly; legs/torso stay fixed."""
from mathutils import Vector
import math

def smooth(a,b,x):
 u=max(0.,min(1.,(x-a)/(b-a)));return u*u*(3-2*u)
def from_v6(point,design):
 p=Vector(point);w=Vector(design['withers']);q=Vector(design['v6_poll_rest']);u=max(0.,min(1.,(w.x-p.x)/(w.x-q.x)))
 # Compact upper neck, retain a broad, continuous shoulder-side base.
 delta=Vector((.030,0,-.026));f=smooth(.02,.90,u)*smooth(.45,.64,p.z)
 head=(1-smooth(q.x-.005,q.x+.040,p.x))*smooth(.56,.68,p.z)
 f=max(f,head)
 out=p+delta*f
 # Extra triangular depth at lower neck, tapered away before the throat.
 base=math.sin(math.pi*u)**1.2*(1-smooth(.65,.82,u))*smooth(.43,.57,p.z)
 crest=w.z+(q.z-w.z)*u
 depth=max(0,min(1,(crest-p.z)/.15))
 out.z-=.020*base*depth
 out.y*=1+.16*base
 return out
