import bpy,bmesh,numpy as np,json,math
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from mathutils.geometry import barycentric_transform
P=Path(__file__).resolve().parent.parent;bpy.ops.wm.open_mainfile(filepath=str(P/'horse-gallop.blend'))
a=next(x for x in bpy.context.scene.objects if x.type=='ARMATURE');o=bpy.data.objects['Horse'];s=bpy.context.scene;N=int(o['base_vertex_count'])
for tr in a.animation_data.nla_tracks:tr.mute=True
o.data.shape_keys.animation_data_clear();key=o.data.shape_keys.key_blocks['RaceNeckCorrective'];key.value=1
a.animation_data.action=bpy.data.actions['RaceGallop_Loop'];design=json.loads((P/'neck-design.json').read_text())
rest=np.array([v.co[:] for v in o.data.vertices[:N]]);shaped=np.array([v.co[:] for v in key.data[:N]]);faces=np.array([tuple(p.vertices) for p in o.data.polygons if all(i<N for i in p.vertices)],dtype=int)
base_bvh=BVHTree.FromPolygons([Vector(v) for v in rest],faces.tolist(),all_triangles=True)
def landmark(point):
 hit,no,index,dist=base_bvh.find_nearest(Vector(point));tri=faces[index];weights=barycentric_transform(hit,*[Vector(rest[i]) for i in tri],Vector((1,0,0)),Vector((0,1,0)),Vector((0,0,1)))
 return tri,np.array(weights)
def track(co,landmark):indices,weights=landmark;return np.sum(co[indices]*weights[:,None],axis=0)
poll_landmark=landmark(design['poll_rest']);nose_left=landmark([design['nose_rest'][0],-.020,design['nose_rest'][2]]);nose_right=landmark([design['nose_rest'][0],.020,design['nose_rest'][2]]);midrest=base_bvh.ray_cast(Vector((-.23,0,2)),Vector((0,0,-1)))[0];mid_landmark=landmark(midrest)
W=np.zeros((N,len(o.vertex_groups)))
for v in o.data.vertices[:N]:
 for g in v.groups:W[v.index,g.group]=g.weight
names={g.index:g.name for g in o.vertex_groups};restnorm=np.cross(shaped[faces[:,1]]-shaped[faces[:,0]],shaped[faces[:,2]]-shaped[faces[:,0]])
region=np.array([(-.40<float(rest[f,0].mean())<.08 and float(rest[f,2].mean())>.36) for f in faces])
volumes=[]
rows=[];worst_reverse=0;worst_neck_reverse=0;worstdegenerate=0
for index in range(109):
 t=index/108;s.frame_set(index+1);bpy.context.view_layer.update();ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=ev.to_mesh();co=np.array([v.co[:] for v in m.vertices[:N]]);ev.to_mesh_clear()
 volumes.append(float(np.einsum('fi,fi->f',co[faces[:,0]],np.cross(co[faces[:,1]],co[faces[:,2]])).sum()/6))
 bvh=BVHTree.FromPolygons([Vector(v) for v in co],faces.tolist(),all_triangles=True)
 B=a.pose.bones['tripo::Spine_7'].matrix@a.data.bones['tripo::Spine_7'].matrix_local.inverted();wx=(B@Vector(design['withers_design_rest'])).x
 poll=track(co,poll_landmark);nose=(track(co,nose_left)+track(co,nose_right))*.5
 hit=bvh.ray_cast(Vector((wx,0,2)),Vector((0,0,-1)))[0];assert hit is not None;withers=np.array(hit)
 samples=[]
 for u in np.linspace(0,1,33):
  x=withers[0]+(poll[0]-withers[0])*u;y=withers[1]+(poll[1]-withers[1])*u
  hit=bvh.ray_cast(Vector((x,y,2)),Vector((0,0,-1)))[0];assert hit is not None,(index,u)
  samples.append(np.array(hit))
 mid=samples[16];neck_angle=math.degrees(math.atan2(poll[2]-withers[2],withers[0]-poll[0]));v1=withers-poll;v2=nose-poll;head_angle=math.degrees(math.acos(np.clip(np.dot(v1,v2)/(np.linalg.norm(v1)*np.linalg.norm(v2)),-1,1)))
 dips=[float((point[2]-(withers[2]+(poll[2]-withers[2])*u))*2.6) for point,u in zip(samples,np.linspace(0,1,33))]
 matrices=[]
 for group in range(len(o.vertex_groups)):
  name=names[group];T=a.pose.bones[name].matrix@a.data.bones[name].matrix_local.inverted() if name in a.pose.bones else np.eye(4);matrices.append(np.array(T)[:3,:3])
 V=np.einsum('vg,gij->vij',W,np.array(matrices));F=V[faces].mean(axis=1);expected=np.einsum('fij,fj->fi',np.linalg.inv(F).transpose(0,2,1),restnorm);normal=np.cross(co[faces[:,1]]-co[faces[:,0]],co[faces[:,2]]-co[faces[:,0]]);dot=np.einsum('fi,fi->f',normal,expected);reversed_faces=dot< -1e-14
 reverse=int(reversed_faces.sum());neck_reverse=int((reversed_faces&region).sum());degenerate=int((np.linalg.norm(normal,axis=1)<1e-12).sum());worst_reverse=max(worst_reverse,reverse);worst_neck_reverse=max(worst_neck_reverse,neck_reverse);worstdegenerate=max(worstdegenerate,degenerate)
 def gltf(point):return [float(point[0]),float(point[2]),float(-point[1])]
 rows.append({'time_seconds':t*.45,'phase':t,'points_model':{'withers':gltf(withers),'mid_neck':gltf(mid),'poll':gltf(poll),'nose':gltf(nose)},'neck_angle_degrees':neck_angle,'head_neck_angle_degrees':head_angle,'crest_min_above_chord_m':min(dips),'crest_profile_model':[gltf(p) for p in samples],'tracked_mid_lateral_m':float(track(co,mid_landmark)[1]*2.6),'normal_transport_disagreement_faces':reverse,'neck_shoulder_normal_transport_disagreement_faces':neck_reverse,'degenerate_faces':degenerate})
summary={'neck_angle_degrees_min':min(r['neck_angle_degrees'] for r in rows),'neck_angle_degrees_max':max(r['neck_angle_degrees'] for r in rows),'head_neck_angle_degrees_min':min(r['head_neck_angle_degrees'] for r in rows),'head_neck_angle_degrees_max':max(r['head_neck_angle_degrees'] for r in rows),'minimum_crest_above_chord_m':min(r['crest_min_above_chord_m'] for r in rows),'mean_poll_height_m':float(np.mean([r['points_model']['poll'][1]*2.6 for r in rows[:-1]])),'max_lateral_mid_m':max(abs(r['tracked_mid_lateral_m']) for r in rows),'max_poll_lateral_m':max(abs(r['points_model']['poll'][2]*2.6) for r in rows),'max_nose_lateral_m':max(abs(r['points_model']['nose'][2]*2.6) for r in rows),'nose_forward_every_sample':all(r['points_model']['nose'][0]<r['points_model']['poll'][0] for r in rows)}
report={'coordinate_space':'unscaled glTF +Y up, -X forward','reference_scale':2.6,'samples_hz':240,'sample_count':109,'point_method':'Actual evaluated skin; fixed barycentric poll and bilateral muzzle-midpoint surface landmarks, withers vertical ray at anatomical Spine_7 X, middle crest ray at half span; exclude added hair. Lateral check also tracks a fixed mid-neck skin landmark.','summary':summary,'samples':rows}
(P/'neck-line.json').write_text(json.dumps(report,indent=2));print('NECK_LINE',json.dumps(summary),flush=True)
meshes={}
for obj in s.objects:
 if obj.type!='MESH':continue
 bm=bmesh.new();bm.from_mesh(obj.data);boundary=sum(e.is_boundary for e in bm.edges);nonmanifold=sum(not e.is_manifold for e in bm.edges);inconsistent=sum(e.is_manifold and not e.is_contiguous for e in bm.edges);volume=bm.calc_volume(signed=True);bm.free();meshes[obj.name]={'boundary_edges':boundary,'nonmanifold_edges':nonmanifold,'inconsistent_winding_edges':inconsistent,'signed_rest_volume_model':volume}
(P/'surface-validation.json').write_text(json.dumps({'meshes':meshes,'race_samples':109,'max_normal_transport_disagreement_faces':worst_reverse,'max_neck_shoulder_normal_transport_disagreement_faces':worst_neck_reverse,'max_degenerate_faces':worstdegenerate,'diagnostic_caution':'Transport disagreement is not a count of inverted winding. A linear skin-normal approximation omits spatial weight gradients. The supplied coat shader corrects opposed normals against the geometric hemisphere; GPU audit is recorded separately.','minimum_posed_body_signed_volume_model':min(volumes),'globally_reversed_body_component':min(volumes)<0,'reversal_definition':'Triangle cross product opposes the inverse-transpose of its average linear-blend skin transform applied to the corrective-rest triangle normal. This approximate diagnostic omits weight gradients and cannot by itself prove a face inversion; consistent edge winding is reported separately.'},indent=2));print('SURFACE',meshes,'NORMAL_DISAGREEMENT',worst_reverse,'NECK_NORMAL_DISAGREEMENT',worst_neck_reverse,'DEGENERATE',worstdegenerate,flush=True)
