"""A local low-neck corrective. Existing RaceNeckCorrective values stay unchanged."""
import bpy,json,math,numpy as np
from pathlib import Path
from mathutils import Matrix,Vector
P=Path(__file__).resolve().parent.parent;bpy.ops.wm.open_mainfile(filepath=str(P/'horse-gallop.blend'));s=bpy.context.scene;o=bpy.data.objects['Horse'];a=next(x for x in s.objects if x.type=='ARMATURE');N=int(o['base_vertex_count']);rest=np.array([v.co[:] for v in o.data.vertices]);names={g.index:g.name for g in o.vertex_groups}
for tr in a.animation_data.nla_tracks:tr.mute=True
a.animation_data.action=bpy.data.actions['Walk_Loop'];o.data.shape_keys.animation_data.action=None
for tr in o.data.shape_keys.animation_data.nla_tracks:tr.mute=True
o.data.shape_keys.key_blocks['RaceNeckCorrective'].value=0
if 'WalkNeckCorrective' in o.data.shape_keys.key_blocks:o.shape_key_remove(o.data.shape_keys.key_blocks['WalkNeckCorrective'])
s.frame_set(1);bpy.context.view_layer.update();ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=ev.to_mesh();posed=np.array([v.co[:] for v in m.vertices]);ev.to_mesh_clear();goal=posed.copy();d=json.loads((P/'neck-design.json').read_text());H=a.pose.bones['tripo::Head_5'].matrix@a.data.bones['tripo::Head_5'].matrix_local.inverted();B=a.pose.bones['tripo::Spine_7'].matrix@a.data.bones['tripo::Spine_7'].matrix_local.inverted();Q=H@Vector(d['poll_rest']);W=B@Vector(d['withers_design_rest'])
def smooth(a,b,x):
 u=max(0,min(1,(x-a)/(b-a)));return u*u*(3-2*u)
# Smooth, tapering underside from behind the jaw into the neck/shoulder junction.
left=Q.x+.034;right=W.x+.028
mask=np.zeros(N)
for i in range(N):
 x,y,z=posed[i];rx,ry,rz=rest[i]
 if rz<.48 or x<left-.025 or x>right+.045:continue
 u=max(0,min(1,(x-left)/(right-left)));u2=u*u*(3-2*u)
 bottom=(Q.z-.066)*(1-u2)+(W.z-.145)*u2
 influence=smooth(left-.025,left+.010,x)*(1-smooth(right,right+.045,x))
 head=sum(g.weight for g in o.data.vertices[i].groups if names[g.group]=='tripo::Head_5');influence*=1-smooth(.88,.995,head)
 if z<bottom:goal[i,2]+=(bottom-z)*influence
 mask[i]=influence*(1-smooth(bottom+.025,bottom+.105,z))
adj=[set() for _ in range(N)]
for e in o.data.edges:
 i,j=e.vertices
 if i<N and j<N:adj[i].add(j);adj[j].add(i)
for k in range(12):
 out=goal.copy()
 for i in np.flatnonzero(mask>.001):
  if adj[i]:out[i]+=.30*mask[i]*(goal[list(adj[i])].mean(axis=0)-goal[i])
 goal=out
key=o.shape_key_add(name='WalkNeckCorrective');max_delta=0;changed=0
for v in o.data.vertices[:N]:
 delta=Vector(goal[v.index]-posed[v.index])
 if delta.length<1e-8:continue
 M=Matrix(((0,0,0,0),)*4)
 for g in v.groups:
  name=names[g.group]
  if name not in a.pose.bones:continue
  T=a.pose.bones[name].matrix@a.data.bones[name].matrix_local.inverted()
  for i in range(4):
   for j in range(4):M[i][j]+=g.weight*T[i][j]
 shift=M.to_3x3().inverted_safe()@delta;key.data[v.index].co=v.co+shift;max_delta=max(max_delta,shift.length);changed+=1
for index,root in json.loads(o['hair_root_vertices']).items():
 index=int(index);root=int(root);key.data[index].co=o.data.vertices[index].co+(key.data[root].co-o.data.vertices[root].co)
from mathutils.bvhtree import BVHTree
vg=names;polys=[tuple(p.vertices) for p in o.data.polygons if all(i<N for i in p.vertices)]
# Rebuild Walk mane locks on the corrected posed surface, then inverse-bind them.
# Rounded locks sit against the neck; each is still a closed six-sided volume.
posed_body_bvh=BVHTree.FromPolygons([Vector(v) for v in goal[:N]],polys)
def side_surface(x,z):
 hit=posed_body_bvh.ray_cast(Vector((x,-2,z)),Vector((0,1,0)))[0]
 return hit+Vector((0,-.0045,0)) if hit is not None else Vector((x,-.040,z))
def bind_hair(index,point):
 v=o.data.vertices[index];M=Matrix(((0,0,0,0),)*4)
 for g in v.groups:
  name=vg[g.group]
  if name not in a.pose.bones:continue
  T=a.pose.bones[name].matrix@a.data.bones[name].matrix_local.inverted()
  for i in range(4):
   for j in range(4):M[i][j]+=g.weight*T[i][j]
 key.data[index].co=M.inverted_safe()@point
layout=json.loads((P/'mane-lock-layout.json').read_text())
import random
rng=random.Random(713);clusters=[]
for group in range(13):
 members=layout[group*4:group*4+4];u=sum(lock['u'] for lock in members)/len(members);x=Q.x+.008+(W.x-Q.x-.020)*u
 root=posed_body_bvh.ray_cast(Vector((x,0,2)),Vector((0,0,-1)))[0]
 clusters.append({'root_x':x,'root_z':root.z,'lean':rng.uniform(.020,.045),'drop':rng.uniform(.004,.017),'bend':rng.uniform(-.004,.006),'side':rng.uniform(.001,.004)})
for tuft,lock in enumerate(layout):
 c=clusters[tuft//4];x=Q.x+.008+(W.x-Q.x-.020)*lock['u'];root=posed_body_bvh.ray_cast(Vector((x,0,2)),Vector((0,0,-1)))[0]
 if root is None:continue
 root+=Vector((0,-.001,.0008));tip_x=c['root_x']+c['lean']+.4*(x-c['root_x'])+rng.uniform(-.0015,.0015);tip_z=c['root_z']-c['drop']+rng.uniform(-.002,.002)
 mid=side_surface((x+tip_x)*.5+c['bend'],root.z*.5+tip_z*.5)+Vector((0,-c['side']*.7,0));tip=side_surface(tip_x,tip_z)+Vector((0,-c['side'],0));width=lock['width']*rng.uniform(.85,1.15)
 axis=(tip-root).normalized();side=axis.cross(Vector((0,1,0)))
 if side.length<.01:side=Vector((1,0,0))
 side.normalize();normal=axis.cross(side).normalized();points=[]
 for center,w in [(root,width),(mid,width*.72),(tip.lerp(mid,.08),width*.10)]:
  for j in range(4):
   theta=j*2*math.pi/4;points.append(center+side*w*math.cos(theta)+normal*w*.85*math.sin(theta))
 points.append(tip)
 for local,point in enumerate(points):bind_hair(N+tuft*13+local,point)
(P/'walk-mane-clusters.json').write_text(json.dumps({'round_bundles':52,'loose_clusters':13,'seed':713,'method':'short overlapping rear-swept round bundles lie close to the neck; adjacent loose locks overlap; exposed tips shortened; no broad flat leaf faces or long isolated tassels','clusters':clusters},indent=2))
# Closed underlay follows the same crest and side surface as the Walk locks.
for station in range(24):
 x=Q.x+.008+(W.x-Q.x-.020)*station/23;root=posed_body_bvh.ray_cast(Vector((x,0,2)),Vector((0,0,-1)))[0]
 if root is None:continue
 bottom=side_surface(x+.006,root.z-.009)
 points=[root+Vector((0,-.003,.0007)),root+Vector((0,.001,.0007)),bottom+Vector((0,.001,0)),bottom+Vector((0,-.001,0))]
 for j,point in enumerate(points):bind_hair(N+66*13+station*4+j,point)
# Preserve the five existing RaceNeckCorrective tracks and add one explicit Walk-only channel.
keys=o.data.shape_keys;keys.animation_data_create()
for clip in ['RaceGallop_Loop','Stand_Loop','Walk_Loop','Trot_Loop','Canter_Loop']:
 act=bpy.data.actions['Morph_'+clip]
 fc=act.fcurves.new(data_path='key_blocks["WalkNeckCorrective"].value');duration=next(x for x in a.animation_data.nla_tracks if x.name==clip).strips[0].action.frame_range[1]
 value=1.0 if clip=='Walk_Loop' else 0.0
 for frame in [1,duration]:fc.keyframe_points.insert(frame,value)
 for p in fc.keyframe_points:p.interpolation='LINEAR'
keys.animation_data.action=None
for tr in keys.animation_data.nla_tracks:tr.mute=True
key.value=0;o.data.shape_keys.key_blocks['RaceNeckCorrective'].value=0;a.animation_data.action=bpy.data.actions['Stand_Loop'];s.frame_set(1)
(P/'walk-neck-corrective.json').write_text(json.dumps({'changed_body_vertices':changed,'max_rest_delta_model':max_delta,'reference_walk_frame':1,'scope':'localized underside smoothing only; RaceNeckCorrective and all existing clips retain their original values','WalkNeckCorrective':{'Walk_Loop':1,'Stand_Loop':0,'RaceGallop_Loop':0,'Trot_Loop':0,'Canter_Loop':0}},indent=2));bpy.ops.wm.save_as_mainfile(filepath=str(P/'horse-gallop.blend'));print('WALK_CORRECTIVE',changed,max_delta)
