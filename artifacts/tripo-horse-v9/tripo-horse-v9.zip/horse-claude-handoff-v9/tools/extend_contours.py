from pathlib import Path
from PIL import Image,ImageDraw,ImageOps,ImageFilter
import numpy as np,json,math
P=Path(__file__).resolve().parent.parent;q=P/'reference-contours/final';obs=json.loads((P/'reference-observations.json').read_text());scale=obs['model_units_per_source_pixel']*800;offphase=obs['model_phase_offset']
def edge(mask):
 im=Image.fromarray((mask*255).astype('uint8'));return Image.fromarray(((np.array(im)>np.array(im.filter(ImageFilter.MinFilter(3))))*255).astype('uint8')).filter(ImageFilter.MaxFilter(3))
def mask(im):
 ar=np.array(im.convert('RGB')).astype(float);r,g,b=ar[:,:,0],ar[:,:,1],ar[:,:,2];return ((r>g*1.18)&(r>b*1.25)&(r>25))|((r+1>=g)&(g+1>=b))
sel12=[math.floor(i*15/12) for i in range(12)];sel8=[int(math.floor(i*15/8+.5)) for i in range(8)]
records=[]
for v in ['v8','v9']:
 c=Image.new('RGB',(1600,1000),'white');d=ImageDraw.Draw(c)
 for j,i in enumerate(sel12):
  im=Image.open(q/f'{v}-owner-run-{i+1:02}.png').crop((160,170,1480,960));im=ImageOps.contain(im,(400,300));c.paste(im,(j%4*400+(400-im.width)//2,j//4*333+30));d.text((j%4*400+5,j//4*333+5),f'{v} / VIDEO sample {j+1}/12 / src{i+1}/15',fill='black')
 c.save(q/f'{v}-video-derived-twelve.jpg',quality=95,subsampling=0)
 tracks=json.loads((P/('attachment-tracks.json' if v=='v9' else 'baseline/v8/attachment-tracks.json')).read_text())['clips']['Canter_Loop']['samples']
 for j,i in enumerate(sel8):
  t=(offphase+i/15)%1;k=t*(len(tracks)-1);k0=int(k);u=k-k0;w=np.array(tracks[k0]['nodes']['Withers']['position_model'])*(1-u)+np.array(tracks[min(k0+1,len(tracks)-1)]['nodes']['Withers']['position_model'])*u
  anchor=(800+800*w[0],900-800*w[1]);src=Image.open(P/'private-reference/user-video-1'/f'{i+1:03}.png');ar=np.asarray(src).astype(float);m=(ar[:,:,0]>ar[:,:,1]*1.12)&(ar[:,:,0]-ar[:,:,2]>15)&(ar[:,:,0]>20);im=Image.fromarray((m*255).astype('uint8')).transpose(Image.Transpose.FLIP_LEFT_RIGHT).resize((round(240*scale),round(144*scale)),Image.Resampling.BILINEAR);cont=edge(np.asarray(im)>127)
  row=obs['rows'][i];refanchor=((239-row['withers_px'][0])*scale,row['withers_px'][1]*scale);offset=(round(anchor[0]-refanchor[0]),round(anchor[1]-refanchor[1]));canvas=Image.new('RGB',(1600,1000),(245,246,248));canvas.paste((25,100,200),mask=edge(mask(Image.open(P/'reference-render/final'/f'{v}-canter-{j:03}.png'))));layer=Image.new('L',canvas.size);layer.paste(cont,offset);canvas.paste((215,60,40),mask=layer);d=ImageDraw.Draw(canvas);d.text((20,20),f'{v} Canter blue / owner RUN red src{i+1}/15; HEAD/NECK guidance only',fill='black');d.text((20,43),'Three-beat Canter feet differ by design. No direct Canter-foot reference; not a full silhouette match.',fill='black');canvas.save(q/f'{v}-owner-canter-guidance-{j:02}.png');records.append({'version':v,'source_frame':i+1,'model_phase':t,'withers_model':w.tolist(),'translation_px':offset})
(P/'canter-reference-guidance.json').write_text(json.dumps({'source_authority':'Owner latest running video, 2026-10-25','scope':'Head/neck guidance; Canter three-beat feet preserved. No claim that gallop-foot silhouette equals Canter.','derived_twelve_source_frames':[i+1 for i in sel12],'paid_twelve_sheet':'not available, not substituted or marked viewed','canter_source_frames':[i+1 for i in sel8],'captures':records},indent=2))
print('EXTENDED_CONTOURS_READY')
