"""Public-domain photo comparison; uniform scaling, declared crop/mirror only."""
from pathlib import Path
from PIL import Image,ImageOps,ImageDraw
import argparse,json
p=Path(__file__).resolve().parent.parent;a=argparse.ArgumentParser();a.add_argument('iteration');args=a.parse_args();q=p/'comparison'/args.iteration;out=q
def shot_path(name):
 f=q/name
 return f if f.exists() else f.with_suffix('.webp')
# v9 faces left; Muybridge faces right. Mirror each historical crop for comparison.
# Mapping is explicitly a visual phase correspondence, not a measured time sync.
mapping=[(3,0,'hind support / gathering'),(5,4,'gather -> reach'),(7,7,'fore reach / support'),(9,11,'fore support / rear extension'),(11,14,'late fore support'),(13,18,'release / gathering'),(15,21,'gathered flight'),(1,25,'rear reach / next support')]
canvas=Image.new('RGB',(1600,1000),(18,23,28));draw=ImageDraw.Draw(canvas)
for i,(photo,frame,note) in enumerate(mapping):
 col=i%4;half=i//4;px=col*400;py=half*500
 im=ImageOps.mirror(Image.open(p/'reference/muybridge-frames'/f'{photo:02}.jpg').convert('RGB'));im=ImageOps.contain(im,(392,215));canvas.paste(im,(px+(400-im.width)//2,py+25+(215-im.height)//2));draw.text((px+6,py+5),f'Photo {photo:02} (mirrored), Muybridge 1887',fill='white')
 im=Image.open(shot_path(f'v9-race-side-{frame:03}.png')).convert('RGB').crop((200,180,1480,930));im=ImageOps.contain(im,(392,215));canvas.paste(im,(px+(400-im.width)//2,py+275+(215-im.height)//2));draw.text((px+6,py+252),f'v9 frame {frame:02}, phase {frame/27:.3f}',fill='white')
canvas.save(out/'real-gallop-comparison.jpg',quality=96,subsampling=0)
canvas=Image.new('RGB',(1600,1000),(18,23,28));draw=ImageDraw.Draw(canvas)
for col,(name,im) in enumerate([('Irish Thoroughbred Stallion, Ridgeway 1905, fig129 p415',Image.open(p/'reference/thoroughbred-stand-pd.jpg').convert('RGB')),('v9 Stand; fixed model camera / no silhouette editing',Image.open(shot_path('v9-stand-side.png')).convert('RGB').crop((200,100,1450,960)))]):
 im=ImageOps.contain(im,(780,850));canvas.paste(im,(col*800+(800-im.width)//2,80+(850-im.height)//2));draw.text((col*800+10,25),name,fill='white')
draw.text((10,960),'Public-domain archival photos; uniform fit for visual comparison, not a scale-calibrated measurement.',fill='white');canvas.save(out/'real-stand-comparison.jpg',quality=96,subsampling=0)
(out/'real-photo-correspondence.json').write_text(json.dumps({'photo_source':'Wellcome Collection uwc8xuuu, Muybridge Animal Locomotion plate626,1887, PDM','standing_source':'Ridgeway1905 fig129 p415, archive.org origininfluenceo00ridgrich, NOT_IN_COPYRIGHT US','photo_transforms':'declared rectangular crops, 90-degree page rotation for standing photo; historical gallop crops mirrored horizontally; uniform contain-fit. No anisotropic scaling or retouching.','comparison_scope':'Visual support/gather/extension phase correspondence only. Photo speed and exact elapsed interval not known; this is not synchronized motion-capture validation. Selection wraps photo 15 -> 1; full16 plate included for audit.','pairs':[{'photo_number':ph,'model_frame':fr,'model_time_seconds':fr/60,'phase_description':nt} for ph,fr,nt in mapping]},indent=2))
print('REAL_PHOTO_SHEETS',out)
