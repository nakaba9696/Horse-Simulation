import bpy,math,json,re
import numpy as np
from pathlib import Path
from mathutils import Vector,Quaternion
OUT=Path(__file__).resolve().parent.parent
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=str(OUT/'source-rigged.glb'))
a=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');o=next(o for o in bpy.context.scene.objects if o.type=='MESH' and len(o.data.vertices)>1000)
for x in list(bpy.context.scene.objects):
 if x not in (a,o):bpy.data.objects.remove(x,do_unlink=True)
# Rest dimensions change along X only; bone count and names stay unchanged.
shorten=2.45/(float(o.dimensions.x)*2.6)
for vertex in o.data.vertices:vertex.co.x*=shorten
bpy.context.view_layer.objects.active=a
bpy.ops.object.mode_set(mode='EDIT')
for bone in a.data.edit_bones:
 bone.head.x*=shorten;bone.tail.x*=shorten
bpy.ops.object.mode_set(mode='OBJECT')
bpy.context.view_layer.update()
n=len(o.data.vertices);ng=len(o.vertex_groups);W=np.zeros((n,ng),dtype=float)
for v in o.data.vertices:
 for g in v.groups:W[v.index,g.group]=g.weight
original=W.copy();co=np.array([v.co[:] for v in o.data.vertices]);names={g.name:g.index for g in o.vertex_groups}
def smoothstep(lo,hi,x):
 t=max(0,min(1,(x-lo)/(hi-lo)));return t*t*(3-2*t)
# Remove nonlocal leg influences, with a soft transition at shoulder/hip and midline.
for v in o.data.vertices:
 x,y,z=v.co
 for g in o.vertex_groups:
  m=re.fullmatch(r'tripo::([01])_(Left|Right)_Limb_(\d+)',g.name)
  if not m:continue
  front=int(m[1])==0;left=m[2]=='Left'
  fore=1-smoothstep(-.04,.12,x)
  lateral=1-smoothstep(-.025,.025,y) if left else smoothstep(-.025,.025,y)
  low=1-smoothstep(.34,.49,z)
  W[v.index,g.index]*=(fore if front else 1-fore)*((1-low)+low*lateral)
 W[v.index]/=max(W[v.index].sum(),1e-12)
# Welded-position adjacency prevents UV-seam discontinuities during smoothing.
ids={};gid=[];groups=[]
for v in o.data.vertices:
 key=tuple(round(float(c),6) for c in v.co)
 if key not in ids:ids[key]=len(groups);groups.append([])
 i=ids[key];gid.append(i);groups[i].append(v.index)
adj=[set() for _ in groups]
for e in o.data.edges:
 i,j=(gid[k] for k in e.vertices)
 if i!=j:adj[i].add(j);adj[j].add(i)
G=np.array([W[g].mean(axis=0) for g in groups])
for iteration in range(7):
 N=G.copy()
 for i,neigh in enumerate(adj):
  if not neigh:continue
  z=co[groups[i][0],2];x=co[groups[i][0],0]
  # Local smoothing of limbs and shoulders; preserve face, mane and tail weighting.
  alpha=.32 if z<.50 else .15
  if x<-.27 or x>.38:alpha=.08
  N[i]=(1-alpha)*G[i]+alpha*G[list(neigh)].mean(axis=0)
 G=N
for i,g in enumerate(groups):W[g]=G[i]
# Restrict distal limb influence to its anatomical height, transferring to parent joints.
for vertex in o.data.vertices:
 row=W[vertex.index];z=vertex.co.z
 for limb in [0,1]:
  for side in ['Left','Right']:
   for joint,lo,hi in [(4,.09,.15),(3,.14,.23),(2,.30,.40),(1,.44,.53)]:
    child=names[f'tripo::{limb}_{side}_Limb_{joint}'];parent=names[f'tripo::{limb}_{side}_Limb_{joint-1}'];amount=row[child]*smoothstep(lo,hi,z);row[child]-=amount;row[parent]+=amount
   idx=names[f'tripo::{limb}_{side}_Limb_0'];amount=row[idx]*smoothstep(.46 if limb==0 else .50,.58 if limb==0 else .61,z)
   if amount>0:
    if vertex.co.x<-.20*shorten and z>.56:
     candidates=[b for b in a.data.bones if b.name in ['tripo::Spine_8','tripo::Spine_9','tripo::Head_0','tripo::Head_1','tripo::Head_2','tripo::Head_3']]
    else:candidates=[a.data.bones[f'tripo::Spine_{j}'] for j in range(8)]
    parent=min(candidates,key=lambda b:(vertex.co-(b.head_local+b.tail_local)/2).length)
    row[idx]-=amount;row[names[parent.name]]+=amount
 row/=row.sum()

# Keep four influences per vertex so GLB and game skinning agree.
for v in o.data.vertices:
 row=W[v.index];keep=np.argsort(row)[-4:];mask=np.ones(ng,dtype=bool);mask[keep]=False;row[mask]=0;row/=row.sum()
 for old in list(v.groups):o.vertex_groups[old.group].remove([v.index])
 for j in keep:
  if row[j]>1e-8:o.vertex_groups[int(j)].add([v.index],float(row[j]),'REPLACE')
changed=int(np.sum(np.max(abs(W-original),axis=1)>1e-5))

# Weld UV-seam duplicates geometrically while preserving per-loop UV layers.
# Identical source positions already share the same cleaned weights above.
import bmesh
bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-6);bm.to_mesh(o.data);bm.free();o.data.update()
bpy.context.view_layer.objects.active=o;bpy.ops.mesh.customdata_custom_splitnormals_clear()
for polygon in o.data.polygons:polygon.use_smooth=True

# Save the unanimated, cleaned rest model for reproducible downstream geometry and clips.
o.name='Horse'
(OUT/'build-info.json').write_text(json.dumps({'base_vertices':n,'changed_vertices':changed,'bone_count':len(a.data.bones),'shorten_x':shorten,'reference_scale':2.6,'source_body_length_meters':float(o.dimensions.x)*2.6},indent=2))
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'rest.blend'))
print('REST_READY',shorten)
