import bpy
from pathlib import Path
P=Path(__file__).resolve().parent.parent
bpy.ops.wm.open_mainfile(filepath=str(P/'horse-gallop.blend'))
o=bpy.data.objects['Horse'];bpy.context.view_layer.objects.active=o
bpy.ops.mesh.customdata_custom_splitnormals_clear()
for poly in o.data.polygons:poly.use_smooth=True
bpy.ops.wm.save_as_mainfile(filepath=str(P/'horse-gallop.blend'))
print('SMOOTH_NORMALS_READY')
