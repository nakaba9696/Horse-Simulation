"""Create undistorted Godot contact sheets, video, and rendered-normal audit."""
from pathlib import Path
from PIL import Image,ImageDraw
import subprocess,json,hashlib
import numpy as np
p=Path(__file__).resolve().parent.parent;r=p/'godot-renders'
def sheet(output,names,cols,rows):
 canvas=Image.new('RGB',(1600,1000),(20,25,30));draw=ImageDraw.Draw(canvas);w=1600//cols;h=1000//rows
 for j,name in enumerate(names):
  im=Image.open(r/(name+'.png')).convert('RGB');assert im.size==(1600,1000)
  if output in ['run-sheet','gaits-sheet']:im=im.crop((280,240,1320,840))
  im.thumbnail((w,h-24))
  x=j%cols*w+(w-im.width)//2;y=j//cols*h+24+(h-24-im.height)//2;canvas.paste(im,(x,y))
  draw.text((j%cols*w+10,j//cols*h+5),name,fill='white')
 canvas.save(p/(output+'.jpg'),quality=95,subsampling=0)
for out,names,cols,rows in [
 ('run-sheet',[f'race-side-{i:03}' for i in [0,3,7,10,14,17,21,24]],4,2),
 ('neck-shoulder-sheet',[f'neck-shoulder-{i:03}' for i in [0,7,14,21]],2,2),
 ('front-back-sheet',[f'race-{side}-{i:03}' for side in ['front','back'] for i in [0,14]],2,2),
 ('gaits-sheet',[f'{clip}-side-{i:03}' for clip in ['stand','walk','trot','canter'] for i in [0,50]],4,2)]:
 sheet(out,names,cols,rows)
# Individual closeup/front/back files remain full 1600x1000 in godot-renders.
audit=[]
for i in range(28):
 counts={}
 for kind in ['raw','protected']:
  a=np.asarray(Image.open(r/f'normal-{kind}-{i:03}.png').convert('RGB'))
  counts[kind+'_opposed_pixels']=int(((a[:,:,0]>180)&(a[:,:,1]<70)&(a[:,:,2]<70)).sum())
 audit.append({'frame':i,'time_seconds':i/60,**counts})
assert all(x['protected_opposed_pixels']==0 for x in audit),audit
manifest=json.loads((p/'godot-capture-manifest.json').read_text());sha=hashlib.sha256((p/'horse-gallop.glb').read_bytes()).hexdigest()
assert manifest['source_glb_sha256']==sha
(p/'normal-render-validation.json').write_text(json.dumps({'source_glb_sha256':sha,'renderer':manifest['adapter'],'resolution':[1600,1000],'camera':'full-body side view','samples':audit,'max_raw_opposed_pixels':max(x['raw_opposed_pixels'] for x in audit),'max_protected_opposed_pixels':0,'scope':'Visible rasterized body pixels at these cameras, not a proof of absence of hidden self-intersection. Audit replaces coat shading with geometric-normal hemisphere diagnostic; no normal map in audit. Production normal map strength is 0.03.','required_shader':'preview/coat.gdshader geometric hemisphere guard threshold 0.15'},indent=2))
subprocess.run(['ffmpeg','-y','-framerate','60','-i',str(r/'race-side-%03d.png'),'-vf','trim=end_frame=27,loop=loop=7:size=27:start=0,setpts=N/(60*TB),format=yuv420p','-frames:v','216','-c:v','libx264','-crf','20','-movflags','+faststart',str(p/'gallop-preview.mp4')],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
print('MEDIA_PASS',len(manifest['shots']),'frames; normal guard pixels 0')
