import bpy,json,math,re
from pathlib import Path
from mathutils import Vector
P=Path(__file__).resolve().parent.parent;specs=json.loads((P/'animation-specs.json').read_text())
final=P/'horse-gallop.glb'
if final.exists():
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.context.scene.render.fps=240;bpy.ops.import_scene.gltf(filepath=str(final));offset=0
else:bpy.ops.wm.open_mainfile(filepath=str(P/'animated.blend'));offset=1
s=bpy.context.scene;a=next(o for o in s.objects if o.type=='ARMATURE');o=next(o for o in s.objects if o.type=='MESH' and len(o.data.vertices)>1000)
regions={}
for v in o.data.vertices:
 if v.co.z>.055:continue
 w={}
 for g in v.groups:
  m=re.fullmatch(r'tripo::([01])_(Left|Right)_Limb_\d+',o.vertex_groups[g.group].name)
  if m:w[(int(m[1]),m[2])]=w.get((int(m[1]),m[2]),0)+g.weight
 if w:
  k=max(w,key=w.get)
  if w[k]>.5:regions.setdefault(k,[]).append(v.index)
report={}
for clip,sp in specs.items():
 for tr in a.animation_data.nla_tracks:tr.mute=True
 action=next(x for x in bpy.data.actions if x.name.startswith(clip) and any(fc.data_path.startswith('pose.bones') for fc in x.fcurves));a.animation_data.action=action
 if o.data.shape_keys:
  o.data.shape_keys.animation_data_clear()
  for key in o.data.shape_keys.key_blocks:
   if key.name!='Basis':key.value=(1 if clip=='Walk_Loop' else 0) if key.name=='WalkNeckCorrective' else (0 if clip in ['Stand_Loop','Walk_Loop'] else 1)
 rows=[];first=None;loop=0
 for sample in range(241):
  t=sample/240;frame=offset+t*sp['duration']*240;s.frame_set(int(frame),subframe=frame-int(frame));bpy.context.view_layer.update();ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=ev.to_mesh();coords=[o.matrix_world@v.co for v in m.vertices]
  if first is None:first=[c.copy() for c in coords]
  if sample==240:loop=max((c-d).length for c,d in zip(coords,first))
  feet={}
  phases={(g,side):phase for g,side,phase in sp['phases']}
  for key,indices in regions.items():
   vs=[coords[i] for i in indices];mean=sum(vs,Vector())/len(vs);feet[str(key)]={'centroid':list(mean),'minimum_y_up':min(v.z for v in vs),'expected_stance':(t-phases[key])%1<sp['stance']}
  withers=a.matrix_world@a.pose.bones['tripo::Spine_7'].head
  rows.append({'phase':t,'time_seconds':t*sp['duration'],'feet':feet,'withers_y_up':withers.z,'airborne':all(v['minimum_y_up']*2.6>.015 for v in feet.values())})
  ev.to_mesh_clear()
 summary={'duration':sp['duration'],'samples':241,'airborne_threshold_m':.015,'airborne_fraction':sum(r['airborne'] for r in rows[:-1])/240,'withers_peak_to_peak_m':(max(r['withers_y_up'] for r in rows)-min(r['withers_y_up'] for r in rows))*2.6,'withers_min_phase':min(rows,key=lambda r:r['withers_y_up'])['phase'],'withers_max_phase':max(rows,key=lambda r:r['withers_y_up'])['phase'],'loop_max_vertex_difference':loop,'minimum_hoof_m':min(f['minimum_y_up'] for r in rows for f in r['feet'].values())*2.6,'legs':{}}
 for key,phase in phases.items():
  data=[r for r in rows[:-1] if r['feet'][str(key)]['expected_stance']]
  xs=[((r['phase']-phase)%1)*sp['duration'] for r in data];ys=[r['feet'][str(key)]['centroid'][0] for r in data];mx=sum(xs)/len(xs);my=sum(ys)/len(ys);den=sum((x-mx)**2 for x in xs)
  slope=sum((x-mx)*(y-my) for x,y in zip(xs,ys))/den if den else 0
  summary['legs'][str(key)]={'fitted_stride_m':slope*sp['duration']*2.6,'stance_height_variation_m':(max(r['feet'][str(key)]['centroid'][2] for r in data)-min(r['feet'][str(key)]['centroid'][2] for r in data))*2.6}
 report[clip]={'summary':summary,'frames':rows};print(clip,json.dumps(summary),flush=True)
(P/'motion-validation.json').write_text(json.dumps(report,indent=2))
