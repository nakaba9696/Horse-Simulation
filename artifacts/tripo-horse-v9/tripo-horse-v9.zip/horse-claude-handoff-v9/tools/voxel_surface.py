"""External Python stage: NumPy, SciPy, scikit-image, trimesh."""
from pathlib import Path
import numpy as np,json
from scipy import ndimage
from skimage import measure,morphology
import trimesh
P=Path(__file__).resolve().parent.parent
source=np.load(P/'repair-input.npz');mesh=trimesh.Trimesh(source['vertices'],source['faces'],process=True)
pitch=.003
vox=mesh.voxelized(pitch,method='subdivide');grid=np.pad(vox.matrix,8)
# Close holes and thin internal folds, then retain the filled exterior volume.
closed=ndimage.binary_closing(grid,structure=morphology.ball(3));solid=ndimage.binary_fill_holes(closed)
# Fill slice-visible cavities as well: source self-intersections can leave narrow
# tunnels through the shell that a 3D cavity fill alone cannot remove.
for axis in range(3):
 view=np.moveaxis(solid,axis,0)
 for i in range(len(view)):
  view[i]=ndimage.binary_fill_holes(view[i])
solid=ndimage.binary_fill_holes(ndimage.binary_closing(solid,structure=morphology.ball(2)))
labels,count=ndimage.label(solid);sizes=np.bincount(labels.ravel());sizes[0]=0;solid=labels==sizes.argmax()
vertices,faces,normals,values=measure.marching_cubes(solid.astype(np.float32),level=.5,spacing=(pitch,)*3,allow_degenerate=False)
vertices+=vox.transform[:3,3]-8*pitch
result=trimesh.Trimesh(vertices,faces,process=True);result.fix_normals();assert result.is_watertight
np.savez(P/'repair-output.npz',vertices=result.vertices,faces=result.faces)
(P/'voxel-repair.json').write_text(json.dumps({'pitch_model':pitch,'closing_radius_voxels':3,'filled_voxels':int(solid.sum()),'watertight_before_decimation':bool(result.is_watertight),'triangles_before_decimation':len(result.faces),'method':'surface voxelization, spherical morphological closing, enclosed-volume fill, largest solid, marching cubes'},indent=2))
print('VOXEL_SURFACE_READY',len(result.vertices),len(result.faces),flush=True)
