"""Closed remeshing and local skin cleanup of the original V4-rest body."""
import bpy,bmesh,numpy as np,json,math
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from mathutils.geometry import barycentric_transform
P=Path(__file__).resolve().parent.parent
bpy.ops.wm.open_mainfile(filepath=str(P/'rest.blend'))
o=bpy.data.objects['Horse'];a=next(x for x in bpy.context.scene.objects if x.type=='ARMATURE')
bpy.context.view_layer.objects.active=o;bpy.ops.object.select_all(action='DESELECT');o.select_set(True)
for modifier in list(o.modifiers):o.modifiers.remove(modifier)
source=o.copy();source.data=o.data.copy();source.name='WeightUVReference';bpy.context.scene.collection.objects.link(source)
bm=bmesh.new();bm.from_mesh(source.data);bmesh.ops.triangulate(bm,faces=list(bm.faces));bm.to_mesh(source.data);bm.free();source.data.update()
verts=[v.co.copy() for v in source.data.vertices];faces=[tuple(p.vertices) for p in source.data.polygons];bvh=BVHTree.FromPolygons(verts,faces,all_triangles=True)
weights=[{g.group:g.weight for g in v.groups} for v in source.data.vertices]
uvs=[[source.data.uv_layers[0].data[i].uv.copy() for i in p.loop_indices] for p in source.data.polygons]
def smooth(lo,hi,x):
 t=max(0,min(1,(x-lo)/(hi-lo)));return t*t*(3-2*t)
vg=o.vertex_groups.new(name='RepairMask')
for v in o.data.vertices:
 x,y,z=v.co;w=smooth(-.38,-.31,x)*(1-smooth(-.02,.12,x))*smooth(.30,.49,z)*(1-smooth(.80,.85,z))
 if w>0:vg.add([v.index],w,'REPLACE')
mod=o.modifiers.new('Remove sculpted neck ridges','SMOOTH');mod.factor=.7;mod.iterations=35;mod.vertex_group=vg.name;bpy.ops.object.modifier_apply(modifier=mod.name);print('MOD','applied',len(o.data.vertices),len(o.data.polygons),tuple(o.dimensions),flush=True)
# Rasterize the prepared surface and reconstruct a filled watertight volume.
# External scientific Python keeps the morphology deterministic and inspectable.
import subprocess,os
bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.triangulate(bm,faces=list(bm.faces));bm.to_mesh(o.data);bm.free()
np.savez(P/'repair-input.npz',vertices=np.array([v.co[:] for v in o.data.vertices]),faces=np.array([p.vertices[:] for p in o.data.polygons],dtype=np.int32))
subprocess.run([os.environ.get('HORSE_REPAIR_PYTHON','python'),str(P/'tools'/'voxel_surface.py')],check=True)
repaired=np.load(P/'repair-output.npz');mesh=bpy.data.meshes.new('RepairedBody');mesh.from_pydata(repaired['vertices'].tolist(),[],repaired['faces'].tolist());mesh.update()
for mat in o.data.materials:mesh.materials.append(mat)
o.data=mesh
# Preserve room for rounded closed hair tufts and existing tack.
mod=o.modifiers.new('Body triangle budget','DECIMATE');mod.use_collapse_triangulate=True;mod.ratio=min(1,15400/max(1,sum(len(p.vertices)-2 for p in o.data.polygons)));bpy.ops.object.modifier_apply(modifier=mod.name);print('MOD','applied',len(o.data.vertices),len(o.data.polygons),tuple(o.dimensions),flush=True)
mod=o.modifiers.new('Surface relaxation','SMOOTH');mod.factor=.10;mod.iterations=1;bpy.ops.object.modifier_apply(modifier=mod.name);print('MOD','applied',len(o.data.vertices),len(o.data.polygons),tuple(o.dimensions),flush=True)
# Volume-preserving Taubin relaxation removes voxel/decimation micro-facets.
co=np.array([v.co[:] for v in o.data.vertices]);adjacency=[set() for _ in co]
for edge in o.data.edges:
 i,j=edge.vertices;adjacency[i].add(j);adjacency[j].add(i)
for iteration in range(10):
 for strength in [.5,-.53]:
  updated=co.copy()
  for i,neighbors in enumerate(adjacency):
   if neighbors:updated[i]+=strength*(co[list(neighbors)].mean(axis=0)-co[i])
  co=updated
for v,point in zip(o.data.vertices,co):v.co=point
# Enforce a centered rest surface, then shape the upper neck before skin binding.
# This avoids a large inverse-skin morph that can fold normals in the bind shape.
bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.symmetrize(bm,input=list(bm.verts)+list(bm.edges)+list(bm.faces),direction='-Y',dist=1e-6);bmesh.ops.triangulate(bm,faces=list(bm.faces));bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(o.data);bm.free();o.data.update()
crest_bvh=BVHTree.FromPolygons([v.co for v in o.data.vertices],[list(p.vertices) for p in o.data.polygons])
wx=float(a.data.bones['tripo::Spine_7'].head_local.x);wz=float(a.data.bones['tripo::Spine_7'].head_local.z)+.025;px=-.315
poll=crest_bvh.find_nearest(Vector((px,0,.801)))[0];pz=float(poll.z)
xs=np.linspace(px,wx+.14,100);tops=[]
for x in xs:
 hit=crest_bvh.ray_cast(Vector((x,0,2)),Vector((0,0,-1)))[0];tops.append(hit.z if hit is not None else wz)
for v in o.data.vertices:
 x,y,z=v.co
 if not(px<x<wx+.14) or z<.43:continue
 top=float(np.interp(x,xs,tops));u=(wx-x)/(wx-px)
 if u<0:target=wz+(tops[-1]-wz)*max(0,min(1,(x-wx)/.14))
 else:target=wz+(pz-wz)*u+.002*math.sin(math.pi*u)
 depth=.19*(1-max(0,min(1,u)))+.065*max(0,min(1,u))
 v.co.z+=(target-top)*smooth(top-depth,top-.008,z)
o.data.update()
for vg in list(o.vertex_groups):o.vertex_groups.remove(vg)
for g in source.vertex_groups:o.vertex_groups.new(name=g.name)
W=np.zeros((len(o.data.vertices),len(o.vertex_groups)));hits=[]
for v in o.data.vertices:
 hit,normal,idx,dist=bvh.find_nearest(v.co);indices=faces[idx]
 bary=barycentric_transform(hit,*[verts[i] for i in indices],Vector((1,0,0)),Vector((0,1,0)),Vector((0,0,1)));bary=[max(0,float(q)) for q in bary];total=sum(bary);bary=[q/total for q in bary]
 hits.append((idx,bary))
 for i,amount in zip(indices,bary):
  for group,value in weights[i].items():W[v.index,group]+=amount*value
names={g.name:g.index for g in o.vertex_groups}
# Upper chest/neck is carried by the spine, not distal or opposite-side leg bones.
for v in o.data.vertices:
 x,y,z=v.co;row=W[v.index]
 candidates=[a.data.bones[f'tripo::Spine_{j}'] for j in range(4,8)]
 parent=min(candidates,key=lambda b:abs(x-b.head_local.x));parent_id=names[parent.name]
 for g in o.vertex_groups:
  if 'Limb_' not in g.name and g.name not in ['bone_23','bone_29']:continue
  fore='::0_' in g.name or g.name in ['bone_23','bone_29']
  cut=smooth(.40,.52,z) if fore else smooth(.50,.63,z)
  if fore:cut=max(cut,(1-smooth(.025,.055,abs(y)))*smooth(.30,.44,z))
  amount=row[g.index]*cut;row[g.index]-=amount;row[parent_id]+=amount
 # Neck weights interpolate by height along the existing neck chain.
 neck=smooth(.50,.59,z)*(1-smooth(-.16,-.08,x))*smooth(-.38,-.31,x)
 if neck>0:
  chain=['tripo::Spine_8','tripo::Spine_9','tripo::Head_0','tripo::Head_1','tripo::Head_2','tripo::Head_3','tripo::Head_4','tripo::Head_5']
  levels=[a.data.bones[n].head_local.z for n in chain];target=np.zeros_like(row)
  index=max(0,min(len(chain)-2,next((i for i in range(len(levels)-1) if z<=levels[i+1]),len(chain)-2)))
  u=max(0,min(1,(z-levels[index])/(levels[index+1]-levels[index])));u=u*u*(3-2*u);target[names[chain[index]]]=1-u;target[names[chain[index+1]]]=u
  row*=1-neck;row+=neck*target
 row/=max(row.sum(),1e-12)
# Diffuse weights directly on the repaired topology; welded vertices share weights.
adj=[set() for _ in o.data.vertices]
for edge in o.data.edges:
 i,j=edge.vertices;adj[i].add(j);adj[j].add(i)
for iteration in range(6):
 N=W.copy()
 for v in o.data.vertices:
  if v.co.z>.30 and adj[v.index]:N[v.index]=.7*W[v.index]+.3*W[list(adj[v.index])].mean(axis=0)
 W=N
# Use local, continuous two-bone fields instead of transferred nonlocal influences.
# All torso bones share the same baked body transform; neck is a smooth torso/skull blend.
for v in o.data.vertices:
 x,y,z=v.co;old=W[v.index].copy();row=np.zeros_like(old);row[names['tripo::Spine_3']]=1
 tail=sum(old[g.index] for g in o.vertex_groups if 'Tail' in g.name or g.name in ['bone_35','bone_36','bone_37','bone_38','bone_39','bone_43'])
 if x>.30 and tail>.5:row=old
 else:
  if z<(.59 if x>0 else .51):
   limb=1 if x>0 else 0;side='Left' if y<0 else 'Right';bones=[a.data.bones[f'tripo::{limb}_{side}_Limb_{i}'] for i in range(5)]
   best=(1e9,0.)
   for j,b in enumerate(bones):
    d=b.tail_local-b.head_local;u=max(0,min(1,(v.co-b.head_local).dot(d)/max(d.length_squared,1e-12)));dist=(v.co-(b.head_local+u*d)).length
    if dist<best[0]:best=(dist,j+u)
   value=max(0,min(4,best[1]-.5));lo=int(math.floor(value));hi=min(4,lo+1);u=value-lo;u=u*u*(3-2*u);leg=np.zeros_like(row);leg[names[bones[lo].name]]=1-u;leg[names[bones[hi].name]]+=u
   blend=1-smooth(.35,.52,z) if limb else 1-smooth(.25,.40,z)
   blend*=1-smooth(.045,.115,max(0,best[0]-.008))
   if z>.30:blend*=smooth(.014,.045,abs(y))
   row=row*(1-blend)+leg*blend
  neck=smooth(.48,.56,z)*(1-smooth(-.15,-.08,x))
  if neck>0:
   u=max(0,min(1,(wx-x)/(wx-px)));neckrow=np.zeros_like(row);neckrow[names['tripo::Spine_7']]=1-u;neckrow[names['tripo::Head_5']]=u;row=row*(1-neck)+neckrow*neck
  head=(1-smooth(-.34,-.29,x))*smooth(.48,.63,z)
  if x<-.38 and z>.48:head=1.
  if head>0:
   headrow=np.zeros_like(row);headrow[names['tripo::Head_5']]=1;row=row*(1-head)+headrow*head
  ear_indices=[g.index for g in o.vertex_groups if g.name in ['tripo::Head_6','tripo::Head_7','tripo::Head_8','bone_20','bone_21','bone_22']]
  ear=sum(old[j] for j in ear_indices)
  if z>.79 and ear>.5:
   row*=1-ear
   for j in ear_indices:row[j]+=old[j]
 W[v.index]=row/max(row.sum(),1e-12)
for v in o.data.vertices:
 row=W[v.index];keep=np.argsort(row)[-4:];total=sum(row[j] for j in keep)
 for j in keep:
  if row[j]>1e-8:o.vertex_groups[int(j)].add([v.index],float(row[j]/total),'REPLACE')
# Transfer the original embedded normal-map UV; its strength is reduced for the new surface.
uv=o.data.uv_layers.get('UVMap') or o.data.uv_layers.new(name='UVMap')
for loop in o.data.loops:
 idx,bary=hits[loop.vertex_index];uv.data[loop.index].uv=sum((u*w for u,w in zip(uvs[idx],bary)),Vector((0,0)))
for poly in o.data.polygons:poly.use_smooth=True
for mat in o.data.materials:
 for node in mat.node_tree.nodes:
  if node.type=='NORMAL_MAP':node.inputs['Strength'].default_value=.03
bpy.data.objects.remove(source,do_unlink=True)
bpy.context.view_layer.objects.active=o;bpy.ops.mesh.customdata_custom_splitnormals_clear()
# Voxel sampling may move hoof soles: restore each leg's minimum to the source sole.
for limb in [0,1]:
 for side in ['Left','Right']:
  prefix=f'tripo::{limb}_{side}_Limb_';ids={g.index for g in o.vertex_groups if g.name.startswith(prefix)}
  subset=[v for v in o.data.vertices if v.co.z<.055 and sum(g.weight for g in v.groups if g.group in ids)>.5]
  if subset:
   low=min(v.co.z for v in subset)
   for v in subset:v.co.z-=low-.0004
bm=bmesh.new();bm.from_mesh(o.data);boundary=sum(e.is_boundary for e in bm.edges);nonmanifold=sum(not e.is_manifold for e in bm.edges);bm.free()
assert boundary==0 and nonmanifold==0,(boundary,nonmanifold)
report={'body_vertices':len(o.data.vertices),'body_triangles':len(o.data.polygons),'boundary_edges':boundary,'nonmanifold_edges':nonmanifold,'voxel_size_model':.003,'normal_map_strength':.03,'method':'Local ridge smoothing, closed voxel remesh, decimation, barycentric weight/UV transfer and anatomical chest/neck weights'}
(P/'surface-repair.json').write_text(json.dumps(report,indent=2));print('SURFACE_REPAIR',json.dumps(report))
mod=o.modifiers.new('Armature','ARMATURE');mod.object=a
bpy.ops.wm.save_as_mainfile(filepath=str(P/'rest.blend'))
