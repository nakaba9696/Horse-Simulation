import json,struct
from pathlib import Path
P=Path(__file__).resolve().parent.parent
raw=(P/'horse-gallop.glb').read_bytes();n=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+n]);payload=raw[28+n:]
import numpy as np
component={5121:np.uint8,5123:np.uint16,5125:np.uint32,5126:np.float32,5120:np.int8,5122:np.int16}
size_by_type={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
def read_accessor(index):
 ac=d['accessors'][index];cols=size_by_type[ac['type']];dtype=np.dtype(component[ac['componentType']]);out=np.zeros((ac['count'],cols),dtype=dtype)
 if 'bufferView' in ac:
  bv=d['bufferViews'][ac['bufferView']];off=bv.get('byteOffset',0)+ac.get('byteOffset',0);stride=bv.get('byteStride',cols*dtype.itemsize);out=np.ndarray((ac['count'],cols),dtype=dtype,buffer=payload,offset=off,strides=(stride,dtype.itemsize)).copy()
 if 'sparse' in ac:
  sparse=ac['sparse'];iv=sparse['indices'];ib=d['bufferViews'][iv['bufferView']];indices=np.frombuffer(payload,dtype=component[iv['componentType']],count=sparse['count'],offset=ib.get('byteOffset',0)+iv.get('byteOffset',0));vv=sparse['values'];vb=d['bufferViews'][vv['bufferView']];values=np.frombuffer(payload,dtype=dtype,count=sparse['count']*cols,offset=vb.get('byteOffset',0)+vv.get('byteOffset',0)).reshape(-1,cols);out[indices]=values
 return out

report={'finite_float_accessors':True,'meshes':{},'normal_lengths':{}}
for index,accessor in enumerate(d['accessors']):
 if accessor['componentType']==5126:assert np.isfinite(read_accessor(index)).all(),index
for mesh in d['meshes']:
 count=0
 for primitive in mesh['primitives']:
  count+=d['accessors'][primitive['indices']]['count']//3
  attrs=primitive['attributes']
  if 'NORMAL' in attrs:
   normal=read_accessor(attrs['NORMAL']);length=np.linalg.norm(normal,axis=1)
   report['normal_lengths'][mesh['name']]={'base_min':float(length.min()),'base_max':float(length.max())}
   assert length.min()>.99 and length.max()<1.01
   for target in primitive.get('targets',[]):
    if 'NORMAL' in target:
     length=np.linalg.norm(normal+read_accessor(target['NORMAL']),axis=1)
     report['normal_lengths'][mesh['name']].update({'corrective_min':float(length.min()),'corrective_max':float(length.max())})
     assert length.min()>.99 and length.max()<1.01
 report['meshes'][mesh['name']]=count
report['bones']=len(d['skins'][0]['joints']);assert report['bones']==54
# v7 shader's immutable face coordinates must be the first active color channel.
body=next(m for m in d['meshes'] if m.get('extras',{}).get('targetNames'))
assert body['extras']['targetNames']==['RaceNeckCorrective','WalkNeckCorrective']
for primitive in body['primitives']:
 assert 'COLOR_0' in primitive['attributes'] and 'COLOR_1' not in primitive['attributes']
 colors=read_accessor(primitive['attributes']['COLOR_0']);report['face_coordinates']={'attribute':'COLOR_0','components':4,'alpha_has_enabled_and_disabled':bool(colors[:,3].min()<colors[:,3].max()),'morphs':body['extras']['targetNames']}
 assert report['face_coordinates']['alpha_has_enabled_and_disabled']
(P/'gltf-validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
