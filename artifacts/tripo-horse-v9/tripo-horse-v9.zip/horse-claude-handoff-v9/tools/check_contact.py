"""Contact-centroid residual speed at 16 m/s, using final GLB samples."""
import json,math,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent.parent;doc=json.loads((p/'motion-validation.json').read_text());rows=doc['RaceGallop_Loop']['frames'];speed=16.;scale=2.6;playback=speed*.45/7;legs={}
for key in rows[0]['feet']:
 values=[];interior=[]
 for a,b in zip(rows,rows[1:]):
  fa=a['feet'][key];fb=b['feet'][key]
  if not(fa['expected_stance'] and fb['expected_stance']):continue
  dt=b['time_seconds']-a['time_seconds'];delta=[(fb['centroid'][i]-fa['centroid'][i])*scale/dt*playback for i in range(3)];delta[0]-=speed
  value=math.sqrt(sum(v*v for v in delta));values.append(value)
  phase=next(x[2] for x in json.loads((p/'animation-specs.json').read_text())['RaceGallop_Loop']['phases'] if key==str((x[0],x[1])))
  margin=1/108
  if margin<((a['phase']-phase)%1)<.20-margin and margin<((b['phase']-phase)%1)<.20-margin:interior.append(value)
 legs[key]={'samples':len(values),'rms_world_centroid_slip_mps':math.sqrt(sum(v*v for v in values)/len(values)),'max_world_centroid_slip_mps':max(values),'interior_excluding_one_baked_key_from_contact_edges':{'margin_normalized_cycle':1/108,'samples':len(interior),'rms_mps':math.sqrt(sum(v*v for v in interior)/len(interior)),'max_mps':max(interior)}}
result={'source_glb_sha256':hashlib.sha256((p/'horse-gallop.glb').read_bytes()).hexdigest(),'speed_mps':speed,'reference_scale':scale,'playback':playback,'method':'Finite differences of final GLB hoof skin vertex centroids while both adjacent samples are scheduled stance; includes xyz. Skin centroid can move from hoof deformation; not individual contact-patch static friction.','legs':legs}
(p/'contact-validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
