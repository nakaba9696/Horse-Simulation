from pathlib import Path
from PIL import Image,ImageOps,ImageDraw
import subprocess,tempfile,argparse
p=Path(__file__).resolve().parent.parent;a=argparse.ArgumentParser();a.add_argument('iteration');args=a.parse_args();q=p/'comparison'/args.iteration
with tempfile.TemporaryDirectory(prefix='horse-compare-') as name:
 tmp=Path(name)
 for n in range(27):
  c=Image.new('RGB',(1600,1000),(18,23,28));d=ImageDraw.Draw(c)
  for j,v in enumerate(['v7','v8','v9']):
   for r,view in enumerate(['side','neck']):
    f=q/f'{v}-race-{view}-{n:03}.png'
    if not f.exists():f=f.with_suffix('.webp')
    im=Image.open(f).convert('RGB');im=ImageOps.contain(im,(533,470));c.paste(im,(j*533+(533-im.width)//2,r*500+25+(470-im.height)//2));d.text((j*533+10,r*500+5),f'{v} {view} frame {n:02} t={n/60:.4f}s',fill='white')
  c.save(tmp/f'{n:03}.png')
 subprocess.run(['ffmpeg','-y','-v','error','-framerate','60','-stream_loop','7','-i',str(tmp/'%03d.png'),'-frames:v','216','-c:v','libx264','-threads','4','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart',str(p/'comparison-preview.mp4')],check=True)
print('COMPARISON_VIDEO_READY')
