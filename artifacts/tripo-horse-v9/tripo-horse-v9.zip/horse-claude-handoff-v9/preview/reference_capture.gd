extends SceneTree
var scene: Node3D
var shots=[]
func _initialize():call_deferred('run')
func capture(name,time):
 scene.player.seek(time,true);scene.player.advance(0)
 for skeleton in scene.model.find_children('*','Skeleton3D',true,false):skeleton.force_update_all_bone_transforms()
 for i in range(3):await process_frame
 await RenderingServer.frame_post_draw
 var path=ProjectSettings.globalize_path('res://../reference-render/'+OS.get_cmdline_user_args()[0]+'/'+name+'.png')
 assert(root.get_texture().get_image().save_png(path)==OK);shots.append(name+'.png')
func run():
 var label=OS.get_cmdline_user_args()[0];var out=ProjectSettings.globalize_path('res://../reference-render/'+label);DirAccess.make_dir_recursive_absolute(out)
 var hashes={}
 for version in (['v8'] if '--only-v8' in OS.get_cmdline_user_args() else ['v8','v9']):
  scene=load('res://main.tscn').instantiate();scene.model_path='res://assets/horse.glb' if version=='v9' else 'res://assets/v8.glb';hashes[version]=FileAccess.get_sha256(scene.model_path);root.add_child(scene)
  for i in range(3):await process_frame
  for layer in scene.find_children('*','CanvasLayer',true,false):layer.visible=false
  scene.player.callback_mode_process=AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL
  scene.camera.position=Vector3(0,.50,3);scene.camera.look_at(Vector3(0,.50,0));scene.camera.size=1.25
  scene.player.play('RaceGallop',0)
  for f in range(15):await capture(version+'-race-%03d'%f,fposmod(79.0/240+float(f)/15,1)*.45)
  scene.player.play('Stand',0);await capture(version+'-stand',0)
  # Owner latest authority: use running head/neck as Canter guidance, preserve three-beat feet.
  # Eight phases of the running source, not a claim of direct Canter footage.
  scene.player.play('Canter',0)
  for f in range(8):await capture(version+'-canter-%03d'%f,scene.player.get_animation('Canter').length*fposmod(79.0/240+float(round(f*15.0/8))/15,1))
  scene.player.play('Walk',0)
  for f in range(8):await capture(version+'-walk-side-%03d'%f,scene.player.get_animation('Walk').length*f/8)
  # Camera approximates oblique source video; not a true side-view reconstruction.
  scene.camera.position=Vector3(-3,1.1,1.6);scene.camera.look_at(Vector3(0,.45,0));scene.camera.size=1.25
  for f in range(8):await capture(version+'-walk-oblique-%03d'%f,scene.player.get_animation('Walk').length*f/8)
  scene.queue_free();for i in range(3):await process_frame
 if '--only-v8' in OS.get_cmdline_user_args():
  var prev=JSON.parse_string(FileAccess.get_file_as_string(out.path_join('capture-manifest.json')))
  for v in prev.versions_glb_sha256:hashes[v]=prev.versions_glb_sha256[v]
  shots=prev.shots
 var file=FileAccess.open(out.path_join('capture-manifest.json'),FileAccess.WRITE)
 file.store_string(JSON.stringify({'versions_glb_sha256':hashes,'size':[1600,1000],'race_ref_frames':15,'race_phase_offset':79.0/240,'race_sampling':'(reference frame/15 +79/240)%1, constant phase offset, no time warping','side_camera':{'position':[0,.50,3],'target':[0,.50,0],'orthographic_size':1.25},'walk_oblique':'Approximate source viewpoint; do not claim source is a side view','canter_reference':'Owner designated running video; eight source phases guide head/neck, not a direct Canter-foot comparison; three-beat feet retained','preview_recipe_sha256':FileAccess.get_sha256('res://preview.gd'),'shader_sha256':FileAccess.get_sha256('res://coat.gdshader'),'shots':shots},'  '));print('REFERENCE_CAPTURE_READY ',shots.size());quit()
