extends "res://compare_capture.gd"
func run():
 var args=OS.get_cmdline_user_args();var label=args[0] if args.size()>0 else 'tv-final';output=ProjectSettings.globalize_path('res://../comparison/'+label);DirAccess.make_dir_recursive_absolute(output)
 var src=JSON.parse_string(FileAccess.get_file_as_string('res://../reference/tv-camera-source.json'));var height=1.2
 views['tv']={'position':Vector3(0,(height+src.vertical_offset_m)/2.6,src.horizontal_distance_m/2.6),'target':Vector3(0,height/2.6,0),'size':1.25}
 var hashes={}
 for v in ['v7','v8','v9']:
  version=v;var path='res://assets/horse.glb' if v=='v9' else 'res://assets/'+v+'.glb';hashes[v]=FileAccess.get_sha256(path)
  scene=load('res://main.tscn').instantiate();scene.model_path=path;root.add_child(scene)
  for i in range(3):await process_frame
  for layer in scene.find_children('*','CanvasLayer',true,false):layer.visible=false
  for m in scene.find_children('*','MeshInstance3D',true,false):
   if m.mesh is PlaneMesh:m.mesh.size=Vector2(160,160)
  scene.camera.projection=Camera3D.PROJECTION_PERSPECTIVE;scene.camera.fov=src.vertical_fov_degrees;scene.camera.keep_aspect=Camera3D.KEEP_HEIGHT;scene.camera.far=500
  scene.player.callback_mode_process=AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL;scene.player.play('RaceGallop',0);scene.coat_material.set_shader_parameter('normal_strength',.03)
  for lod in [1.0,16.0]:
   for m in scene.model.find_children('*','MeshInstance3D',true,false):m.lod_bias=lod
   for frame in [0,7,14,21]:await shot('tv-lod%d-%03d'%[int(lod),frame],float(frame)/60,'tv')
  scene.queue_free()
  for i in range(3):await process_frame
 var manifest={'versions_glb_sha256':hashes,'shader_sha256':FileAccess.get_sha256('res://coat.gdshader'),'size':[1600,1000],'renderer':RenderingServer.get_video_adapter_name(),'source_camera':src,'preview_view':{'position_model':str(views.tv.position),'target_model':str(views.tv.target),'projection':'perspective','vertical_fov':src.vertical_fov_degrees,'reference_scale':2.6},'lod_bias':[1,16],'shots':shots,'scope':'Distance/FOV/elevation obtained from an unmodified isolated game checkout at T=20. Subject recentered and side-aligned on a flat standalone ground; no riders/HUD/real game background. Native full-frame pixels preserved, no subject magnification.'}
 var f=FileAccess.open(output.path_join('capture-manifest.json'),FileAccess.WRITE);f.store_string(JSON.stringify(manifest,'  '));print('TV_CAPTURE_READY');quit()
