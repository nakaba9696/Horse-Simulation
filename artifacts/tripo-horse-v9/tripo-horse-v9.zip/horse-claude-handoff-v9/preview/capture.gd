extends SceneTree
var scene: Node3D
var output: String
var shots: Array[String]=[]
func _initialize() -> void:
 call_deferred("run")
func shot(name: String, seconds: float, camera_position: Vector3, target: Vector3, size: float) -> void:
 scene.camera.position=camera_position
 scene.camera.look_at(target,Vector3.UP)
 scene.camera.size=size
 scene.player.seek(seconds,true)
 scene.player.advance(0)
 for node in scene.model.find_children("*","Skeleton3D",true,false):node.force_update_all_bone_transforms()
 for i in range(3):await process_frame
 await RenderingServer.frame_post_draw
 var image=root.get_texture().get_image()
 assert(image.get_width()==1600 and image.get_height()==1000)
 assert(image.save_png(output.path_join(name+".png"))==OK)
 shots.append(name+".png")
 print("CAPTURE ",name)
func run() -> void:
 output=ProjectSettings.globalize_path("res://../godot-renders")
 DirAccess.make_dir_recursive_absolute(output)
 scene=load("res://main.tscn").instantiate()
 root.add_child(scene)
 for i in range(3):await process_frame
 for layer in scene.find_children("*","CanvasLayer",true,false):layer.visible=false
 scene.player.callback_mode_process=AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL
 scene.player.play("RaceGallop",0)
 var frames=range(28) if "--full" in OS.get_cmdline_user_args() else [0,7,14,21]
 for frame in frames:
  await shot("race-side-%03d"%frame,float(frame)/60,Vector3(0,.70,3),Vector3(0,.42,0),1.8)
 for frame in frames:
  await shot("neck-shoulder-%03d"%frame,float(frame)/60,Vector3(-.27,.67,3),Vector3(-.26,.57,0),.65)
 for frame in [0,14]:
  await shot("race-front-%03d"%frame,float(frame)/60,Vector3(-3,.70,0),Vector3(0,.42,0),1.5)
  await shot("race-back-%03d"%frame,float(frame)/60,Vector3(3,.70,0),Vector3(0,.42,0),1.5)
 if "--full" in OS.get_cmdline_user_args():
  for clip in ["Stand","Walk","Trot","Canter"]:
   scene.player.play(clip,0)
   var animation=scene.player.get_animation(clip)
   for phase in [0,.25,.5,.75]:
    await shot(clip.to_lower()+"-side-%03d"%int(phase*100),phase*animation.length,Vector3(0,.70,3),Vector3(0,.42,0),1.8)
 scene.coat_material.set_shader_parameter("show_regions",true)
 scene.player.play("RaceGallop",0)
 await shot("region-debug",.2,Vector3(0,.70,3),Vector3(0,.42,0),1.8)
 scene.coat_material.set_shader_parameter("show_regions",false)
 var old_material=scene.coat_material
 var audit=ShaderMaterial.new()
 audit.shader=load("res://normal_audit.gdshader")
 for node in scene.model.find_children("*","MeshInstance3D",true,false):
  if node.name=="Horse":node.material_override=audit
 scene.player.play("RaceGallop",0)
 for enabled in [false,true]:
  audit.set_shader_parameter("guard_enabled",enabled)
  for frame in frames:
   await shot(("normal-protected-" if enabled else "normal-raw-")+"%03d"%frame,float(frame)/60,Vector3(0,.70,3),Vector3(0,.42,0),1.8)
 var manifest={"source_glb_sha256":FileAccess.get_sha256("res://assets/horse.glb"),"engine":Engine.get_version_info().string,"adapter":RenderingServer.get_video_adapter_name(),"size":[1600,1000],"inspection_lod_bias":16.0,"shots":shots}
 var file=FileAccess.open("res://../godot-capture-manifest.json",FileAccess.WRITE)
 file.store_string(JSON.stringify(manifest,"  "))
 scene.queue_free()
 await process_frame
 print("GODOT_CAPTURE_COMPLETE")
 quit()
