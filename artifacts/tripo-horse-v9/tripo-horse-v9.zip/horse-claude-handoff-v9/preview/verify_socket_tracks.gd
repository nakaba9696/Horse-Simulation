extends SceneTree
func _initialize():call_deferred("run")
func run():
 var scene=load("res://main.tscn").instantiate();root.add_child(scene)
 await process_frame
 scene.player.callback_mode_process=AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL
 var tracks=JSON.parse_string(FileAccess.get_file_as_string("res://../attachment-tracks.json"));var result={}
 var nodes={}
 for name in ["Saddle","Stirrup_L","Stirrup_R","Bit_L","Bit_R","Withers"]:nodes[name]=scene.model.find_child(name,true,false)
 for clip in tracks.clips:
  var godot_clip=clip.replace("_Loop","");scene.player.play(godot_clip,0);var errors={};var angular=0.0
  for sample in tracks.clips[clip].samples:
   scene.player.seek(float(sample.time_seconds),true);scene.player.advance(0)
   for skel in scene.model.find_children("*","Skeleton3D",true,false):skel.force_update_all_bone_transforms()
   await process_frame
   await process_frame
   for name in nodes:
    var transform=scene.model.global_transform.affine_inverse()*nodes[name].global_transform
    var p=sample.nodes[name].position_model;var error=transform.origin.distance_to(Vector3(p[0],p[1],p[2]))*2.6
    errors[name]=max(errors.get(name,0.0),error)
    var q=sample.nodes[name].quaternion_xyzw;angular=max(angular,transform.basis.get_rotation_quaternion().angle_to(Quaternion(q[0],q[1],q[2],q[3])))
  for name in errors:assert(errors[name]<(0.002 if name in ["Saddle","Stirrup_L","Stirrup_R"] else 0.007))
  assert(angular<0.01)
  result[godot_clip]={"position_error_m_by_socket":errors,"max_angle_error_radians":angular,"samples":tracks.clips[clip].samples.size()}
 var file=FileAccess.open("res://../attachment-godot-validation.json",FileAccess.WRITE);file.store_string(JSON.stringify(result,"  "));print("ALL_CLIP_SOCKET_PASS ",JSON.stringify(result));quit()
