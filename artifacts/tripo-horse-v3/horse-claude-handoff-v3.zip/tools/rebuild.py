from pathlib import Path
import subprocess,sys,shutil
root=Path(__file__).resolve().parent
blender=shutil.which('blender')
if not blender:raise SystemExit('Blender 4.3+ must be on PATH')
for name in ['build.py','regions.py','corrective.py','export.py']:
 subprocess.run([blender,'-b','-t','4','--python-exit-code','1','--python',str(root/name)],check=True)
subprocess.run([sys.executable,str(root/'finalize.py')],check=True)
shutil.copy2(root.parent/'horse-gallop.glb',root.parent/'preview/assets/horse.glb')
print('Updated race GLB and preview asset')

import struct,json
b=(root.parent/'horse-gallop.glb').read_bytes();size=struct.unpack_from('<I',b,12)[0];doc=json.loads(b[20:20+size])
assert len(doc['animations'])==1
assert doc['animations'][0]['name']=='RaceGallop_Loop'
assert len(doc['skins'][0]['joints'])==54
assert 'TEXCOORD_1' in doc['meshes'][0]['primitives'][0]['attributes']
assert doc['meshes'][0]['extras']['targetNames']==['RaceNeckCorrective']
assert any(c['target']['path']=='weights' for c in doc['animations'][0]['channels'])
print('Verified clip, skeleton, UV2, and neck corrective')
