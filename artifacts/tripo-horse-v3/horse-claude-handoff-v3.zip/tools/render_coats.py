import bpy,math,json
from pathlib import Path
from mathutils import Vector,Quaternion
p=Path(__file__).resolve().parent.parent
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.scene.render.fps=60
bpy.ops.import_scene.gltf(filepath=str(p/'horse-gallop.glb'))
a=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE')
if a.animation_data:
 for tr in a.animation_data.nla_tracks:tr.mute=True
 a.animation_data.action=bpy.data.actions[0]
for o in list(bpy.context.scene.objects):
 if o.type=='MESH' and len(o.data.vertices)<100:bpy.data.objects.remove(o,do_unlink=True)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=4;s.cycles.use_denoising=False
s.render.resolution_x=1600;s.render.resolution_y=1000;s.render.resolution_percentage=100
s.world=bpy.data.worlds.new('Studio');s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.18,.18,.18,1)
for pos in [(-1,-2,3),(1,2,2)]:
 d=bpy.data.lights.new('Light','AREA');d.energy=180;d.size=2;o=bpy.data.objects.new('Light',d);s.collection.objects.link(o);o.location=pos;o.rotation_euler=(Vector((0,0,.4))-o.location).to_track_quat('-Z','Y').to_euler()
d=bpy.data.cameras.new('Camera');o=bpy.data.objects.new('Camera',d);s.collection.objects.link(o);s.camera=o;o.location=(0,-3,1);o.rotation_euler=(Vector((0,0,.42))-o.location).to_track_quat('-Z','Y').to_euler();d.type='ORTHO';d.ortho_scale=1.8


mesh=next(o for o in s.objects if o.type=='MESH')
original=mesh.data.materials[0]
colors=[(.36,.13,.045,1),(.018,.012,.008,1),(.018,.012,.008,1),(.065,.06,.055,1),(.055,.035,.03,1),(.005,.004,.003,1),(.36,.13,.045,1),(.20,.12,.10,1)]
debug=[(.7,.7,.7,1),(.9,.1,.05,1),(.6,.05,.8,1),(.05,.2,.9,1),(.05,.8,.8,1),(.01,.01,.01,1),(1,1,.05,1),(.1,.9,.1,1)]
materials=[]
for i in range(8):
 mat=original.copy();mat.name='Coat_'+str(i);materials.append(mat)
# Blend mane pigment at the boundary using the UV2 mask weight.
mat=materials[1];nodes=mat.node_tree.nodes;links=mat.node_tree.links
uvnode=nodes.new('ShaderNodeUVMap');uvnode.uv_map=mesh.data.uv_layers[1].name
sep=nodes.new('ShaderNodeSeparateXYZ');links.new(uvnode.outputs['UV'],sep.inputs[0])
mult=nodes.new('ShaderNodeMath');mult.operation='MULTIPLY';mult.inputs[1].default_value=8;links.new(sep.outputs[0],mult.inputs[0])
sub=nodes.new('ShaderNodeMath');sub.operation='SUBTRACT';sub.inputs[1].default_value=1.1;links.new(mult.outputs[0],sub.inputs[0])
div=nodes.new('ShaderNodeMath');div.operation='DIVIDE';div.inputs[1].default_value=.8;div.use_clamp=True;links.new(sub.outputs[0],div.inputs[0])
mix=nodes.new('ShaderNodeMixRGB');mix.inputs[1].default_value=colors[0];mix.inputs[2].default_value=colors[1];links.new(div.outputs[0],mix.inputs[0])
principled=next(n for n in nodes if n.type=='BSDF_PRINCIPLED');links.new(mix.outputs[0],principled.inputs['Base Color'])
mesh.data.materials.clear()
for mat in materials:mesh.data.materials.append(mat)
for poly in mesh.data.polygons:
 poly.material_index=min(7,int(mesh.data.uv_layers[1].data[poly.loop_indices[0]].uv.x*8))
s.frame_set(13)
for name,palette in [('bay',colors),('region-debug',debug),('chestnut',[colors[0],(.16,.055,.018,1),(.16,.055,.018,1),*colors[3:]])]:
 mix.inputs[1].default_value=palette[0];mix.inputs[2].default_value=palette[1]
 for mat,c in zip(materials,palette):
  for node in mat.node_tree.nodes:
   if node.type=='BSDF_PRINCIPLED':node.inputs['Base Color'].default_value=c;node.inputs['Roughness'].default_value=.8
 s.render.filepath=str(p/(name+'.png'));bpy.ops.render.render(write_still=True)
