import struct,json
from pathlib import Path
p=(Path(__file__).resolve().parent.parent/'horse-gallop.glb');b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);payload=bytearray(b[28+n:]);seen=set()
for anim in d['animations']:
 anim['name']='RaceGallop_Loop'
 for sampler in anim['samplers']:
  i=sampler['input']
  if i in seen:continue
  seen.add(i);a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];offset=v.get('byteOffset',0)+a.get('byteOffset',0);values=list(struct.unpack_from('<'+'f'*a['count'],payload,offset));shift=values[0];values=[x-shift for x in values];struct.pack_into('<'+'f'*len(values),payload,offset,*values);a['min']=[min(values)];a['max']=[max(values)]
js=json.dumps(d,separators=(',',':')).encode();js+=b' '*((-len(js))%4);payload+=b'\0'*((-len(payload))%4)
p.write_bytes(struct.pack('<III',0x46546c67,2,12+8+len(js)+8+len(payload))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(payload),0x004e4942)+payload)
print('CLIP',d['animations'][0]['name'],'DURATION',max(d['accessors'][i]['max'][0] for i in seen))
