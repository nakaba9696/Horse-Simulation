from pathlib import Path
import bpy
p=str(Path(__file__).resolve().parent.parent)+'/'
bpy.ops.wm.open_mainfile(filepath=p+'horse-gallop.blend')
a=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE')
for f in a.animation_data.action.fcurves:
 for k in f.keyframe_points:k.interpolation='LINEAR'
bpy.context.scene.frame_end=109;bpy.context.scene.frame_set(1)
bpy.ops.export_scene.gltf(filepath=p+'horse-gallop.glb',export_format='GLB',use_selection=True,export_animations=True,export_frame_range=True,export_force_sampling=True,export_animation_mode='ACTIVE_ACTIONS',export_anim_single_armature=True,export_extras=True)
bpy.ops.wm.save_as_mainfile(filepath=p+'horse-gallop.blend')
