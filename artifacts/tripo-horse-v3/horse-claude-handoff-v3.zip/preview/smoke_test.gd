extends SceneTree
func _initialize():
 call_deferred("run_check")
func run_check():
 var preview = load("res://main.tscn").instantiate()
 root.add_child(preview)
 await process_frame
 var player: AnimationPlayer = preview.player
 var skeleton: Skeleton3D = preview.find_children("*", "Skeleton3D", true, false)[0]
 var bone := -1
 for index in range(skeleton.get_bone_count()):
  if skeleton.get_bone_name(index).ends_with("0_Left_Limb_2"):
   bone = index
   break
 assert(bone >= 0)
 player.seek(0, true)
 player.advance(0)
 var first = skeleton.get_bone_global_pose(bone)
 var first_all = []
 for index in range(skeleton.get_bone_count()): first_all.append(skeleton.get_bone_global_pose(index).origin)
 var max_displacement = 0.0
 var max_loop_difference = 0.0
 for sample in range(1, 1921):
  player.advance(0.45 / 96.0)
  for index in range(skeleton.get_bone_count()):
   assert(skeleton.get_bone_global_pose(index).origin.is_finite())
  var pose = skeleton.get_bone_global_pose(bone)
  max_displacement = max(max_displacement, pose.origin.distance_to(first.origin))
  if sample % 96 == 0:
   for index in range(skeleton.get_bone_count()):
    max_loop_difference = max(max_loop_difference, skeleton.get_bone_global_pose(index).origin.distance_to(first_all[index]))
 assert(max_displacement > 0.2, "Leg did not move")
 assert(max_loop_difference < 0.0001, "Loop drift")
 preview.toggle_pause()
 assert(preview.is_paused and not player.is_playing())
 preview.toggle_pause()
 assert(player.is_playing())
 for position in [Vector3(-2.4,0.6,0),Vector3(2.4,0.6,0),Vector3(0,0.65,2.4)]:
  preview.set_view(position)
  assert(preview.camera.transform.origin.is_finite())
 var slider = preview.find_children("*", "HSlider", true, false)[0]
 slider.value = 0.5
 assert(is_equal_approx(player.speed_scale, 0.5))
 slider.value = 1.0
 preview.apply_coat(Color(0.42,0.15,0.05), Color(0.16,0.055,0.018))
 assert(preview.coat_material.get_shader_parameter("coat_color").is_equal_approx(Color(0.42,0.15,0.05)))
 var report = {"cycles":20,"samples":1920,"bones":skeleton.get_bone_count(),"clip":str(preview.animation_name),"leg_displacement":max_displacement,"loop_drift":max_loop_difference,"pause_resume":true,"view_switching":true,"speed_control":true,"coat_control":true}
 var file = FileAccess.open("res://../godot-endurance.json", FileAccess.WRITE)
 file.store_string(JSON.stringify(report,"\t"))
 print(JSON.stringify(report))
 quit()
