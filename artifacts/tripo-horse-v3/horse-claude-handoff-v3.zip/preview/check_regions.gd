extends SceneTree
func _initialize():
 var horse = load("res://assets/horse.glb").instantiate()
 root.add_child(horse)
 var mesh_instance = horse.find_children("*", "MeshInstance3D", true, false)[0]
 assert(mesh_instance.mesh.get_blend_shape_count() == 1)
 var player: AnimationPlayer = horse.find_children("*", "AnimationPlayer", true, false)[0]
 for clip in player.get_animation_list():
  if clip != "RESET":
   player.play(clip)
   player.seek(0.1,true)
   player.advance(0)
   break
 assert(is_equal_approx(mesh_instance.get_blend_shape_value(0),1.0))
 var arrays = mesh_instance.mesh.surface_get_arrays(0)
 var coordinates: PackedVector2Array = arrays[Mesh.ARRAY_TEX_UV2]
 assert(coordinates.size() == arrays[Mesh.ARRAY_VERTEX].size())
 var regions = {}
 var legs = {}
 for uv in coordinates:
  var region = int(floor(uv.x * 8.0))
  var leg = int(floor(uv.y * 8.0))
  assert(region >= 0 and region <= 7)
  assert(leg >= 0 and leg <= 4)
  regions[region] = regions.get(region,0) + 1
  legs[leg] = legs.get(leg,0) + 1
 assert(regions.size()==8)
 assert(legs.size()==5)
 var result = {"vertex_count":coordinates.size(),"regions":regions,"legs":legs,"uv2_preserved":true,"neck_corrective_default":mesh_instance.get_blend_shape_value(0)}
 var f=FileAccess.open("res://../godot-regions.json",FileAccess.WRITE)
 f.store_string(JSON.stringify(result,"\t"))
 print(JSON.stringify(result))
 quit()
