# 馬モデル試作 v3

約7mの完歩、0.45秒周期、首を前へ伸ばす姿勢、毛色用領域データを追加した版です。

ClaudeへはCLAUDE_HANDOFF.mdを渡してください。モデルは独立した試作シーンに取り込み、今の馬と実画面で比較してから採否を決めてください。

見る: Godot 4.6でpreview/project.godotを開きF5。鹿毛・栗毛・芦毛・領域表示を切り替えられます。
編集: Blender 4.3.2でhorse-gallop.blend。
再生成: BlenderをPATHへ登録し、python tools/rebuild.py。

GLB単体はグレーです。毛色の表示には同梱のcoat.gdshaderを使います。UV2の上書きと、首補正の扱いに注意してください。

実写に合わせた完成歩様ではなく、肩・首の変形や毛の境界には調整の余地があります。詳細な確認結果と制限はCLAUDE_HANDOFF.mdに記載しています。
