# 画像レビューの履歴

1. `01-iteration-review.md`: 首頭の比率は改善、たてがみの大きい葉と二分した鼻を差し戻し。
2. `02-iteration-review.md`: 鼻の中央溝が悪化して差し戻し。
3. `03-iteration-review.md`: 鼻先の追加形が貼り付けに見え、差し戻し。
4. 04-probe: 鼻の切除範囲が喉まで届く欠けを制作側が実画像で検出。04bで範囲を狭めて修正。閉じたメッシュという数値だけでは合格にしていない。
5. `04-final-independent-rejected.md`: 別の最終担当がたてがみの平たい鱗状の房を拒否。途中担当の許容判断を最終合格に流用せず、52本の丸断面の束に再制作。
6. `05-iteration-review.md` / `FINAL_INDEPENDENT_REVIEW.md`: 再描画後、途中担当と別の最終担当がそれぞれ実画像を確認。最終判定と残件はこの2文書を参照。

修正前後はルートの `mane-before-after.jpg`, `face-before-after.jpg`, `throat-before-after.jpg`。比較画像のカメラ/尺度/照明/位相はmanifestに固定。中間の原寸は抜粋、最終05の570枚は全収録。フレーム列の閲覧と実時間動画の人間による再生は区別し、後者は実施済みにしていない。
