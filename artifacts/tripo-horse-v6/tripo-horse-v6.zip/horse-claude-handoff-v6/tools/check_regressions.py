"""Compare v5 preserved contracts against the current final GLB-derived reports."""
import json,math,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent.parent;B=P/'baseline/v5'
load=lambda p:json.loads(p.read_text());old=load(B/'motion-validation.json');new=load(P/'motion-validation.json');clips={}
for clip in old:
 a=old[clip]['summary'];b=new[clip]['summary'];assert abs(a['duration']-b['duration'])<1e-8
 assert b['minimum_hoof_m']>=-.0031 and b['loop_max_vertex_difference']<1e-5
 assert abs(a['airborne_fraction']-b['airborne_fraction'])<.005
 assert abs(a['withers_peak_to_peak_m']-b['withers_peak_to_peak_m'])<.0001
 worst=0
 for ra,rb in zip(old[clip]['frames'],new[clip]['frames']):
  for key in ra['feet']:
   worst=max(worst,math.dist(ra['feet'][key]['centroid'],rb['feet'][key]['centroid']))
 assert worst*2.6<.0001,(clip,worst)
 clips[clip]={'max_hoof_centroid_difference_m':worst*2.6,'duration':b['duration'],'min_hoof_m':b['minimum_hoof_m'],'airborne_fraction':b['airborne_fraction'],'withers_peak_to_peak_m':b['withers_peak_to_peak_m'],'loop_difference_model':b['loop_max_vertex_difference']}
a=load(B/'saddle-track.json');b=load(P/'saddle-track.json');sockets={}
for name in ['Saddle','Stirrup_L','Stirrup_R','Withers']:
 worst=max(math.dist(x['nodes'][name]['position_model'],y['nodes'][name]['position_model']) for x,y in zip(a['samples'],b['samples']));assert worst*2.6<.0001
 sockets[name]={'max_v5_position_difference_m':worst*2.6}
neck=load(P/'neck-line.json');s=neck['summary'];poll=[x['points_model']['poll'][1]*2.6 for x in neck['samples'][:-1]];poll_range=max(poll)-min(poll)
assert 20<=s['neck_angle_degrees_min']<=s['neck_angle_degrees_max']<=35
assert 90<=s['head_neck_angle_degrees_min']<=s['head_neck_angle_degrees_max']<=110
assert s['minimum_crest_above_chord_m']>=-.002 and s['max_lateral_mid_m']<.005 and s['nose_forward_every_sample']
assert .25<=poll_range<=.35
surface=load(P/'surface-validation.json')
for mesh in surface['meshes'].values():assert mesh['boundary_edges']==mesh['nonmanifold_edges']==mesh['inconsistent_winding_edges']==0
assert surface['max_degenerate_faces']==0 and not surface['globally_reversed_body_component']
assert load(P/'geometry-report.json')['total_triangles']<=19190
result={'source_glb_sha256':hashlib.sha256((P/'horse-gallop.glb').read_bytes()).hexdigest(),'clips':clips,'preserved_sockets':sockets,'bits':'Rest placement follows resized skull; compare to regenerated JSON and bridle ring, not v5 position.','poll_height_range_m':poll_range,'numerical_contracts':'PASS','visual_approval':'Separate review records required; this script does not approve appearance.'}
(P/'regression-validation.json').write_text(json.dumps(result,indent=2));print('REGRESSION_PASS',poll_range)
