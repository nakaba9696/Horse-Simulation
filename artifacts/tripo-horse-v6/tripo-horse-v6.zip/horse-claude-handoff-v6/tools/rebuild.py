"""Rebuild bundled v6 assets; never reads or edits the game project."""
import argparse, subprocess, json, struct, hashlib, os, sys, shutil
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--blender',default='blender')
parser.add_argument('--godot',default=None,help='Also import and verify standalone preview')
parser.add_argument('--compare',default=None,help='Capture v4/v5/v6 at common cameras into comparison/LABEL; requires display')
parser.add_argument('--render',action='store_true',help='Capture real Godot renderer; requires display')
args=parser.parse_args();root=Path(__file__).resolve().parent.parent
env=os.environ.copy();env['HORSE_REPAIR_PYTHON']=sys.executable
for stage in ['rest','repair_surface','proportions','animate','geometry','regions','corrective','normals','export','measure','sockets','verify_neck_surface','roundtrip','measure_dimensions']:
 print('STAGE',stage,flush=True)
 subprocess.run([args.blender,'-b','-t','4','--python-exit-code','1','--python',str(root/'tools'/f'{stage}.py')],check=True,env=env)
for check in ['inspect_gltf','check_contact','check_regressions','compare_proportions']:
 subprocess.run([sys.executable,str(root/'tools'/f'{check}.py')],check=True,env=env)
raw=(root/'horse-gallop.glb').read_bytes();size=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+size])
assert len(doc['skins'][0]['joints'])==54
assert {x['name'] for x in doc['animations']}=={'RaceGallop_Loop','Stand_Loop','Walk_Loop','Trot_Loop','Canter_Loop'}
assert {'Saddle','Stirrup_L','Stirrup_R','Bit_L','Bit_R','Withers'}<={n.get('name','') for n in doc['nodes']}
for mesh in doc['meshes']:
 for primitive in mesh['primitives']:
  if primitive.get('targets'):
   assert 'TEXCOORD_1' in primitive['attributes'] and len(primitive['targets'])==1
geometry=json.loads((root/'geometry-report.json').read_text());assert geometry['total_triangles']<=19190
motion=json.loads((root/'motion-validation.json').read_text())['RaceGallop_Loop']['summary']
assert .15<=motion['airborne_fraction']<=.25 and .14<=motion['withers_peak_to_peak_m']<=.16
assert motion['minimum_hoof_m']>=-.0031
for leg in motion['legs'].values():assert abs(leg['fitted_stride_m']-7)<.025
assert motion['loop_max_vertex_difference']<1e-5
neck=json.loads((root/'neck-line.json').read_text())['summary']
assert 20<=neck['neck_angle_degrees_min']<=neck['neck_angle_degrees_max']<=35
assert 90<=neck['head_neck_angle_degrees_min']<=neck['head_neck_angle_degrees_max']<=110
assert neck['minimum_crest_above_chord_m']>=-.002 and neck['max_lateral_mid_m']<.005
assert neck['nose_forward_every_sample']
surface=json.loads((root/'surface-validation.json').read_text())
for mesh in surface['meshes'].values():
 assert mesh['boundary_edges']==mesh['nonmanifold_edges']==mesh['inconsistent_winding_edges']==0
assert not surface['globally_reversed_body_component'] and surface['max_degenerate_faces']==0
(root/'preview/assets').mkdir(parents=True,exist_ok=True)
shutil.copy2(root/'horse-gallop.glb',root/'preview/assets/horse.glb')
if (args.render or args.compare) and not args.godot:parser.error('--render/--compare also require --godot')
if args.godot:
 for name in ['DATA','CACHE','CONFIG']:
  env.setdefault('XDG_'+name+'_HOME',str(root/'.runtime'/name.lower()))
 subprocess.run([args.godot,'--headless','--path',str(root/'preview'),'--editor','--import'],check=True,env=env,timeout=180)
 subprocess.run([sys.executable,str(root/'tools/configure_godot_import.py'),str(root/'preview/assets/horse.glb.import'),'--godot',args.godot],check=True,env=env)
 for file in (root/'preview/.godot/imported').glob('horse.glb-*'):file.unlink()
 subprocess.run([args.godot,'--headless','--path',str(root/'preview'),'--editor','--import'],check=True,env=env,timeout=180)
 subprocess.run([args.godot,'--headless','--path',str(root/'preview'),'--script','verify.gd'],check=True,env=env,timeout=90)
 subprocess.run([args.godot,'--headless','--path',str(root/'preview'),'--script','verify_socket_tracks.gd'],check=True,env=env,timeout=90)
 if args.compare:
  subprocess.run([args.godot,'--path',str(root/'preview'),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1600x1000','--script','compare_capture.gd','--',args.compare],check=True,env=env,timeout=900)
  subprocess.run([sys.executable,str(root/'tools/compare_media.py'),args.compare],check=True,env=env)
 if args.render:
  subprocess.run([args.godot,'--path',str(root/'preview'),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1600x1000','--script','capture.gd','--','--full'],check=True,env=env,timeout=600)
  subprocess.run([sys.executable,str(root/'tools/make_media.py')],check=True,env=env)
print('REBUILD_PASS',hashlib.sha256(raw).hexdigest())
