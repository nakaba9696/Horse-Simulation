"""Deterministic local proportion map; Blender-space +Z up, -X forward."""
from mathutils import Vector
import math

def smooth(a,b,x):
 u=max(0,min(1,(x-a)/(b-a)));return u*u*(3-2*u)

def interpolate(rows,x,column):
 if x<=rows[0][0]:return rows[0][column]
 for one,two in zip(rows,rows[1:]):
  if one[0]<=x<=two[0]:
   u=(x-one[0])/(two[0]-one[0]);return one[column]*(1-u)+two[column]*u
 return rows[-1][column]

def round_face(point,design):
 p=Vector(point)
 if 'face_sections' not in design or p.x>-.30 or p.z<.52:return p
 q=Vector(design['v5_poll']);d=Vector(design['v5_nose'])-q;length=d.length;axis=d.normalized();perp=Vector((-axis.z,0,axis.x));delta=p-q;u=delta.dot(axis)/length;v=delta.dot(perp)
 rows=design['face_sections'];center=interpolate(rows,u,1);ry=interpolate(rows,u,2);rv=interpolate(rows,u,3);theta=math.atan2(p.y/ry,(v-center)/rv);r=math.sqrt((p.y/ry)**2+((v-center)/rv)**2)
 alpha=.96*smooth(.25,.65,u)
 if r>1e-5:
  y=p.y*(1-alpha)+p.y/r*alpha;v=v*(1-alpha)+(center+(v-center)/r)*alpha
 else:y=p.y
 return q+axis*(u*length)+Vector((0,y,0))+perp*v

def warp(point,design):
 p=round_face(point,design);w=Vector(design['withers']);q=Vector(design['v5_poll']);d=Vector(design['v5_nose'])-q;d.y=0;axis=d.normalized();perp=Vector((-axis.z,0,axis.x));new_q=Vector((w.x+1.25*(q.x-w.x),0,q.z))
 delta=p-q;head=new_q+axis*delta.dot(axis)*.85+perp*delta.dot(perp)*.82+Vector((0,p.y*.78,0))
 u=max(0,min(1,(w.x-p.x)/(w.x-q.x)));top=w.z+(q.z-w.z)*u
 slender=.22*smooth(.02,.65,u)
 neck=Vector((w.x+1.25*(p.x-w.x),p.y*(1-slender),top+(p.z-top)*(1-slender)))
 blend=(1-smooth(-.34,-.29,p.x))*smooth(.48,.63,p.z)
 if p.x<-.38 and p.z>.48:blend=1
 shaped=neck.lerp(head,blend)
 amount=smooth(.46,.57,p.z)*(1-smooth(w.x-.015,w.x+.035,p.x))
 return p.lerp(shaped,amount)
