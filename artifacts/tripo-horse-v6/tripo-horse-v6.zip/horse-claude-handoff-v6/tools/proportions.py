import bpy,json,sys,numpy as np,math
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
P=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(P/'tools'));from shape_v6 import warp
bpy.ops.wm.open_mainfile(filepath=str(P/'rest.blend'))
a=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');o=bpy.data.objects['Horse'];bvh=BVHTree.FromPolygons([v.co for v in o.data.vertices],[tuple(f.vertices) for f in o.data.polygons]);q=bvh.find_nearest(Vector((-.315,0,.800)))[0];q.y=0;n=bvh.find_nearest(Vector((-.462,0,.607)))[0];n.y=0;w=a.data.bones['tripo::Spine_7'].head_local.copy();w.y=0;w.z+=.025
design={'withers':list(w),'v5_poll':list(q),'v5_nose':list(n),'neck_horizontal_factor':1.25,'head_longitudinal_factor':.85,'head_depth_factor':.82,'head_width_factor':.78,'neck_thickness_reduction_max':.22}
# Fit a smooth oval rostrum, removing the source's peanut-shaped nose cleft.
axis=(n-q).normalized();perp=Vector((-axis.z,0,axis.x));length=(n-q).length
samples=np.array([[(v.co-q).dot(axis)/length,v.co.y,(v.co-q).dot(perp)] for v in o.data.vertices if v.co.x<-.31 and v.co.z>.52])
sections=[]
for u in np.linspace(.10,1.15,22):
 points=samples[abs(samples[:,0]-u)<.055]
 if len(points)<4:continue
 low,high=np.percentile(points[:,2],[2,98]);ry=min(float(np.max(abs(points[:,1]))),.057-.012*max(0,min(1,(u-.35)/.65)))
 sections.append([float(u),float((low+high)*.5),max(.012,ry),max(.012,float(high-low)*.5)])
design['face_sections']=sections
attr=o.data.attributes.new('v5_rest_position','FLOAT_VECTOR','POINT')
for v in o.data.vertices:
 attr.data[v.index].vector=v.co;v.co=warp(v.co,design)
design['poll_rest']=list(warp(q,design));design['nose_rest']=list(warp(n,design))
# Fuse a small closed oval muzzle into the source, filling the deep medial cleft.
# Boolean is confined to the skull. Torso/limb vertex coordinates remain unchanged.
import bmesh
from mathutils.kdtree import KDTree
from mathutils.geometry import barycentric_transform
old_mesh=o.data.copy();coords=[v.co.copy() for v in old_mesh.vertices];kd=KDTree(len(coords))
for i,co in enumerate(coords):kd.insert(co,i)
kd.balance();old_bvh=BVHTree.FromPolygons(coords,[tuple(f.vertices) for f in old_mesh.polygons]);old_uv={}
for loop in old_mesh.loops:old_uv.setdefault(loop.vertex_index,old_mesh.uv_layers[0].data[loop.index].uv.copy())
new_q=Vector(design['poll_rest']);new_axis=(n-q).normalized();new_perp=Vector((-new_axis.z,0,new_axis.x));new_length=(n-q).length*.85
center=new_q+new_axis*(new_length*.86)+new_perp*.011;long_radius=new_length*.22;side_radius=.0405;depth_radius=.040
# Remove the old forked rostrum beyond a local transverse plane before union.
# A bounded cutter avoids touching the torso or legs that share axial projections.
cutverts=[]
for u in [.78,2.0]:
 for y,v in [(-.09,-.065),(.09,-.065),(.09,.065),(-.09,.065)]:cutverts.append(new_q+new_axis*(new_length*u)+Vector((0,y,0))+new_perp*v)
cutfaces=[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]
cutmesh=bpy.data.meshes.new('LocalRostrumCutter');cutmesh.from_pydata(cutverts,[],cutfaces);cutmesh.update();cutter=bpy.data.objects.new('LocalRostrumCutter',cutmesh);bpy.context.scene.collection.objects.link(cutter)
bm=bmesh.new();bm.from_mesh(cutmesh);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(cutmesh);bm.free()
for mod in list(o.modifiers):o.modifiers.remove(mod)
bpy.context.view_layer.objects.active=o;cut=o.modifiers.new('RemoveForkedNose','BOOLEAN');cut.operation='DIFFERENCE';cut.solver='EXACT';cut.object=cutter;bpy.ops.object.modifier_apply(modifier=cut.name);bpy.data.objects.remove(cutter,do_unlink=True)
for mod in list(o.modifiers):o.modifiers.remove(mod)
bpy.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=8,radius=1)
ellipsoid=bpy.context.object
for vertex in ellipsoid.data.vertices:
 x,y,z=vertex.co;vertex.co=center+new_axis*(z*long_radius)+Vector((0,x*side_radius,0))+new_perp*(y*depth_radius)
ellipsoid.data.materials.append(o.data.materials[0]);bpy.context.view_layer.objects.active=o
boolean=o.modifiers.new('ClosedMuzzleUnion','BOOLEAN');boolean.operation='UNION';boolean.solver='EXACT';boolean.object=ellipsoid
bpy.ops.object.modifier_apply(modifier=boolean.name);bpy.data.objects.remove(ellipsoid,do_unlink=True)
bm=bmesh.new();bm.from_mesh(o.data)
head_vertices=[v for v in bm.verts if v.co.x<-.30 and v.co.z>.50]
bmesh.ops.remove_doubles(bm,verts=head_vertices,dist=.000001)
bmesh.ops.dissolve_degenerate(bm,edges=[e for e in bm.edges if all(v.co.x<-.30 and v.co.z>.50 for v in e.verts)],dist=.00001)
bmesh.ops.triangulate(bm,faces=list(bm.faces))
# Blend the transition without shrinking the new nose cap or changing neck/limbs.
def smooth_weight(vertex):
 u=(vertex.co-new_q).dot(new_axis)/new_length
 return max(0,min(1,(u-.48)/.26)) if vertex.co.x<-.30 and vertex.co.z>.50 and abs((vertex.co-new_q).dot(new_perp))<.075 else 0
for iteration in range(16):
 for strength in [.5,-.53]:
  updates={}
  for vertex in bm.verts:
   weight=smooth_weight(vertex)
   if weight>0 and vertex.link_edges:
    mean=sum((edge.other_vert(vertex).co for edge in vertex.link_edges),Vector())/len(vertex.link_edges);updates[vertex]=vertex.co+strength*weight*(mean-vertex.co)
  for vertex,value in updates.items():vertex.co=value
bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(o.data);bm.free()
canonical=o.data.attributes.get('v5_rest_position');head=o.vertex_groups['tripo::Head_5']
new_count=0
for vertex in o.data.vertices:
 nearest,index,distance=kd.find(vertex.co)
 if distance<1e-7:canonical.data[vertex.index].vector=old_mesh.attributes['v5_rest_position'].data[index].vector
 else:
  delta=vertex.co-new_q;canonical.data[vertex.index].vector=q+new_axis*(delta.dot(new_axis)/.85)+new_perp*(delta.dot(new_perp)/.82)+Vector((0,vertex.co.y/.78,0));new_count+=1
  for group in list(vertex.groups):o.vertex_groups[group.group].remove([vertex.index])
  head.add([vertex.index],1.,'REPLACE')
# Newly created muzzle faces use a nearest-source UV sample; embedded normal strength stays .03.
uv=o.data.uv_layers[0]
for loop in o.data.loops:
 vertex=o.data.vertices[loop.vertex_index];nearest,index,distance=kd.find(vertex.co)
 if distance>1e-7:uv.data[loop.index].uv=old_uv[index]
mod=o.modifiers.new('Armature','ARMATURE');mod.object=a
# The distal point now lies on the fused cap, not inside the old divided nostrils.
design['nose_rest']=list(center+new_axis*long_radius)
(P/'proportion-design.json').write_text(json.dumps(design,indent=2))
(P/'muzzle-fusion.json').write_text(json.dumps({'method':'Local bounded cut removes forked source nose; exact union with closed oval rostrum; 16 Taubin pairs blend the transition; closed winding recalculated','new_surface_vertices':new_count,'center_model_blender':list(center),'radii_model':[long_radius,side_radius,depth_radius],'body_triangles_after_union':len(o.data.polygons),'taubin_pairs':16,'local_cut_start_fraction':.78},indent=2))
# No leg, torso, saddle bone, hoof or animation transforms are changed here.
bpy.ops.wm.save_as_mainfile(filepath=str(P/'rest.blend'));print('V6_PROPORTIONS_READY',design)
