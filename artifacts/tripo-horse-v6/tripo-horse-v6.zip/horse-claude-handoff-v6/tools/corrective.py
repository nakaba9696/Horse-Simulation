import bpy,numpy as np,json,math
from pathlib import Path
from mathutils import Matrix,Vector
from mathutils.bvhtree import BVHTree
P=Path(__file__).resolve().parent.parent;bpy.ops.wm.open_mainfile(filepath=str(P/'regions.blend'))
o=bpy.data.objects['Horse'];a=next(x for x in bpy.context.scene.objects if x.type=='ARMATURE');s=bpy.context.scene
for tr in a.animation_data.nla_tracks:tr.mute=True
a.animation_data.action=bpy.data.actions['RaceGallop_Loop'];s.frame_set(55);bpy.context.view_layer.update()
if o.data.shape_keys:
 for key in list(o.data.shape_keys.key_blocks)[::-1]:o.shape_key_remove(key)
N=int(o['base_vertex_count']);rest=np.array([v.co[:] for v in o.data.vertices]);ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());mesh=ev.to_mesh();posed=np.array([v.co[:] for v in mesh.vertices]);ev.to_mesh_clear();goal=posed.copy()
def smooth(lo,hi,x):
 t=max(0,min(1,(x-lo)/(hi-lo)));return t*t*(3-2*t)
adj=[set() for _ in rest]
for edge in o.data.edges:
 i,j=edge.vertices
 if i<N and j<N:adj[i].add(j);adj[j].add(i)
mask=[]
for i,(x,y,z) in enumerate(rest):
 limb=sum(g.weight for g in o.data.vertices[i].groups if 'Limb' in o.vertex_groups[g.group].name)
 mask.append(smooth(-.39,-.32,x)*(1-smooth(.02,.10,x))*smooth(.32,.50,z)*(1-smooth(.80,.84,z))*(1-smooth(.25,.65,limb)) if i<N else 0)
for iteration in range(0):
 for strength in [.5,-.45]:
  out=goal.copy()
  for i in np.flatnonzero(np.array(mask)>.001):
   if adj[i]:out[i]+=strength*mask[i]*(goal[list(adj[i])].mean(axis=0)-goal[i])
  goal=out
# Set the upper contour to a gently convex line between the anatomical landmarks.
design=json.loads((P/'neck-design.json').read_text());B=a.pose.bones['tripo::Spine_7'].matrix@a.data.bones['tripo::Spine_7'].matrix_local.inverted();W=B@Vector(design['withers_design_rest']);W.y=0
H=a.pose.bones['tripo::Head_5'].matrix@a.data.bones['tripo::Head_5'].matrix_local.inverted();Q=H@Vector(design['poll_rest']);Q.y=0
polys=[tuple(p.vertices) for p in o.data.polygons if all(i<N for i in p.vertices)];bvh=BVHTree.FromPolygons([Vector(v) for v in goal[:N]],polys)
xs=np.linspace(Q.x,W.x+.14,80);tops=[]
for x in xs:
 hit=bvh.ray_cast(Vector((x,0,2)),Vector((0,0,-1)))[0]
 tops.append(float(hit.z) if hit else float(np.interp(x,[Q.x,W.x],[Q.z,W.z])))
for i in range(N):
 x,y,z=goal[i];rx,ry,rz=rest[i]
 if not(Q.x-.002<x<W.x+.14) or rz<.43:continue
 oldtop=float(np.interp(x,xs,tops));u=(W.x-x)/(W.x-Q.x)
 if u<0:
  t=max(0,min(1,(x-W.x)/.14));target=W.z+(tops[-1]-W.z)*t
 else:target=W.z+(Q.z-W.z)*u+.014*math.sin(math.pi*min(1,u))
 depth=.16*(1-max(0,min(1,u)))+.055*max(0,min(1,u))
 weight=smooth(oldtop-depth,oldtop-.008,z)
 goal[i,2]+=(target-oldtop)*weight
basis=o.shape_key_add(name='Basis');key=o.shape_key_add(name='RaceNeckCorrective');key.value=1
vg={g.index:g.name for g in o.vertex_groups};max_delta=0;count=0
for v in o.data.vertices[:N]:
 delta=goal[v.index]-posed[v.index]
 if np.linalg.norm(delta)<1e-8:continue
 M=Matrix(((0,0,0,0),)*4)
 for g in v.groups:
  name=vg[g.group]
  if name not in a.pose.bones:continue
  T=o.matrix_world.inverted()@a.matrix_world@a.pose.bones[name].matrix@a.data.bones[name].matrix_local.inverted()@a.matrix_world.inverted()@o.matrix_world
  for i in range(4):
   for j in range(4):M[i][j]+=g.weight*T[i][j]
 d=M.to_3x3().inverted_safe()@Vector(delta);key.data[v.index].co=v.co+d;max_delta=max(max_delta,d.length);count+=1
# Keep locks attached to the reconstructed surface.
for index,root in json.loads(o['hair_root_vertices']).items():
 index=int(index);root=int(root);key.data[index].co=o.data.vertices[index].co+(key.data[root].co-o.data.vertices[root].co)
# Redesign race mane locks on the corrected posed surface, then inverse-bind them.
# Rounded locks sit against the neck; each is still a closed six-sided volume.
posed_body_bvh=BVHTree.FromPolygons([Vector(v) for v in goal[:N]],polys)
def side_surface(x,z):
 hit=posed_body_bvh.ray_cast(Vector((x,-2,z)),Vector((0,1,0)))[0]
 return hit+Vector((0,-.0045,0)) if hit is not None else Vector((x,-.040,z))
def bind_hair(index,point):
 v=o.data.vertices[index];M=Matrix(((0,0,0,0),)*4)
 for g in v.groups:
  name=vg[g.group]
  if name not in a.pose.bones:continue
  T=a.pose.bones[name].matrix@a.data.bones[name].matrix_local.inverted()
  for i in range(4):
   for j in range(4):M[i][j]+=g.weight*T[i][j]
 key.data[index].co=M.inverted_safe()@point
layout=json.loads((P/'mane-lock-layout.json').read_text())
for tuft,lock in enumerate(layout):
 x=Q.x+.008+(W.x-Q.x-.020)*lock['u']
 root=posed_body_bvh.ray_cast(Vector((x,0,2)),Vector((0,0,-1)))[0]
 if root is None:continue
 root+=Vector((0,-.001,.0008));mid=side_surface(x+lock['lean']*.45,root.z-lock['drop']*.5);tip=side_surface(x+lock['lean'],root.z-lock['drop']);width=lock['width']
 axis=(tip-root).normalized();side=axis.cross(Vector((0,1,0)))
 if side.length<.01:side=Vector((1,0,0))
 side.normalize();normal=axis.cross(side).normalized();points=[]
 for center,w in [(root,width),(mid,width*.65),(tip.lerp(mid,.12),width*.12)]:
  for j in range(4):
   theta=j*2*math.pi/4;points.append(center+side*w*math.cos(theta)+normal*w*.85*math.sin(theta))
 points.append(tip)
 for local,point in enumerate(points):bind_hair(N+tuft*13+local,point)
# Closed underlay follows the same crest and side surface as the race locks.
for station in range(24):
 x=Q.x+.008+(W.x-Q.x-.020)*station/23;root=posed_body_bvh.ray_cast(Vector((x,0,2)),Vector((0,0,-1)))[0]
 if root is None:continue
 bottom=side_surface(x+.006,root.z-.023)
 points=[root+Vector((0,-.003,.0007)),root+Vector((0,.001,.0007)),bottom+Vector((0,.001,0)),bottom+Vector((0,-.001,0))]
 for j,point in enumerate(points):bind_hair(N+66*13+station*4+j,point)
for mat in o.data.materials:
 for node in mat.node_tree.nodes:
  if node.type=='NORMAL_MAP':node.inputs['Strength'].default_value=.03
specs=json.loads((P/'animation-specs.json').read_text());shape=o.data.shape_keys;shape.animation_data_create();acts={}
for clip,sp in specs.items():
 act=bpy.data.actions.new('Morph_'+clip);act.use_fake_user=True;shape.animation_data.action=act;key.value=0 if clip in ['Stand_Loop','Walk_Loop'] else 1
 for frame in [1,sp['frames']+1]:key.keyframe_insert('value',frame=frame)
 for fc in act.fcurves:
  for point in fc.keyframe_points:point.interpolation='LINEAR'
 shape.animation_data.action=None;tr=shape.animation_data.nla_tracks.new();tr.name=clip;tr.strips.new(clip,1,act);tr.mute=True;acts[clip]=act
shape.animation_data.action=acts['Stand_Loop'];a.animation_data.action=bpy.data.actions['Stand_Loop'];s.frame_set(1);key.value=0
(P/'neck-corrective.json').write_text(json.dumps({'shape_key':key.name,'affected_vertices':count,'max_rest_delta':max_delta,'reference_frame':55,'design_withers_reference':list(W),'design_poll_reference':list(Q),'method':'Inverse LBS correction after topology repair and smooth weights, convex crest projection; locks follow anchors','race_trot_canter_value':1,'stand_walk_value':0},indent=2))
bpy.ops.wm.save_as_mainfile(filepath=str(P/'horse-gallop.blend'));print('CORRECTIVE_READY',count,max_delta)
