# 馬モデル v6

最初に [CLAUDE_HANDOFF.md](CLAUDE_HANDOFF.md) を読んでください。ゲーム本体は含みません。

- `horse-gallop.glb`: 54骨・5歩法・6取付点・UV2毛色領域。首の水平長1.250倍、頭長0.892倍、うなじ上下0.286m。
- `horse-gallop.blend`: 編集元。`tools/README.md`: 元入力からの再制作手順。
- `preview/`: Godot 4.6.3 の独立確認場面。必須シェーダ補正とimport設定は引き継ぎ文を参照。
- `comparison/iteration-05/`: 共通カメラの最終全570枚。v6新規260枚、v4/v5固定参照310枚。PNGから可逆WebPへ変換し全画像の復号画素一致を検査。
- `comparison-preview.mp4`: 同じ時刻のv4/v5/v6、上段横・下段首。60fps、0.45秒×8周期。
- `godot-renders/`: 単独画角の原寸PNG133枚（法線監査含む）。共通比較のカメラとは区別。
- `review/`: 制作と分離した途中レビュー・不合格指摘・別担当の最終レビュー。
- `*-before-after.jpg`: 首/たてがみ/顔の不合格試作と修正の対比。すべて1600×1000。
- `*-validation.json`, `neck-line.json`, `proportion-comparison.json`: 数値と検証の範囲。

中間01〜04/probeは代表画像とシートを抜粋し、全原寸フレームは配布していません。中間レビューの元ファイル名は履歴として残します。最終05は全原寸570枚を収録。`capture-manifest-original.json` は元PNG名での記録、`capture-manifest.json` は配布WebP名です。画素一致の証拠は `image-conversion-validation.json`。

`sha256sum -c SHA256SUMS` で全収録ファイルを確認できます。ZIPのSHA-256は外側のREADMEに記載。

独立画像レビューは合格。近接のたてがみ根元の暗い帯、簡略な鼻孔/口線、芦毛の強い白、胴脚の面の段差と尾の帯状感は軽微な残件。実ゲームの騎手/手綱干渉、歩法遷移、LOD/FPS、実時間再生での見え方は未検証です。素材としての合格とゲーム採用の合格は区別します。

完全再生成は各検証を通過しましたが、Booleanの頂点順と浮動小数丸めによりGLBのバイト一致はしません。base/correctiveの双方向最近点距離は実寸0.0008mm未満。納品は実際にレビュー・描画したGLBに固定しています。`rebuild-validation.json` を参照。

レビューのcoverage-index.jsonは監査の原記録として元PNG名とPNG SHA-256を保持します。配布WebPへの対応と両方のSHAはimage-conversion-validation.jsonにあります。中間04の網羅シートは履歴indexのみを残し、抜粋画像と最終05の全画像を配布しています。
