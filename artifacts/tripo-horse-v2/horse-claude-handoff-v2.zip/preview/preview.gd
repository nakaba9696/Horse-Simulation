extends Node3D

var player: AnimationPlayer
var camera: Camera3D
var status: Label
var pause_button: Button
var is_paused := false
var animation_name: StringName

func _ready() -> void:
 var horse := load("res://assets/horse.glb").instantiate() as Node3D
 add_child(horse)
 var players := horse.find_children("*", "AnimationPlayer", true, false)
 assert(players.size() == 1, "Expected one AnimationPlayer")
 player = players[0]
 for clip in player.get_animation_list():
  if clip != "RESET":
   animation_name = clip
   break
 assert(not animation_name.is_empty(), "Missing gallop animation")
 player.get_animation(animation_name).loop_mode = Animation.LOOP_LINEAR
 player.play(animation_name)
 var ground := MeshInstance3D.new()
 var plane := PlaneMesh.new()
 plane.size = Vector2(20, 20)
 ground.mesh = plane
 var mat := StandardMaterial3D.new()
 mat.albedo_color = Color(0.12, 0.15, 0.17)
 mat.roughness = 0.95
 ground.material_override = mat
 ground.position.y = -0.001
 add_child(ground)
 var environment := WorldEnvironment.new()
 environment.environment = Environment.new()
 environment.environment.background_mode = Environment.BG_COLOR
 environment.environment.background_color = Color(0.08, 0.10, 0.12)
 environment.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
 environment.environment.ambient_light_color = Color.WHITE
 environment.environment.ambient_light_energy = 0.7
 add_child(environment)
 var light := DirectionalLight3D.new()
 light.rotation_degrees = Vector3(-45, -35, 0)
 light.light_energy = 1.8
 light.shadow_enabled = true
 add_child(light)
 camera = Camera3D.new()
 camera.projection = Camera3D.PROJECTION_ORTHOGONAL
 camera.size = 1.4
 add_child(camera)
 set_view(Vector3(0, 0.65, 2.4))
 build_controls()
 print("PREVIEW_READY ", animation_name, " duration=", player.get_animation(animation_name).length)

func set_view(position_value: Vector3) -> void:
 camera.position = position_value
 camera.look_at(Vector3(0, 0.38, 0), Vector3.UP)

func button(text: String, callback: Callable, parent: Node) -> Button:
 var result := Button.new()
 result.text = text
 result.custom_minimum_size = Vector2(150, 60)
 result.pressed.connect(callback)
 parent.add_child(result)
 return result

func build_controls() -> void:
 var layer := CanvasLayer.new()
 add_child(layer)
 var panel := VBoxContainer.new()
 panel.position = Vector2(24, 20)
 layer.add_child(panel)
 var title := Label.new()
 title.text = "馬モデル走行プレビュー（試作）"
 title.add_theme_font_size_override("font_size", 28)
 panel.add_child(title)
 var views := HBoxContainer.new()
 panel.add_child(views)
 button("側面", func(): set_view(Vector3(0, 0.65, 2.4)), views)
 button("正面", func(): set_view(Vector3(-2.4, 0.60, 0)), views)
 button("背面", func(): set_view(Vector3(2.4, 0.60, 0)), views)
 button("斜め", func(): set_view(Vector3(-1.8, 0.85, 1.8)), views)
 pause_button = button("一時停止", toggle_pause, views)
 var speed_label := Label.new()
 speed_label.text = "再生速度（移動速度との対応は未調整）"
 panel.add_child(speed_label)
 var speed := HSlider.new()
 speed.min_value = 0.25
 speed.max_value = 2.0
 speed.step = 0.05
 speed.value = 1.0
 speed.custom_minimum_size = Vector2(650, 50)
 speed.value_changed.connect(func(value: float): player.speed_scale = value)
 panel.add_child(speed)
 status = Label.new()
 panel.add_child(status)

func toggle_pause() -> void:
 is_paused = not is_paused
 if is_paused:
  player.pause()
 else:
  player.play(animation_name)
 pause_button.text = "再生" if is_paused else "一時停止"

func _process(_delta: float) -> void:
 if player != null and status != null:
  status.text = "%s   %.2f / %.2f 秒   ×%.2f" % [animation_name, player.current_animation_position, player.current_animation_length, player.speed_scale]
