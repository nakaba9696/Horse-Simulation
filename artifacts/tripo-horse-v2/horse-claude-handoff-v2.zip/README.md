# 馬モデル試作パッケージ v2

Claudeへ渡す場合は、このZIP一式と「CLAUDE_HANDOFF.mdに従って、独立した試作シーンへ取り込んでください」を渡してください。

自分で見る場合: Godot 4.6でpreview/project.godotを開いてF5。再生・停止、視点切替、再生速度を変更できます。Blenderではhorse-gallop.blendを開いてタイムラインを再生してください。

動画: gallop-preview.mp4。

モデルの毛色や騎手は未対応です。試作のため、自然な歩様やゲーム内の移動速度には引き続き調整が必要です。
