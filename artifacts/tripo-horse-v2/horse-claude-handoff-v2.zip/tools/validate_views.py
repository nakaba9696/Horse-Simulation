import bpy,math,json
from pathlib import Path
from mathutils import Vector,Quaternion
p=Path(__file__).resolve().parent.parent
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.scene.render.fps=60
bpy.ops.import_scene.gltf(filepath=str(p/'horse-gallop.glb'))
a=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE')
if a.animation_data:
 for tr in a.animation_data.nla_tracks:tr.mute=True
 a.animation_data.action=bpy.data.actions[0]
for o in list(bpy.context.scene.objects):
 if o.type=='MESH' and len(o.data.vertices)<100:bpy.data.objects.remove(o,do_unlink=True)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=4;s.cycles.use_denoising=False
s.render.resolution_x=960;s.render.resolution_y=640;s.render.resolution_percentage=100
s.world=bpy.data.worlds.new('Studio');s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.18,.18,.18,1)
for pos in [(-1,-2,3),(1,2,2)]:
 d=bpy.data.lights.new('Light','AREA');d.energy=180;d.size=2;o=bpy.data.objects.new('Light',d);s.collection.objects.link(o);o.location=pos;o.rotation_euler=(Vector((0,0,.4))-o.location).to_track_quat('-Z','Y').to_euler()
d=bpy.data.cameras.new('Camera');o=bpy.data.objects.new('Camera',d);s.collection.objects.link(o);s.camera=o;o.location=(0,-3,1);o.rotation_euler=(Vector((0,0,.42))-o.location).to_track_quat('-Z','Y').to_euler();d.type='ORTHO';d.ortho_scale=1.5

mesh=next(o for o in s.objects if o.type=='MESH' and len(o.data.vertices)>1000)
s.render.fps=60

import math
rest=[v.co.copy() for v in mesh.data.vertices];edges=[tuple(e.vertices) for e in mesh.data.edges];base=[(rest[i]-rest[j]).length for i,j in edges]
rows=[]
for f in range(1,50):
 s.frame_set(f-1);bpy.context.view_layer.update();ev=mesh.evaluated_get(bpy.context.evaluated_depsgraph_get());m=ev.to_mesh();coords=[v.co.copy() for v in m.vertices]
 ratios=sorted((coords[i]-coords[j]).length/l for (i,j),l in zip(edges,base) if l>.002)
 assert all(math.isfinite(c) for v in coords for c in v)
 rows.append({'frame':f,'p99_edge_ratio':ratios[int(len(ratios)*.99)],'max_edge_ratio':ratios[-1]});ev.to_mesh_clear()
 if f not in [1,13,25,37]:continue
 for name,pos in [('front',(-3,-.05,.8)),('back',(3,-.05,.8))]:
  cam=s.camera;cam.location=pos;cam.rotation_euler=(Vector((0,0,.42))-cam.location).to_track_quat('-Z','Y').to_euler();s.render.filepath=str(p/f'{name}-{f:03}.png');bpy.ops.render.render(write_still=True)
(p/'deformation-check.json').write_text(json.dumps(rows,indent=2))
print('MAX_EDGE',max(x['max_edge_ratio'] for x in rows))
