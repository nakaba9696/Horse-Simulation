import bpy,json,re,math
from pathlib import Path
from mathutils import Vector
p=Path(__file__).resolve().parent.parent
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.context.scene.render.fps=60
bpy.ops.import_scene.gltf(filepath=str(p/'horse-gallop.glb'))
a=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');o=next(o for o in bpy.context.scene.objects if o.type=='MESH');s=bpy.context.scene
for tr in a.animation_data.nla_tracks:tr.mute=True
a.animation_data.action=bpy.data.actions[0]
regions={}
for v in o.data.vertices:
 if v.co.z>.055:continue
 total={}
 for g in v.groups:
  m=re.fullmatch(r'tripo::([01])_(Left|Right)_Limb_\d+',o.vertex_groups[g.group].name)
  if m:total[(int(m[1]),m[2])]=total.get((int(m[1]),m[2]),0)+g.weight
 if total:
  key=max(total,key=total.get)
  if total[key]>.5:regions.setdefault(key,[]).append(v.index)
phases={(1,'Left'):0,(1,'Right'):.13,(0,'Left'):.46,(0,'Right'):.59};rows=[]
for sample in range(193):
 t=sample/192;f=t*48;s.frame_set(int(f),subframe=f-int(f));bpy.context.view_layer.update();ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=ev.to_mesh();feet={}
 for key,indices in regions.items():
  coords=[m.vertices[i].co for i in indices];avg=sum(coords,Vector())/len(coords);feet[str(key)]={'mean':list(avg),'min_z':min(c.z for c in coords),'max_z':max(c.z for c in coords),'bounds':[[min(c[axis] for c in coords),max(c[axis] for c in coords)] for axis in range(3)],'stance_expected':(t-phases[key])%1<.34}
 rows.append({'time':t*.8,'feet':feet});ev.to_mesh_clear()
summary={}
for key in regions:
 data=[r['feet'][str(key)] for r in rows if r['feet'][str(key)]['stance_expected']]
 summary[str(key)]={'vertices':len(regions[key]),'stance_min_z':min(v['min_z'] for v in data),'stance_max_min_z':max(v['min_z'] for v in data),'stance_centroid_z_range':max(v['mean'][2] for v in data)-min(v['mean'][2] for v in data),'min_any_z':min(r['feet'][str(key)]['min_z'] for r in rows)}
overlaps=[]
for r in rows:
 keys=list(r['feet'])
 for i,one in enumerate(keys):
  for two in keys[i+1:]:
   b1=r['feet'][one]['bounds'];b2=r['feet'][two]['bounds']
   if all(min(b1[k][1],b2[k][1])>max(b1[k][0],b2[k][0]) for k in range(3)):overlaps.append({'time':r['time'],'pair':[one,two]})
for key in regions:
 samples=[r for r in rows if r['feet'][str(key)]['stance_expected']]
 error=[r['feet'][str(key)]['mean'][0]-(.24/(.34*.8))*(((r['time']/.8)-phases[key])%1)*.8 for r in samples]
 summary[str(key)]['stance_horizontal_drift_range']=max(error)-min(error)
report={'foot_aabb_overlaps':overlaps,'samples':193,'summary':summary,'frames':rows};(p/'contact-check.json').write_text(json.dumps(report,indent=2));print(json.dumps(summary))
