import bpy,math,json
from pathlib import Path
from mathutils import Vector,Quaternion
p=Path(__file__).resolve().parent.parent
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.scene.render.fps=60
bpy.ops.import_scene.gltf(filepath=str(p/'horse-gallop.glb'))
a=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE')
if a.animation_data:
 for tr in a.animation_data.nla_tracks:tr.mute=True
 a.animation_data.action=bpy.data.actions[0]
for o in list(bpy.context.scene.objects):
 if o.type=='MESH' and len(o.data.vertices)<100:bpy.data.objects.remove(o,do_unlink=True)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=4;s.cycles.use_denoising=False
s.render.resolution_x=960;s.render.resolution_y=640;s.render.resolution_percentage=100
s.world=bpy.data.worlds.new('Studio');s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.18,.18,.18,1)
for pos in [(-1,-2,3),(1,2,2)]:
 d=bpy.data.lights.new('Light','AREA');d.energy=180;d.size=2;o=bpy.data.objects.new('Light',d);s.collection.objects.link(o);o.location=pos;o.rotation_euler=(Vector((0,0,.4))-o.location).to_track_quat('-Z','Y').to_euler()
d=bpy.data.cameras.new('Camera');o=bpy.data.objects.new('Camera',d);s.collection.objects.link(o);s.camera=o;o.location=(0,-3,1);o.rotation_euler=(Vector((0,0,.42))-o.location).to_track_quat('-Z','Y').to_euler();d.type='ORTHO';d.ortho_scale=1.5

mesh=next(o for o in s.objects if o.type=='MESH' and len(o.data.vertices)>1000)
s.render.fps=60
frames=[];positions=[]
for f in range(1,50):
 s.frame_set(f-1);bpy.context.view_layer.update()
 ev=mesh.evaluated_get(bpy.context.evaluated_depsgraph_get());m=ev.to_mesh();coords=[mesh.matrix_world@v.co for v in m.vertices];positions.append([v.copy() for v in coords])
 feet={bn:list(a.matrix_world@a.pose.bones[bn].tail) for bn in [f'tripo::{g}_{side}_Limb_4' for g in [0,1] for side in ['Left','Right']]}
 frames.append({'frame':f,'min_z':min(v.z for v in coords),'max_z':max(v.z for v in coords),'feet':feet});ev.to_mesh_clear()
 s.render.filepath=str(p/f'run-{f:03}.png');bpy.ops.render.render(write_still=True)
loop=max((x-y).length for x,y in zip(positions[0],positions[-1]))
(p/'animation-check.json').write_text(json.dumps({'loop_vertex_difference':loop,'frames':frames},indent=2))
print('LOOP_DIFFERENCE',loop)
