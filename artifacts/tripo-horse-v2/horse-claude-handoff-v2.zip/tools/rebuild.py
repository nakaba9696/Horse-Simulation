from pathlib import Path
import subprocess,sys,shutil
root=Path(__file__).resolve().parent
blender=shutil.which('blender')
if not blender:raise SystemExit('Blender 4.3+ must be on PATH')
for name in ['build.py','export.py']:
 subprocess.run([blender,'-b','-t','4','--python',str(root/name)],check=True)
subprocess.run([sys.executable,str(root/'finalize.py')],check=True)
shutil.copy2(root.parent/'horse-gallop.glb',root.parent/'preview/assets/horse.glb')
print('Updated horse-gallop.glb and preview/assets/horse.glb')
