import bpy,math,json,re
import numpy as np
from pathlib import Path
from mathutils import Vector,Quaternion
OUT=Path(__file__).resolve().parent.parent
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=str(OUT/'source-rigged.glb'))
a=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');o=next(o for o in bpy.context.scene.objects if o.type=='MESH' and len(o.data.vertices)>1000)
for x in list(bpy.context.scene.objects):
 if x not in (a,o):bpy.data.objects.remove(x,do_unlink=True)
n=len(o.data.vertices);ng=len(o.vertex_groups);W=np.zeros((n,ng),dtype=float)
for v in o.data.vertices:
 for g in v.groups:W[v.index,g.group]=g.weight
original=W.copy();co=np.array([v.co[:] for v in o.data.vertices]);names={g.name:g.index for g in o.vertex_groups}
def smoothstep(lo,hi,x):
 t=max(0,min(1,(x-lo)/(hi-lo)));return t*t*(3-2*t)
# Remove nonlocal leg influences, with a soft transition at shoulder/hip and midline.
for v in o.data.vertices:
 x,y,z=v.co
 for g in o.vertex_groups:
  m=re.fullmatch(r'tripo::([01])_(Left|Right)_Limb_(\d+)',g.name)
  if not m:continue
  front=int(m[1])==0;left=m[2]=='Left'
  fore=1-smoothstep(-.04,.12,x)
  lateral=1-smoothstep(-.025,.025,y) if left else smoothstep(-.025,.025,y)
  low=1-smoothstep(.34,.49,z)
  W[v.index,g.index]*=(fore if front else 1-fore)*((1-low)+low*lateral)
 W[v.index]/=max(W[v.index].sum(),1e-12)
# Welded-position adjacency prevents UV-seam discontinuities during smoothing.
ids={};gid=[];groups=[]
for v in o.data.vertices:
 key=tuple(round(float(c),6) for c in v.co)
 if key not in ids:ids[key]=len(groups);groups.append([])
 i=ids[key];gid.append(i);groups[i].append(v.index)
adj=[set() for _ in groups]
for e in o.data.edges:
 i,j=(gid[k] for k in e.vertices)
 if i!=j:adj[i].add(j);adj[j].add(i)
G=np.array([W[g].mean(axis=0) for g in groups])
for iteration in range(7):
 N=G.copy()
 for i,neigh in enumerate(adj):
  if not neigh:continue
  z=co[groups[i][0],2];x=co[groups[i][0],0]
  # Local smoothing of limbs and shoulders; preserve face, mane and tail weighting.
  alpha=.32 if z<.50 else .15
  if x<-.27 or x>.38:alpha=.08
  N[i]=(1-alpha)*G[i]+alpha*G[list(neigh)].mean(axis=0)
 G=N
for i,g in enumerate(groups):W[g]=G[i]
# Keep four influences per vertex so GLB and game skinning agree.
for v in o.data.vertices:
 row=W[v.index];keep=np.argsort(row)[-4:];mask=np.ones(ng,dtype=bool);mask[keep]=False;row[mask]=0;row/=row.sum()
 for old in list(v.groups):o.vertex_groups[old.group].remove([v.index])
 for j in keep:
  if row[j]>1e-8:o.vertex_groups[int(j)].add([v.index],float(row[j]),'REPLACE')
changed=int(np.sum(np.max(abs(W-original),axis=1)>1e-5))
# Four-beat in-place gallop prototype, with foot targets on a ground plane during stance.
s=bpy.context.scene;s.render.fps=60;s.frame_start=1;s.frame_end=49
period=48;stance=.34;stride=.24;targets=[];feet=[]
for group,side,phase in [(1,'Left',0),(1,'Right',.13),(0,'Left',.46),(0,'Right',.59)]:
 b=a.pose.bones[f'tripo::{group}_{side}_Limb_2'];rest=b.bone.tail_local.copy();rest.z+={(0,'Left'):.001,(0,'Right'):-.0016,(1,'Left'):-.0145,(1,'Right'):-.009}[(group,side)]
 target=bpy.data.objects.new(f'IK_{group}_{side}',None);s.collection.objects.link(target)
 ik=b.constraints.new('IK');ik.target=target;ik.chain_count=3;ik.iterations=100
 # Fixed hoof orientation keeps stance feet from rolling through the ground.
 foot=a.pose.bones[f'tripo::{group}_{side}_Limb_3']
 orient=bpy.data.objects.new(f'Hoof_{group}_{side}',None);s.collection.objects.link(orient);orient.rotation_mode='QUATERNION';orient.rotation_quaternion=(a.matrix_world@foot.bone.matrix_local).to_quaternion()
 cr=foot.constraints.new('COPY_ROTATION');cr.target=orient;cr.owner_space='WORLD';cr.target_space='WORLD'
 targets.append((target,rest,phase));feet.append((group,side))
for f in range(1,50):
 t=(f-1)/period
 # Root bob is baked on the existing Root bone; object transform stays static.
 root=a.pose.bones['tripo::Root'];root.location=(0,0,0)
 root.location=root.bone.matrix_local.to_3x3().inverted()@Vector((0,0,-.055+.008*(1-math.cos(4*math.pi*t))))
 root.keyframe_insert('location',frame=f)
 for target,rest,phase in targets:
  u=(t-phase)%1
  if u<stance:
   q=u/stance;dx=-stride/2+stride*q;dz=0
  else:
   q=(u-stance)/(1-stance);ease=q*q*(3-2*q);dx=stride/2-stride*ease;dz=.105*math.sin(math.pi*q)**2
  target.location=rest+Vector((dx,0,dz));target.keyframe_insert('location',frame=f)
 for bn,deg in [('tripo::Head_0',3.5),('tripo::Head_2',2),('tripo::Tail_0',4)]:
  b=a.pose.bones[bn];b.rotation_mode='QUATERNION';axis=b.bone.matrix_local.to_3x3().inverted()@Vector((0,1,0));b.rotation_quaternion=Quaternion(axis,math.radians(deg)*math.sin(2*math.pi*t));b.keyframe_insert('rotation_quaternion',frame=f)
# Bake IK into all bone transforms, leaving no IK dependency in exported GLB.
bpy.ops.object.select_all(action='DESELECT');a.select_set(True);bpy.context.view_layer.objects.active=a
bpy.ops.nla.bake(frame_start=1,frame_end=49,step=1,only_selected=False,visual_keying=True,clear_constraints=True,clear_parents=False,use_current_action=False,bake_types={'POSE'})
a.animation_data.action.name='Gallop_Prototype'
for ob in list(bpy.context.scene.objects):
 if ob not in (a,o):bpy.data.objects.remove(ob,do_unlink=True)
s.frame_set(1)
bpy.ops.object.select_all(action='DESELECT');a.select_set(True);o.select_set(True);bpy.context.view_layer.objects.active=a
bpy.ops.export_scene.gltf(filepath=str(OUT/'horse-gallop.glb'),export_format='GLB',use_selection=True,export_animations=True,export_skins=True,export_frame_range=True,export_force_sampling=True)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'horse-gallop.blend'))
(OUT/'build-info.json').write_text(json.dumps({'vertices':n,'changed_vertices':changed,'bones':len(a.data.bones),'fps':60,'frames':[1,49],'duration_seconds':.8,'stance_fraction':stance,'stride_model_units':stride,'animation':'Gallop_Prototype'},indent=2))
print('BUILD_COMPLETE',changed)
